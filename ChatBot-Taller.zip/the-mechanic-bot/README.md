# The Mechanic Bot 🔧

App Android para **The Mechanic Automoción**. Lee los mensajes que llegan a **WhatsApp Business** y responde sola con el botón «Responder» de la notificación. No usa servidores ni IA de pago: todo funciona dentro del dispositivo, mientras esté encendido y con conexión.

## Qué hace

**Chatbot**
- Da la bienvenida y pide nombre, modelo del vehículo, año de fabricación, matrícula y teléfono. Avisa de que hay que **responder con números**.
- Con esos datos crea el **perfil del cliente**. Los perfiles se ordenan por fecha y hora de llegada, del primero al último.
- Menú principal: 1️⃣ ITV · 2️⃣ Mantenimiento · 3️⃣ Avería · 4️⃣ Grúa.
  - **1.1** Revisión pre-ITV · **1.2** ITV desfavorable (pide foto del informe) · **1.3** Tramitar la ITV (pide la fecha de caducidad).
  - **2.1** Mantenimiento básico y **2.2** preventivo: se pueden elegir **varios** servicios (ej.: `1, 4, 6`). Si elige neumáticos, pide medida y foto.
  - **3** Avería y **4** Grúa: pide una breve explicación. La grúa se marca como **URGENTE** y te avisa al momento.
- Entiende `1`, `1️⃣`, `uno`, `1.2`, `1️⃣.2️⃣`, `dos punto uno`… y también palabras como «ITV», «aceite» o «neumáticos».
- Tiene **conocimientos básicos de mecánica**: responde dudas frecuentes (aceite, frenos, batería, testigos, temperatura…) y avisa si hay riesgo para la seguridad.
- Si el cliente no responde como debe (3 intentos), pide hablar con una persona o manda audios, responde que **un trabajador se pondrá en contacto** y lo anota en la app. Desde ese momento, el bot deja de responder en ese chat.
- Al terminar se despide como empresa.
- Si **respondes tú** desde la notificación, el bot se pausa en ese chat. También puedes pausarlo a mano desde la ficha del cliente.

**App**
- **Casos**: lista de perfiles con filtros (Grúa, Contactar, Pendientes, Con cita…). Cada ficha incluye datos, servicios, notas, la conversación completa y botones para llamar o escribir por WhatsApp.
- **Calendario** de todo el año: asigna fecha y hora de visita a cada caso o crea citas libres. Los días con citas se marcan en ámbar.
- **Recordatorios** antes de cada cita (por defecto, 1 día antes y 1 hora antes; se cambia en Ajustes).
- Al asignar una cita, la app ofrece enviar la **confirmación al cliente por WhatsApp**.
- **Simulador**: prueba el bot escribiendo como si fueras un cliente, sin usar WhatsApp.
- **Exportar** los casos en CSV.

## Cómo conseguir el APK

### Opción A: GitHub lo compila por ti (sin ordenador)
1. Sube esta carpeta a un repositorio de GitHub.
2. GitHub compila la app sola en la pestaña **Actions** (tarda unos 5 minutos).
3. Ve a **Releases** desde la tablet y descarga `TheMechanicBot.apk`.

### Opción B: Android Studio (en un ordenador)
Abre la carpeta con Android Studio, conecta la tablet por USB y pulsa ▶️ Run.

## Instalación en la tablet o el móvil

1. Abre `TheMechanicBot.apk` y permite **instalar apps de origen desconocido** si te lo pide.
2. Abre la app y acepta las **notificaciones**.
3. Ve a **Ajustes → Dar acceso a notificaciones** y activa **The Mechanic Bot**.
   - ⚠️ En Android 13 o superior puede salir el aviso **«Ajuste restringido»**. Para quitarlo: Ajustes del sistema → Aplicaciones → The Mechanic Bot → menú **⋮** (arriba a la derecha) → **Permitir ajustes restringidos**. Después vuelve a activar el acceso.
4. Pulsa **Quitar restricción de batería** para que Android no duerma la app.
5. Rellena los **datos del taller** (teléfono, horario y dirección).
6. Prueba el bot con **Herramientas → Probar el bot (simulador)**.

## Requisitos para que responda en WhatsApp

- **WhatsApp Business** instalado y con sesión iniciada **en el mismo dispositivo** que la app. En una tablet, se vincula como dispositivo acompañante desde el móvil del taller: WhatsApp Business → Dispositivos vinculados.
- Las **notificaciones de WhatsApp Business activadas**, y los chats sin silenciar.
- Si tienes un chat **abierto en pantalla**, WhatsApp no muestra la notificación y el bot no lo ve. Deja la tablet en la pantalla de inicio o con la app del bot abierta.
- Dispositivo encendido, con internet y, mejor, enchufado.

## Limitaciones

- Las **fotos** no se descargan en la app: queda anotado que el cliente envió la foto, y la ves en el chat de WhatsApp.
- El bot **no responde en grupos**.
- No escucha **audios**: pide al cliente que lo escriba.
- Es una automatización no oficial de las notificaciones. Úsala solo para responder a quien te escribe, nunca para mensajes masivos.
- Si respondes desde dentro de WhatsApp (y no desde la notificación), la app no puede detectarlo. En ese caso pausa el bot desde la ficha del cliente, o usa el botón «WhatsApp» de la ficha, que lo pausa automáticamente.

## Personalizar textos

Todos los mensajes del bot están en `app/src/main/java/com/themechanic/bot/engine/BotEngine.kt`. Los conocimientos de mecánica están en `Mechanics.kt`.

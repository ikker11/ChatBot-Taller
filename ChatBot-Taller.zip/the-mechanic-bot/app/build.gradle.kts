plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.themechanic.bot"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.themechanic.bot"
        minSdk = 26
        targetSdk = 34
        versionCode = 4
        versionName = "1.3"
    }

    // Firma fija: así cada versión nueva se instala encima de la anterior sin perder datos
    signingConfigs {
        create("taller") {
            storeFile = file("firma.keystore")
            storePassword = "themechanic"
            keyAlias = "chatbot"
            keyPassword = "themechanic"
        }
    }

    buildTypes {
        debug {
            signingConfig = signingConfigs.getByName("taller")
        }
        release {
            isMinifyEnabled = false
            signingConfig = signingConfigs.getByName("taller")
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    kotlinOptions {
        jvmTarget = "17"
    }

    lint {
        abortOnError = false
        checkReleaseBuilds = false
    }
}

dependencies {
    implementation("androidx.core:core-ktx:1.13.1")
    testImplementation("junit:junit:4.13.2")
}

package com.themechanic.bot.engine

import org.junit.Assert.assertEquals
import org.junit.Test
import java.time.ZoneId

class MemStore : CaseStore {
    val profiles = linkedMapOf<String, Profile>()
    val events = mutableListOf<CaseEvent>()
    var n = 0
    override fun newProfile(chatKey: String, now: Long) = Profile("p${++n}", chatKey, now).also { profiles[it.id] = it }
    override fun getProfile(id: String) = profiles[id]
    override fun onProfileChanged(profile: Profile, event: CaseEvent) { events += event }
}

var failures = 0
fun check(cond: Boolean, msg: String) { if (!cond) { failures++; println("   ❌ FALLO: $msg") } }

class Chat(val title: String, waPhone: String = "") {
    var now = 1_790_000_000_000L
    val store = MemStore()
    val engine = BotEngine(store, { TallerInfo(phone = "600 000 000", hours = "L-V 8:30-14:00 y 16:00-19:00") }, { now }, ZoneId.of("Europe/Madrid"))
    val conv = Conversation("chat").also { it.waPhone = waPhone }
    fun say(t: String, verbose: Boolean = true): String? {
        val r = engine.handle(conv, Incoming(t))
        if (verbose) { println("👤 $t"); println("🤖 ${r?.replace("\n", "\n   ") ?: "(sin respuesta)"}"); println() }
        return r
    }
    val p get() = store.profiles.values.last()
}

fun data(c: Chat) { c.say("Hola", false); c.say("Me llamo juan pérez", false); c.say("Seat Ibiza", false); c.say("2015", false); c.say("1234abc", false); c.say("600123456", false) }

fun runAllScenarios() {
    println("===== 1. Flujo completo: datos + ITV 1.1 =====")
    Chat("A").apply {
        val w = say("Hola buenas")!!
        check(w.contains("The Mechanic Automoción") && w.contains("número"), "bienvenida")
        say("Me llamo juan pérez")
        say("Seat Ibiza")
        say("del 2015")
        say("1234 abc")
        val m = say("600 12 34 56")!!
        check(m.contains("1️⃣ ITV") && m.contains("4️⃣ GRÚA"), "menú principal")
        check(store.profiles.size == 1 && p.name == "Juan Pérez" && p.plate == "1234 ABC" && p.year == "2015" && p.phone == "600 123 456", "perfil creado ${p.name}|${p.plate}|${p.year}|${p.phone}")
        val itv = say("1️⃣")!!
        check(itv.contains("1️⃣.1️⃣ REVISIÓN PRE-ITV"), "submenú ITV")
        say("1.1")
        check(p.services.contains("ITV › Revisión pre-ITV"), "servicio pre-ITV")
        val bye = say("no, gracias")!!
        check(bye.contains("Muchas gracias") && p.status == CaseStatus.PENDING && conv.step == Step.DONE, "despedida")
        check(store.events.contains(CaseEvent.COMPLETED), "evento completado")
        val again = say("hola?")
        check(again != null && again.contains("Ya tenemos"), "aviso de ya registrado")
        check(say("??", false) == null, "silencio tras aviso")
        now += 13L * 3600_000
        val back = say("Hola otra vez")!!
        check(back.contains("mismo vehículo"), "cliente que vuelve")
        say("sí")
        check(store.profiles.size == 2 && p.plate == "1234 ABC", "nuevo caso con mismo coche")
    }

    println("===== 2. Números escritos y emojis: ITV desfavorable + tramitar =====")
    Chat("B").apply {
        data(this)
        say("uno")
        say("dos")
        val r = say("📷 Foto")!!
        check(p.notes.any { it.contains("informe ITV") }, "nota foto ITV")
        check(r.contains("algo más"), "pregunta algo más")
        say("1")
        say("1️⃣.3️⃣")
        say("pues no sé, mañana miro")
        say("en marzo del 2027")
        check(p.itvExpiry == "marzo de 2027", "fecha ITV: ${p.itvExpiry}")
        say("2")
    }

    println("===== 3. Mantenimiento básico multiselección + preventivo con neumáticos =====")
    Chat("C").apply {
        data(this)
        say("2")
        say("2.1")
        say("1, 4 y seis, 9")
        check(p.services.containsAll(listOf("Mantenimiento básico › Filtro de aire", "Mantenimiento básico › Cambio de aceite + filtro de aceite", "Mantenimiento básico › Cambio de pastillas")), "básico: ${p.services}")
        say("si")
        say("2️⃣.2️⃣.3️⃣ 2️⃣.2️⃣.6️⃣")
        check(conv.step == Step.ASK_TIRE_SIZE, "pide medidas: ${conv.step}")
        say("Las dos delanteras 205/55r16")
        check(p.notes.any { it.contains("205/55 R16") }, "medida neumático")
        say("📷 Foto")
        say("2")
        check(p.services.contains("Mantenimiento preventivo › Neumáticos") && p.services.contains("Mantenimiento preventivo › Embrague"), "preventivo")
    }

    println("===== 4. Avería con riesgo + duda de mecánica =====")
    Chat("D").apply {
        data(this)
        say("¿cada cuánto hay que cambiar el aceite?")
        check(conv.failures == 0, "duda no cuenta como fallo")
        say("tres")
        val r = say("El pedal del freno está muy blando y se va al fondo")!!
        check(r.contains("no circules"), "aviso de seguridad")
        say("2")
    }

    println("===== 5. Grúa =====")
    Chat("E", waPhone = "+34611222333").apply {
        say("Buenas"); say("Soy Marta"); say("Renault Clio 2012 4567 DFG")
        check(conv.step == Step.ASK_PHONE, "aprovecha año y matrícula: ${conv.step}")
        say("1")
        check(p.phone == "+34611222333", "teléfono de WhatsApp")
        say("grúa")
        say("📍 Ubicación")
        val r = say("Se me ha parado en la A-3 km 20 y no arranca")!!
        check(p.status == CaseStatus.URGENT && store.events.contains(CaseEvent.URGENT), "urgente")
        check(r.contains("baliza V16") && conv.step == Step.DONE, "despedida grúa")
    }

    println("===== 6. Cliente que no responde bien → trabajador =====")
    Chat("F").apply {
        data(this)
        say("asdf")
        say("no sé qué poner")
        val r = say("jajaja")!!
        check(r.contains("un trabajador se pondrá en contacto"), "salida a trabajador")
        check(p.status == CaseStatus.NEEDS_CONTACT && conv.step == Step.HUMAN, "estado contactar")
        check(say("hola??", false) == null, "silencio con trabajador")
    }

    println("===== 7. Pide una persona durante los datos =====")
    Chat("G").apply {
        say("hola"); say("Pedro")
        say("quiero hablar con una persona")
        check(p.status == CaseStatus.NEEDS_CONTACT && p.name == "Pedro", "perfil parcial + contactar")
    }

    println("===== 8. Audios y volver atrás =====")
    Chat("H").apply {
        data(this)
        say("🎤 Mensaje de voz (0:12)")
        say("1"); say("0")
        check(conv.step == Step.MAIN_MENU, "volver al menú")
        say("1.2")
        check(conv.step == Step.ASK_ITV_PHOTO, "salto directo 1.2")
    }

    println("===== Parsers =====")
    check(TextParsing.parsePlate("matrícula 1234-BCD") == "1234 BCD", "matrícula guion")
    check(TextParsing.parsePlate("M-1234-XY") == "M-1234-XY", "matrícula antigua ${TextParsing.parsePlate("M-1234-XY")}")
    check(TextParsing.parsePlate("seat ibiza") == null, "no matrícula")
    check(TextParsing.parseYear("08", 2026) == 2008, "año 2 cifras")
    check(TextParsing.parseDate("15/03/2027", java.time.LocalDate.of(2026, 10, 9)) == "15/03/2027", "fecha")
    check(TextParsing.parseDate("15 de marzo de 2027", java.time.LocalDate.of(2026, 10, 9)) == "15/03/2027", "fecha texto")
    check(TextParsing.parseDate("03/2027", java.time.LocalDate.of(2026, 10, 9)) == "marzo de 2027", "mes/año")
    check(TextParsing.numberTokens("2️⃣.1️⃣.1️⃣, dos punto uno punto cuatro") == listOf(listOf(2, 1, 1), listOf(2, 1, 4)), "tokens")
    check(TextParsing.parsePhone("+34 600 12 34 56") == "+34600123456", "teléfono +34")

    println(if (failures == 0) "\n✅ TODAS LAS PRUEBAS OK" else "\n❌ $failures fallos")
}

/** Simula conversaciones completas de todas las ramas del menú. */
class BotEngineTest {
    @Test
    fun todasLasConversaciones() {
        failures = 0
        runAllScenarios()
        assertEquals("Hay pruebas del bot que fallan (ver salida)", 0, failures)
    }
}

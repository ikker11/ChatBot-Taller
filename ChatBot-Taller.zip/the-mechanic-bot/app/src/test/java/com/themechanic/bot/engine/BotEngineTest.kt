package com.themechanic.bot.engine

import org.junit.Assert.assertEquals
import org.junit.Test
import java.time.ZoneId

class MemStore : CaseStore {
    val profiles = linkedMapOf<String, Profile>()
    val events = mutableListOf<CaseEvent>()
    var n = 0
    override fun newProfile(chatKey: String, now: Long) = Profile("p${++n}", chatKey, now).also { profiles[it.id] = it }
    override fun getProfile(id: String) = profiles[id]
    override fun onProfileChanged(profile: Profile, event: CaseEvent) { events += event }
    val appts = mutableListOf<ApptRef>()
    override fun latestProfileFor(chatKey: String, since: Long) =
        profiles.values.filter { it.chatKey == chatKey && maxOf(it.updatedAt, it.createdAt) >= since }.maxByOrNull { it.createdAt }
    override fun upcomingAppointments(chatKey: String, now: Long) =
        appts.filter { a -> a.at >= now - 7200_000L && a.profileId?.let { profiles[it]?.chatKey } == chatKey }
    override fun cancelAppointment(id: String) { appts.removeAll { it.id == id } }
}

var failures = 0
fun check(cond: Boolean, msg: String) { if (!cond) { failures++; println("   ❌ FALLO: $msg") } }

class Chat(val title: String, waPhone: String = "") {
    var now = 1_790_000_000_000L
    val store = MemStore()
    var bs = BotSettings()
    val engine = BotEngine(store, { TallerInfo(phone = "600 000 000", hours = "L-V 8:30-14:00 y 16:00-19:00") }, { now }, ZoneId.of("Europe/Madrid"), { bs })
    val conv = Conversation("chat").also { it.waPhone = waPhone }
    fun say(t: String, verbose: Boolean = true): String? {
        val r = engine.handle(conv, Incoming(t))
        if (verbose) { println("👤 $t"); println("🤖 ${r?.replace("\n", "\n   ") ?: "(sin respuesta)"}"); println() }
        return r
    }
    val p get() = store.profiles.values.last()
}

fun data(c: Chat) { c.say("Hola", false); c.say("Me llamo juan pérez", false); c.say("Seat Ibiza", false); c.say("2015", false); c.say("1234abc", false); c.say("600123456", false) }

fun runAllScenarios() {
    println("===== 1. Flujo completo: datos + ITV 1.1 =====")
    Chat("A").apply {
        val w = say("Hola buenas")!!
        check(w.contains("The Mechanic Automoción") && w.contains("número"), "bienvenida")
        say("Me llamo juan pérez")
        say("Seat Ibiza")
        say("del 2015")
        say("1234 abc")
        val m = say("600 12 34 56")!!
        check(m.contains("1️⃣ ITV") && m.contains("4️⃣ GRÚA"), "menú principal")
        check(store.profiles.size == 1 && p.name == "Juan Pérez" && p.plate == "1234 ABC" && p.year == "2015" && p.phone == "600 123 456", "perfil creado ${p.name}|${p.plate}|${p.year}|${p.phone}")
        val itv = say("1️⃣")!!
        check(itv.contains("1️⃣.1️⃣ REVISIÓN PRE-ITV"), "submenú ITV")
        say("1.1")
        check(p.services.contains("ITV › Revisión pre-ITV"), "servicio pre-ITV")
        val bye = say("no, gracias")!!
        check(bye.contains("Muchas gracias") && p.status == CaseStatus.PENDING && conv.step == Step.DONE, "despedida")
        check(store.events.contains(CaseEvent.COMPLETED), "evento completado")
        val again = say("hola?")
        check(again != null && again.contains("Ya tenemos"), "aviso de ya registrado")
        check(say("??", false) == null, "silencio tras aviso")
        now += 13L * 3600_000
        val back = say("Hola otra vez")!!
        check(back.contains("mismo vehículo"), "cliente que vuelve")
        say("sí")
        check(store.profiles.size == 2 && p.plate == "1234 ABC", "nuevo caso con mismo coche")
    }

    println("===== 2. Números escritos y emojis: ITV desfavorable + tramitar =====")
    Chat("B").apply {
        data(this)
        say("uno")
        say("dos")
        val r = say("📷 Foto")!!
        check(p.notes.any { it.contains("informe ITV") }, "nota foto ITV")
        check(r.contains("algo más"), "pregunta algo más")
        say("1")
        say("1️⃣.3️⃣")
        say("pues no sé, mañana miro")
        say("en marzo del 2027")
        check(p.itvExpiry == "marzo de 2027", "fecha ITV: ${p.itvExpiry}")
        say("2")
    }

    println("===== 3. Mantenimiento básico multiselección + preventivo con neumáticos =====")
    Chat("C").apply {
        data(this)
        say("2")
        say("2.1")
        say("1, 4 y seis, 9")
        check(p.services.containsAll(listOf("Mantenimiento básico › Filtro de aire", "Mantenimiento básico › Cambio de aceite + filtro de aceite", "Mantenimiento básico › Cambio de pastillas")), "básico: ${p.services}")
        say("si")
        say("2️⃣.2️⃣.3️⃣ 2️⃣.2️⃣.6️⃣")
        check(conv.step == Step.ASK_TIRE_SIZE, "pide medidas: ${conv.step}")
        say("Las dos delanteras 205/55r16")
        check(p.notes.any { it.contains("205/55 R16") }, "medida neumático")
        say("📷 Foto")
        say("2")
        check(p.services.contains("Mantenimiento preventivo › Neumáticos") && p.services.contains("Mantenimiento preventivo › Embrague"), "preventivo")
    }

    println("===== 4. Avería con riesgo + duda de mecánica =====")
    Chat("D").apply {
        data(this)
        say("¿cada cuánto hay que cambiar el aceite?")
        check(conv.failures == 0, "duda no cuenta como fallo")
        say("tres")
        val r = say("El pedal del freno está muy blando y se va al fondo")!!
        check(r.contains("no circules"), "aviso de seguridad")
        say("2")
    }

    println("===== 5. Grúa =====")
    Chat("E", waPhone = "+34611222333").apply {
        say("Buenas"); say("Soy Marta"); say("Renault Clio 2012 4567 DFG")
        check(conv.step == Step.ASK_PHONE, "aprovecha año y matrícula: ${conv.step}")
        say("1")
        check(p.phone == "+34611222333", "teléfono de WhatsApp")
        say("grúa")
        say("📍 Ubicación")
        val r = say("Se me ha parado en la A-3 km 20 y no arranca")!!
        check(p.status == CaseStatus.URGENT && store.events.contains(CaseEvent.URGENT), "urgente")
        check(r.contains("baliza V16") && conv.step == Step.DONE, "despedida grúa")
    }

    println("===== 6. Cliente que no responde bien → trabajador =====")
    Chat("F").apply {
        data(this)
        say("asdf")
        say("qwerty zzz")
        val r = say("blablabla ñe")!!
        check(r.contains("un trabajador se pondrá en contacto"), "salida a trabajador")
        check(p.status == CaseStatus.NEEDS_CONTACT && conv.step == Step.HUMAN, "estado contactar")
        check(say("hola??", false) == null, "silencio con trabajador")
    }

    println("===== 7. Pide una persona durante los datos =====")
    Chat("G").apply {
        say("hola"); say("Pedro")
        say("quiero hablar con una persona")
        check(p.status == CaseStatus.NEEDS_CONTACT && p.name == "Pedro", "perfil parcial + contactar")
    }

    println("===== 8. Audios y volver atrás =====")
    Chat("H").apply {
        data(this)
        say("🎤 Mensaje de voz (0:12)")
        say("1"); say("0")
        check(conv.step == Step.MAIN_MENU, "volver al menú")
        say("1.2")
        check(conv.step == Step.ASK_ITV_PHOTO, "salto directo 1.2")
    }


    println("===== 9. Charla fuera de los pasos =====")
    Chat("I").apply {
        data(this)
        val g = say("gracias")!!
        check(g.startsWith("¡De nada!") && g.contains("1️⃣ ITV") && conv.failures == 0, "gracias + menú")
        val r = say("¿eres un robot?")!!
        check(r.contains("asistente virtual") && conv.step == Step.MAIN_MENU, "identidad sin pasar a persona")
        val h = say("hola")!!
        check(h.startsWith("¡Hola!") && conv.failures == 0, "saludo a mitad")
        val u = say("es urgente por favor")!!
        check(u.contains("GRÚA") && u.contains("600 000 000"), "urgente")
        val t = say("¿cuánto tardáis?")!!
        check(t.contains("depende"), "plazo")
        val pago = say("¿aceptáis bizum?")!!
        check(pago.contains("pago"), "pago")
        say("1")
        check(conv.step == Step.ITV_MENU, "sigue funcionando el menú")
    }

    println("===== 10. Pausa de 1 h y volver con el menú =====")
    Chat("J").apply {
        bs = BotSettings(pauseMs = 3600_000L, resumeMode = ResumeMode.MENU)
        data(this)
        engine.pause(conv, now)
        check(say("hola?", false) == null, "callado durante la pausa")
        now += 30 * 60_000L
        check(say("sigues?", false) == null, "callado a los 30 min")
        now += 31 * 60_000L
        val r = say("hola de nuevo")!!
        check(r.contains("Hola de nuevo, Juan Pérez") && r.contains("1️⃣ ITV") && conv.step == Step.MAIN_MENU, "vuelve con menú")
        check(store.profiles.size == 2, "abre caso nuevo con mismos datos")
    }

    println("===== 11. Pausa y seguir donde se quedó =====")
    Chat("K").apply {
        bs = BotSettings(pauseMs = 60 * 60_000L, resumeMode = ResumeMode.CONTINUE)
        say("hola", false); say("Ana", false)
        engine.pause(conv, now)
        now += 2 * 3600_000L
        val r = say("perdona")!!
        check(r.contains("Seguimos donde lo dejamos") && conv.step == Step.ASK_MODEL, "retoma en modelo: ${conv.step}")
    }

    println("===== 12. Pausa indefinida y reactivar =====")
    Chat("L").apply {
        bs = BotSettings(pauseMs = Long.MAX_VALUE, resumeMode = ResumeMode.RESTART)
        data(this)
        engine.pause(conv, now)
        now += 10L * 24 * 3600_000L
        check(say("hola", false) == null, "sigue callado tras 10 días")
        engine.reset(conv)
        val r = say("hola")!!
        check(r.contains("mismo vehículo"), "tras reactivar empieza de nuevo")
    }


    println("===== 13. Memoria: vuelve a los 2 meses =====")
    Chat("M").apply {
        data(this); say("1", false); say("1.1", false); say("2", false)
        now += 60L * 24 * 3600_000L
        val r = say("Hola buenas")!!
        check(r.contains("Hola de nuevo, Juan Pérez") && r.contains("La última vez nos consultaste por: Revisión pre-ITV"), "recuerda al cliente")
        check(conv.step == Step.ASK_SAME_VEHICLE, "pregunta mismo vehículo")
    }

    println("===== 14. Memoria: pasados 7 meses empieza de cero =====")
    Chat("N").apply {
        data(this); say("1", false); say("1.1", false); say("2", false)
        now += 210L * 24 * 3600_000L
        val r = say("Hola")!!
        check(r.contains("Bienvenido/a") && conv.step == Step.ASK_NAME && conv.name.isBlank(), "olvida tras 6 meses")
    }

    println("===== 15. Recuerda aunque se pierda la conversación =====")
    Chat("O").apply {
        data(this); say("2", false); say("2.1", false); say("4", false); say("2", false)
        val fresh = Conversation("chat")
        now += 5L * 24 * 3600_000L
        val r = engine.handle(fresh, Incoming("hola"))!!
        println("🤖 " + r.replace("\n", "\n   "))
        check(r.contains("Hola de nuevo, Juan Pérez") && r.contains("Cambio de aceite"), "recupera desde el perfil")
    }

    println("===== 16. Anula la cita estando el bot en pausa =====")
    Chat("P").apply {
        data(this); say("1", false); say("1.1", false); say("2", false)
        store.appts += ApptRef("a1", now + 3L * 24 * 3600_000L, p.id)
        engine.pause(conv, now)
        now += 3600_000L
        val r = say("Hola, al final tengo que anular la cita, lo siento")!!
        check(r.contains("anulado") && store.appts.isEmpty(), "cita anulada y borrada")
        check(p.status == CaseStatus.CANCELLED && store.events.last() == CaseEvent.CANCELLED, "estado y aviso de anulación")
        check(p.notes.any { it.contains("ANULADO") }, "nota de anulación")
        check(conv.step == Step.HUMAN, "sigue en pausa")
    }

    println("===== 17. Quiere cambiar la cita =====")
    Chat("Q").apply {
        data(this); say("3", false); say("Hace ruido al frenar", false); say("2", false)
        store.appts += ApptRef("a2", now + 2L * 24 * 3600_000L, p.id)
        now += 3600_000L
        val r = say("¿podemos cambiar la cita a otro día?")!!
        check(r.contains("cambiar tu cita") && store.appts.size == 1, "cita mantenida")
        check(p.status == CaseStatus.NEEDS_CONTACT && store.events.last() == CaseEvent.RESCHEDULE, "aviso de cambio")
        val r2 = say("no puedo ir")
        check(r2 != null && r2.contains("anulado") && store.appts.isEmpty(), "luego la anula")
    }

    println("===== 18. 'No puedo ir' sin cita no hace nada raro =====")
    Chat("R").apply {
        data(this)
        val r = say("no puedo ir")!!
        check(!r.contains("anulado"), "sin cita no anula")
    }

    println("===== Parsers =====")
    check(TextParsing.parsePlate("matrícula 1234-BCD") == "1234 BCD", "matrícula guion")
    check(TextParsing.parsePlate("M-1234-XY") == "M-1234-XY", "matrícula antigua ${TextParsing.parsePlate("M-1234-XY")}")
    check(TextParsing.parsePlate("seat ibiza") == null, "no matrícula")
    check(TextParsing.parseYear("08", 2026) == 2008, "año 2 cifras")
    check(TextParsing.parseDate("15/03/2027", java.time.LocalDate.of(2026, 10, 9)) == "15/03/2027", "fecha")
    check(TextParsing.parseDate("15 de marzo de 2027", java.time.LocalDate.of(2026, 10, 9)) == "15/03/2027", "fecha texto")
    check(TextParsing.parseDate("03/2027", java.time.LocalDate.of(2026, 10, 9)) == "marzo de 2027", "mes/año")
    check(TextParsing.numberTokens("2️⃣.1️⃣.1️⃣, dos punto uno punto cuatro") == listOf(listOf(2, 1, 1), listOf(2, 1, 4)), "tokens")
    check(TextParsing.parsePhone("+34 600 12 34 56") == "+34600123456", "teléfono +34")

    println(if (failures == 0) "\n✅ TODAS LAS PRUEBAS OK" else "\n❌ $failures fallos")
}

/** Simula conversaciones completas de todas las ramas del menú. */
class BotEngineTest {
    @Test
    fun todasLasConversaciones() {
        failures = 0
        runAllScenarios()
        assertEquals("Hay pruebas del bot que fallan (ver salida)", 0, failures)
    }
}

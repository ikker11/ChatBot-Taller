package com.themechanic.bot.notify

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import com.themechanic.bot.data.AppSettings
import com.themechanic.bot.data.Appointment
import com.themechanic.bot.data.Repo

/** Programa los avisos de las citas con la antelación elegida en Ajustes. */
object Reminders {
    private const val ACTION = "com.themechanic.bot.RECORDATORIO"
    const val EXTRA_APPT = "cita"
    const val EXTRA_MIN = "minutos"

    private fun pending(ctx: Context, a: Appointment, slot: Int, minutes: Int, create: Boolean): PendingIntent? {
        val intent = Intent(ctx, ReminderReceiver::class.java)
            .setAction(ACTION)
            .setData(Uri.parse("cita://${a.id}/$slot"))
            .putExtra(EXTRA_APPT, a.id)
            .putExtra(EXTRA_MIN, minutes)
        val mode = if (create) PendingIntent.FLAG_UPDATE_CURRENT else PendingIntent.FLAG_NO_CREATE
        val flags = PendingIntent.FLAG_IMMUTABLE or mode
        return PendingIntent.getBroadcast(ctx, 0, intent, flags)
    }

    fun schedule(ctx: Context, a: Appointment) {
        val am = ctx.getSystemService(AlarmManager::class.java)
        val now = System.currentTimeMillis()
        AppSettings.reminderOffsets().forEachIndexed { slot, minutes ->
            pending(ctx, a, slot, minutes, false)?.let { am.cancel(it) }
            if (minutes <= 0) return@forEachIndexed
            val at = a.at - minutes * 60_000L
            if (at <= now) return@forEachIndexed
            val pi = pending(ctx, a, slot, minutes, true) ?: return@forEachIndexed
            val exact = Build.VERSION.SDK_INT < Build.VERSION_CODES.S || am.canScheduleExactAlarms()
            if (exact) am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pi)
            else am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pi)
        }
    }

    fun cancel(ctx: Context, a: Appointment) {
        val am = ctx.getSystemService(AlarmManager::class.java)
        for (slot in 0..1) pending(ctx, a, slot, 0, false)?.let { am.cancel(it); it.cancel() }
    }

    fun rescheduleAll(ctx: Context) {
        Repo.allAppointments().forEach { schedule(ctx, it) }
    }
}

class ReminderReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        Repo.init(context)
        val a = Repo.appointment(intent.getStringExtra(Reminders.EXTRA_APPT)) ?: return
        val p = Repo.profile(a.profileId)
        Notifier.reminder(context, a, p, intent.getIntExtra(Reminders.EXTRA_MIN, 0))
    }
}

/** Al reiniciar el dispositivo, vuelve a programar los recordatorios. */
class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        Repo.init(context)
        Reminders.rescheduleAll(context)
    }
}

package com.themechanic.bot.engine

/**
 * Respuestas mínimas para cuando el cliente escribe algo que no tiene que ver
 * con el paso en el que está (saludos, gracias, dudas generales...).
 * Después de responder, el bot repite la pregunta pendiente.
 */
object SmallTalk {

    private fun has(text: String, vararg phrases: String) = TextParsing.containsAny(text, phrases.toList())
    private fun words(text: String) = TextParsing.words(text).size

    private val IDENTITY = listOf(
        "eres un robot", "eres un bot", "eres una maquina", "eres real", "eres humano", "eres una persona",
        "hablo con una maquina", "hablo con un robot", "hablo con un bot", "eres un contestador", "quien eres",
        "con quien hablo", "eres una ia", "inteligencia artificial", "eres automatico",
    )

    fun isIdentityQuestion(text: String) = TextParsing.containsAny(text, IDENTITY)

    fun identity(taller: String) =
        "Soy el asistente virtual de *$taller* 🤖. Te ayudo a registrar tu solicitud para que un mecánico la revise. " +
            "Si prefieres hablar con una persona, escribe *persona*."

    /** Devuelve una respuesta corta, o null si no es charla reconocible. */
    fun answer(text: String, info: TallerInfo): String? {
        val n = words(text)
        val tel = info.phone.takeIf { it.isNotBlank() }
        return when {
            has(text, "jaja", "jajaja", "jajajaja", "jeje", "jejeje", "xd", "lol") && n <= 4 -> "😄"

            has(text, "gracias", "muchas gracias", "mil gracias", "te lo agradezco", "agradecido", "agradecida") ->
                "¡De nada! 😊"

            has(text, "tonto", "tonta", "idiota", "inutil", "mierda", "joder", "gilipollas", "imbecil", "estupido", "estupida") ->
                "Siento las molestias 🙏 Estoy aquí para ayudarte. Si lo prefieres, escribe *persona* y te contactará un trabajador."

            has(text, "adios", "hasta luego", "chao", "chau", "nos vemos", "hasta pronto", "hasta manana", "buenas noches") && n <= 5 ->
                "¡Hasta pronto! 👋 Cuando quieras, seguimos con tu solicitud."

            TextParsing.isGreeting(text) && n <= 4 -> "¡Hola! 👋"

            has(text, "ok", "okay", "okey", "vale", "perfecto", "entendido", "de acuerdo", "genial", "estupendo", "guay", "bien", "muy bien") && n <= 3 ->
                "👍"

            has(text, "urgente", "es urgente", "lo antes posible", "cuanto antes", "emergencia", "rapido", "deprisa") ->
                "Entendido, lo marcamos como prioritario 🚨 Si tu vehículo no puede circular, elige *GRÚA* en el menú." +
                    (tel?.let { " Si es muy urgente, llámanos al *$it*." } ?: "")

            has(text, "cuanto tardais", "cuanto tiempo", "cuanto tarda", "cuanto tardara", "para cuando", "plazo", "cuando estara", "cuando lo tendre", "cuantos dias") ->
                "El tiempo depende del trabajo y de la disponibilidad de piezas. Un trabajador te lo confirmará al revisar tu solicitud. ⏱️"

            has(text, "tarjeta", "bizum", "efectivo", "formas de pago", "forma de pago", "como se paga", "como pago", "pagar", "financiar", "financiacion") ->
                "Las formas de pago te las confirmará un trabajador cuando revise tu solicitud. 💳"

            has(text, "teneis hueco", "hay hueco", "disponibilidad", "cuando puedo llevar", "puedo ir hoy", "puedo llevarlo", "puedo pasar", "me dais cita", "dar cita", "pedir cita") ->
                "Para darte cita primero registramos tu solicitud; después un trabajador te propondrá día y hora. 📅"

            has(text, "coche de sustitucion", "vehiculo de sustitucion", "coche de cortesia", "coche de alquiler") ->
                "Lo anotamos para que nuestro equipo te confirme si hay vehículo de sustitución disponible. 🚗"

            has(text, "garantia") ->
                "Las dudas sobre garantía las revisará un trabajador al ver tu caso. 📝"

            has(text, "ayuda", "que puedes hacer", "no entiendo", "como funciona", "que tengo que hacer", "que hago", "no se que poner", "no se que hacer") ->
                "Te explico 🙂 Solo tienes que responder a cada pregunta. En los menús, escribe el *número* de la opción que quieras (por ejemplo: 1)."

            has(text, "que tal", "como estas", "como va") && n <= 5 ->
                "¡Muy bien, gracias! 😊 Vamos con tu consulta."

            else -> null
        }
    }
}

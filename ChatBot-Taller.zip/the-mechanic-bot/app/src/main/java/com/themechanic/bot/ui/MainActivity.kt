package com.themechanic.bot.ui

import android.Manifest
import android.app.Activity
import android.app.AlarmManager
import android.app.AlertDialog
import android.app.TimePickerDialog
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.PowerManager
import android.provider.Settings
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.CheckBox
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.HorizontalScrollView
import android.widget.ImageView
import android.widget.LinearLayout
import com.themechanic.bot.R
import android.widget.ScrollView
import android.widget.Spinner
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast
import com.themechanic.bot.data.AppSettings
import com.themechanic.bot.data.Appointment
import com.themechanic.bot.data.Fmt
import com.themechanic.bot.data.Repo
import com.themechanic.bot.engine.CaseStatus
import com.themechanic.bot.engine.Profile
import com.themechanic.bot.notify.Reminders
import com.themechanic.bot.service.WhatsAppListener
import java.time.LocalDate
import java.time.LocalTime
import java.time.YearMonth
import java.time.ZoneId
import java.time.format.TextStyle
import java.util.Locale

class MainActivity : Activity() {

    companion object {
        const val EXTRA_TAB = "tab"
    }

    private lateinit var content: FrameLayout
    private lateinit var tabs: List<TextView>
    private lateinit var botPill: TextView
    private var tab = 0
    private var filter: CaseStatus? = null
    private var showTests = true
    private var year = LocalDate.now().year
    private val es = Locale("es", "ES")
    private val refresher = Runnable { if (tab != 2) render() else updateHeader() }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Repo.init(this)
        tab = intent.getIntExtra(EXTRA_TAB, 0)
        actionBar?.hide()

        val root = vbox().apply { setBackgroundColor(C.BG) }

        // Cabecera
        val header = hbox().apply {
            setBackgroundColor(C.DARK)
            setPadding(dp(16), dp(14), dp(16), dp(14))
        }
        header.addView(ImageView(this).apply { setImageResource(R.drawable.logo_blanco) }, lp(dp(46), dp(46)).apply { rightMargin = dp(12) })
        val titles = vbox()
        titles.addView(tv("The Mechanic", 20f, Color.WHITE, bold = true))
        titles.addView(tv("Automoción · Asistente de WhatsApp", 12f, Color.parseColor("#D1D5DB")))
        header.addView(titles, lp(0, -2, 1f))
        botPill = pill("", C.GREEN)
        header.addView(botPill)
        root.addView(header)

        content = FrameLayout(this)
        root.addView(content, lp(-1, 0, 1f))

        // Pestañas inferiores
        val bar = hbox().apply { setBackgroundColor(Color.WHITE); elevation = dp(8).toFloat() }
        tabs = listOf("🗂️\nCasos", "📅\nCalendario", "⚙️\nAjustes").mapIndexed { i, label ->
            tv(label, 13f, C.MUTED).apply {
                gravity = Gravity.CENTER
                setPadding(0, dp(8), 0, dp(8))
                setOnClickListener { tab = i; render() }
            }
        }
        tabs.forEach { bar.addView(it, lp(0, -2, 1f)) }
        root.addView(bar)

        setContentView(root)
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        tab = intent.getIntExtra(EXTRA_TAB, tab)
        render()
    }

    override fun onResume() {
        super.onResume()
        Repo.addListener(refresher)
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
        }
        render()
    }

    override fun onPause() {
        Repo.removeListener(refresher)
        super.onPause()
    }

    private fun updateHeader() {
        val listening = WhatsAppListener.isEnabled(this)
        val (text, color) = when {
            !AppSettings.botEnabled -> "Bot apagado" to C.MUTED
            !listening -> "Sin permiso" to C.RED
            else -> "Bot activo" to C.GREEN
        }
        botPill.text = text
        botPill.background = rounded(color, dp(20).toFloat())
    }

    private fun render() {
        updateHeader()
        tabs.forEachIndexed { i, t ->
            t.setTextColor(if (i == tab) C.INK else C.MUTED)
            t.setTypeface(null, if (i == tab) android.graphics.Typeface.BOLD else android.graphics.Typeface.NORMAL)
            t.setBackgroundColor(if (i == tab) C.ACCENT_SOFT else Color.WHITE)
        }
        content.removeAllViews()
        content.addView(
            when (tab) {
                0 -> casesView()
                1 -> calendarView()
                else -> settingsView()
            },
        )
    }

    private fun scroll(inner: View): ScrollView = ScrollView(this).apply {
        isFillViewport = true
        addView(inner)
    }

    // =====================================================================
    // CASOS
    // =====================================================================

    private fun casesView(): View {
        val box = vbox(14)

        if (!WhatsAppListener.isEnabled(this)) {
            val warn = card().apply { background = rounded(Color.parseColor("#FEE2E2"), dp(14).toFloat()) }
            warn.addView(tv("⚠️ El bot no puede leer WhatsApp todavía", 15f, C.RED, bold = true))
            warn.addView(tv("Dale acceso a las notificaciones para que pueda leer y responder los mensajes.", 13f, C.INK))
            warn.addSpaced(btn("Dar acceso a notificaciones") { openListenerSettings() }, 8)
            box.addView(warn)
            box.addView(space(12))
        }

        // Filtros
        val chips = hbox()
        val options: List<Pair<String, CaseStatus?>> = listOf("Todos" to null) + listOf(
            CaseStatus.URGENT, CaseStatus.NEEDS_CONTACT, CaseStatus.PENDING, CaseStatus.SCHEDULED, CaseStatus.IN_PROGRESS, CaseStatus.CLOSED,
        ).map { shortLabel(it) to it }
        val all = Repo.profilesSorted()
        options.forEach { (label, st) ->
            val count = if (st == null) all.count { it.status != CaseStatus.CLOSED } else all.count { it.status == st }
            val selected = filter == st
            chips.addView(tv("$label ($count)", 13f, if (selected) Color.WHITE else C.INK, bold = selected).apply {
                background = rounded(if (selected) C.DARK else Color.WHITE, dp(20).toFloat(), dp(1), C.LINE)
                setPadding(dp(12), dp(6), dp(12), dp(6))
                setOnClickListener { filter = st; render() }
            }, lp(-2, -2).apply { rightMargin = dp(6) })
        }
        box.addView(HorizontalScrollView(this).apply { isHorizontalScrollBarEnabled = false; addView(chips) })

        val list = all.filter { p ->
            (filter == null && p.status != CaseStatus.CLOSED || p.status == filter) && (showTests || !p.isTest)
        }
        box.addSpaced(
            tv("Ordenados por llegada (del primero al último) · ${list.size} caso(s)", 12f, C.MUTED), 10,
        )
        if (list.isEmpty()) {
            box.addSpaced(tv("No hay casos aquí todavía.\nCuando un cliente escriba por WhatsApp aparecerá su perfil.", 14f, C.MUTED).apply {
                gravity = Gravity.CENTER; setPadding(0, dp(40), 0, dp(40))
            })
        }
        list.forEach { p -> box.addSpaced(caseCard(p, all.indexOf(p) + 1), 10) }
        return scroll(box)
    }

    private fun shortLabel(s: CaseStatus) = when (s) {
        CaseStatus.URGENT -> "🚨 Grúa"
        CaseStatus.NEEDS_CONTACT -> "👤 Contactar"
        CaseStatus.PENDING -> "🆕 Pendientes"
        CaseStatus.SCHEDULED -> "📅 Con cita"
        CaseStatus.IN_PROGRESS -> "💬 En curso"
        CaseStatus.CLOSED -> "✔️ Cerrados"
    }

    private fun caseCard(p: Profile, number: Int): View {
        val c = card()
        val top = hbox()
        top.addView(tv("#$number · ${Fmt.dateTime(p.createdAt)}", 12f, C.MUTED), lp(0, -2, 1f))
        if (p.isTest) top.addView(pill("PRUEBA", C.PURPLE), lp(-2, -2).apply { rightMargin = dp(6) })
        top.addView(pill(p.status.label, C.status(p.status)))
        c.addView(top)
        c.addSpaced(tv(p.name.ifBlank { p.waName.ifBlank { "Cliente sin nombre" } }, 17f, bold = true), 6)
        val vehicle = p.vehicleLine()
        if (vehicle.isNotBlank()) c.addView(tv("🚗 $vehicle", 14f))
        if (p.phone.isNotBlank()) c.addView(tv("📞 ${p.phone}", 14f, C.MUTED))
        if (p.services.isNotEmpty()) c.addSpaced(tv("🔧 " + p.services.joinToString(" · "), 13f, C.INK), 4)
        val appts = Repo.appointmentsFor(p.id).filter { it.at >= System.currentTimeMillis() - 3600_000 }
        appts.firstOrNull()?.let { c.addSpaced(tv("📅 Cita: ${Fmt.dateTime(it.at)}", 13f, C.GREEN, bold = true), 4) }
        if (Repo.isBotPaused(p)) c.addView(tv("⏸️ Bot en pausa en este chat", 12f, C.ACCENT, bold = true))
        c.setOnClickListener { openProfile(p.id) }
        return c
    }

    private fun openProfile(id: String) {
        startActivity(Intent(this, ProfileActivity::class.java).putExtra(ProfileActivity.EXTRA_ID, id))
    }

    // =====================================================================
    // CALENDARIO (todo el año)
    // =====================================================================

    private fun calendarView(): View {
        val box = vbox(14)

        val nav = hbox()
        nav.addView(btn("◀", 1) { year--; render() })
        nav.addView(tv("$year", 22f, bold = true).apply { gravity = Gravity.CENTER }, lp(0, -2, 1f))
        nav.addView(btn("▶", 1) { year++; render() })
        box.addView(nav)
        box.addSpaced(btn("➕ Nueva cita") { pickDate { d -> addAppointmentFlow(d) } }, 8)

        // Próximas citas
        val next = Repo.upcoming(8)
        val upc = card()
        upc.addView(tv("Próximas citas", 16f, bold = true))
        if (next.isEmpty()) upc.addView(tv("No hay citas programadas.", 14f, C.MUTED))
        next.forEach { a -> upc.addSpaced(appointmentRow(a), 6) }
        box.addSpaced(upc, 12)

        // Meses
        val apptDays = Repo.allAppointments().groupBy { Repo.dateOf(it.at) }
        val width = resources.configuration.screenWidthDp
        val cols = when { width >= 1000 -> 4; width >= 700 -> 3; width >= 380 -> 2; else -> 1 }
        var row: LinearLayout? = null
        for (m in 1..12) {
            if ((m - 1) % cols == 0) {
                val r = hbox().apply { gravity = Gravity.TOP }
                row = r
                box.addSpaced(r, 10)
            }
            row?.addView(monthView(YearMonth.of(year, m), apptDays), lp(0, -2, 1f).apply { leftMargin = dp(3); rightMargin = dp(3) })
        }
        // Huecos para que la última fila no se estire
        val remaining = (cols - 12 % cols) % cols
        repeat(remaining) { row?.addView(View(this), lp(0, 1, 1f)) }

        box.addSpaced(tv("Toca un día para ver o añadir citas. Los días marcados en ámbar tienen citas.", 12f, C.MUTED), 10)
        return scroll(box)
    }

    private fun monthView(ym: YearMonth, apptDays: Map<LocalDate, List<Appointment>>): View {
        val c = vbox(8).apply { background = rounded(Color.WHITE, dp(12).toFloat()) }
        val name = ym.month.getDisplayName(TextStyle.FULL_STANDALONE, es).replaceFirstChar { it.titlecase(es) }
        c.addView(tv(name, 14f, bold = true).apply { gravity = Gravity.CENTER })
        val head = hbox()
        listOf("L", "M", "X", "J", "V", "S", "D").forEach {
            head.addView(tv(it, 11f, C.MUTED).apply { gravity = Gravity.CENTER }, lp(0, -2, 1f))
        }
        c.addView(head)
        val today = LocalDate.now()
        val first = ym.atDay(1)
        val offset = first.dayOfWeek.value - 1
        val days = ym.lengthOfMonth()
        var day = 1 - offset
        while (day <= days) {
            val week = hbox()
            for (i in 0 until 7) {
                val cell = TextView(this).apply {
                    gravity = Gravity.CENTER
                    textSize = 12f
                    setPadding(0, dp(5), 0, dp(5))
                }
                if (day in 1..days) {
                    val date = ym.atDay(day)
                    val count = apptDays[date]?.size ?: 0
                    cell.text = "$day"
                    when {
                        count > 0 -> {
                            cell.background = rounded(C.ACCENT, dp(8).toFloat())
                            cell.setTextColor(C.INK)
                            cell.setTypeface(null, android.graphics.Typeface.BOLD)
                        }
                        date == today -> {
                            cell.background = rounded(Color.TRANSPARENT, dp(8).toFloat(), dp(2), C.DARK)
                            cell.setTextColor(C.INK)
                        }
                        else -> cell.setTextColor(if (i >= 5) C.MUTED else C.INK)
                    }
                    if (date == today && count > 0) cell.background = rounded(C.ACCENT, dp(8).toFloat(), dp(2), C.DARK)
                    cell.setOnClickListener { showDay(date) }
                }
                week.addView(cell, lp(0, -2, 1f).apply { setMargins(dp(1), dp(1), dp(1), dp(1)) })
                day++
            }
            c.addView(week)
        }
        return c
    }

    private fun appointmentRow(a: Appointment): View {
        val p = Repo.profile(a.profileId)
        val r = hbox().apply {
            background = rounded(C.BG, dp(10).toFloat())
            setPadding(dp(10), dp(8), dp(10), dp(8))
        }
        r.addView(tv(Fmt.short(a.at), 13f, C.DARK, bold = true), lp(-2, -2).apply { rightMargin = dp(10) })
        val who = p?.let { listOf(it.name, it.vehicleLine()).filter { s -> s.isNotBlank() }.joinToString(" · ") } ?: a.title
        r.addView(tv(who, 13f), lp(0, -2, 1f))
        r.setOnClickListener { if (p != null) openProfile(p.id) else appointmentOptions(a) }
        return r
    }

    private fun showDay(date: LocalDate) {
        val list = Repo.appointmentsOn(date)
        val b = AlertDialog.Builder(this).setTitle(Fmt.longDate(date))
        if (list.isEmpty()) {
            b.setMessage("No hay citas este día.")
        } else {
            val labels = list.map { a ->
                val p = Repo.profile(a.profileId)
                "${Fmt.time(a.at)} · " + (p?.let { listOf(it.name, it.vehicleLine()).filter { s -> s.isNotBlank() }.joinToString(" – ") } ?: a.title)
            }.toTypedArray()
            b.setItems(labels) { _, i ->
                val a = list[i]
                if (a.profileId != null && Repo.profile(a.profileId) != null) openProfile(a.profileId!!) else appointmentOptions(a)
            }
        }
        b.setPositiveButton("➕ Añadir cita") { _, _ -> addAppointmentFlow(date) }
        b.setNegativeButton("Cerrar", null)
        b.show()
    }

    private fun appointmentOptions(a: Appointment) {
        AlertDialog.Builder(this)
            .setTitle(a.title)
            .setMessage(Fmt.longDateTime(a.at) + if (a.notes.isNotBlank()) "\n\n${a.notes}" else "")
            .setPositiveButton("Cerrar", null)
            .setNegativeButton("Eliminar cita") { _, _ -> Repo.deleteAppointment(a.id); render() }
            .show()
    }

    private fun pickDate(onPicked: (LocalDate) -> Unit) {
        val t = LocalDate.now()
        android.app.DatePickerDialog(this, { _, y, m, d -> onPicked(LocalDate.of(y, m + 1, d)) }, t.year, t.monthValue - 1, t.dayOfMonth).show()
    }

    /** Elegir a qué caso pertenece la cita (o una cita libre) y la hora. */
    private fun addAppointmentFlow(date: LocalDate) {
        val candidates = Repo.profilesSorted().filter { it.status != CaseStatus.CLOSED }
        val labels = candidates.map { p ->
            "${p.name.ifBlank { p.waName }} · ${p.vehicleLine()} (${p.status.label})"
        } + "✏️ Otra cita (sin caso)"
        AlertDialog.Builder(this)
            .setTitle("¿Para qué caso es la cita?")
            .setItems(labels.toTypedArray()) { _, i ->
                if (i < candidates.size) {
                    val p = candidates[i]
                    pickTime(date) { at -> ProfileActivity.afterAppointment(this, p, Repo.addAppointment(p.id, p.name, at)) { render() } }
                } else {
                    val input = EditText(this).apply { hint = "Ej.: Revisión coche de Antonio" }
                    AlertDialog.Builder(this)
                        .setTitle("Descripción de la cita")
                        .setView(input)
                        .setPositiveButton("Siguiente") { _, _ ->
                            val title = input.text.toString().ifBlank { "Cita" }
                            pickTime(date) { at -> Repo.addAppointment(null, title, at); render(); toast("Cita guardada") }
                        }
                        .setNegativeButton("Cancelar", null)
                        .show()
                }
            }
            .setNegativeButton("Cancelar", null)
            .show()
    }

    private fun pickTime(date: LocalDate, onPicked: (Long) -> Unit) {
        TimePickerDialog(this, { _, h, m ->
            onPicked(date.atTime(LocalTime.of(h, m)).atZone(ZoneId.systemDefault()).toInstant().toEpochMilli())
        }, 9, 0, true).show()
    }

    // =====================================================================
    // AJUSTES
    // =====================================================================

    private fun settingsView(): View {
        val box = vbox(14)

        // Estado y permisos
        val st = card()
        st.addView(tv("Estado del bot", 16f, bold = true))
        st.addSpaced(Switch(this).apply {
            text = "Bot activado (responde automáticamente)"
            textSize = 15f
            isChecked = AppSettings.botEnabled
            setOnCheckedChangeListener { _, on -> AppSettings.botEnabled = on; updateHeader() }
        }, 8)
        val listening = WhatsAppListener.isEnabled(this)
        st.addSpaced(tv(if (listening) "✅ Acceso a notificaciones: concedido" else "❌ Acceso a notificaciones: NO concedido", 14f, if (listening) C.GREEN else C.RED, bold = true), 8)
        st.addSpaced(btn(if (listening) "Revisar acceso a notificaciones" else "Dar acceso a notificaciones", if (listening) 1 else 0) { openListenerSettings() }, 6)

        val pm = getSystemService(PowerManager::class.java)
        val batteryOk = pm.isIgnoringBatteryOptimizations(packageName)
        st.addSpaced(tv(if (batteryOk) "✅ Sin restricciones de batería" else "⚠️ Android puede dormir la app para ahorrar batería", 14f, if (batteryOk) C.GREEN else C.ACCENT, bold = true), 10)
        if (!batteryOk) st.addSpaced(btn("Quitar restricción de batería") { askBattery() }, 6)

        if (Build.VERSION.SDK_INT >= 31) {
            val am = getSystemService(AlarmManager::class.java)
            if (!am.canScheduleExactAlarms()) {
                st.addSpaced(tv("⚠️ Los recordatorios pueden llegar con algo de retraso", 14f, C.ACCENT, bold = true), 10)
                st.addSpaced(btn("Permitir alarmas exactas") {
                    runCatching { startActivity(Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM, Uri.parse("package:$packageName"))) }
                }, 6)
            }
        }
        st.addSpaced(CheckBox(this).apply {
            text = "Responder también en WhatsApp normal (no Business)"
            isChecked = AppSettings.watchPersonal
            setOnCheckedChangeListener { _, on -> AppSettings.watchPersonal = on }
        }, 8)
        box.addView(st)

        // Datos del taller
        val data = card()
        data.addView(tv("Datos del taller", 16f, bold = true))
        data.addView(tv("Se usan en los mensajes del bot (horario y dirección, cuando el cliente pregunta).", 12f, C.MUTED))
        val fName = field(data, "Nombre del taller", AppSettings.tallerName)
        val fPhone = field(data, "Teléfono del taller (para urgencias)", AppSettings.tallerPhone, InputType.TYPE_CLASS_PHONE)
        val fHours = field(data, "Horario (ej.: L-V 8:30–14:00 y 16:00–19:00)", AppSettings.hours)
        val fAddr = field(data, "Dirección", AppSettings.address)
        data.addSpaced(btn("Guardar datos del taller") {
            AppSettings.tallerName = fName.text.toString().trim()
            AppSettings.tallerPhone = fPhone.text.toString().trim()
            AppSettings.hours = fHours.text.toString().trim()
            AppSettings.address = fAddr.text.toString().trim()
            toast("Guardado")
        }, 10)
        box.addSpaced(data, 12)

        // Recordatorios
        val rem = card()
        rem.addView(tv("Recordatorios de citas", 16f, bold = true))
        rem.addView(tv("La app te avisará antes de cada cita del calendario.", 12f, C.MUTED))
        reminderSpinner(rem, "Primer aviso", AppSettings.reminder1) { AppSettings.reminder1 = it }
        reminderSpinner(rem, "Segundo aviso", AppSettings.reminder2) { AppSettings.reminder2 = it }
        box.addSpaced(rem, 12)

        // Herramientas
        val tools = card()
        tools.addView(tv("Herramientas", 16f, bold = true))
        tools.addSpaced(btn("💬 Probar el bot (simulador)", 3) { startActivity(Intent(this, SimulatorActivity::class.java)) }, 8)
        tools.addSpaced(btn("📤 Exportar casos (CSV)", 1) { exportCsv() }, 8)
        tools.addSpaced(CheckBox(this).apply {
            text = "Mostrar casos de prueba en la lista"
            isChecked = showTests
            setOnCheckedChangeListener { _, on -> showTests = on }
        }, 8)
        tools.addSpaced(btn("🧹 Borrar casos de prueba", 2) {
            AlertDialog.Builder(this).setMessage("¿Borrar todos los casos creados con el simulador?")
                .setPositiveButton("Borrar") { _, _ -> Repo.clearTests(); toast("Casos de prueba borrados") }
                .setNegativeButton("Cancelar", null).show()
        }, 8)
        box.addSpaced(tools, 12)

        box.addSpaced(tv("Todos los datos se guardan solo en este dispositivo. El bot funciona mientras el dispositivo esté encendido y con conexión.", 12f, C.MUTED), 12)
        return scroll(box)
    }

    private fun field(parent: LinearLayout, label: String, value: String, type: Int = InputType.TYPE_CLASS_TEXT): EditText {
        parent.addSpaced(tv(label, 13f, C.MUTED), 10)
        val e = EditText(this).apply {
            setText(value)
            inputType = type
            textSize = 15f
        }
        parent.addView(e, lp())
        return e
    }

    private fun reminderSpinner(parent: LinearLayout, label: String, current: Int, onChange: (Int) -> Unit) {
        parent.addSpaced(tv(label, 13f, C.MUTED), 10)
        val choices = AppSettings.REMINDER_CHOICES
        val sp = Spinner(this)
        sp.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, choices.map { AppSettings.reminderLabel(it) })
        sp.setSelection(choices.indexOf(current).coerceAtLeast(0), false)
        sp.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(parentView: AdapterView<*>?, view: View?, position: Int, id: Long) {
                if (choices[position] != current) {
                    onChange(choices[position])
                    Reminders.rescheduleAll(this@MainActivity)
                    toast("Recordatorios actualizados")
                }
            }
            override fun onNothingSelected(parentView: AdapterView<*>?) {}
        }
        parent.addView(sp, lp())
    }

    private fun openListenerSettings() {
        runCatching { startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS)) }
            .onFailure { toast("Abre Ajustes > Notificaciones > Acceso a notificaciones") }
    }

    private fun askBattery() {
        runCatching {
            startActivity(Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:$packageName")))
        }.onFailure {
            runCatching { startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS)) }
        }
    }

    private fun exportCsv() {
        val send = Intent(Intent.ACTION_SEND).apply {
            type = "text/plain"
            putExtra(Intent.EXTRA_SUBJECT, "Casos The Mechanic Automoción")
            putExtra(Intent.EXTRA_TEXT, Repo.exportCsv())
        }
        startActivity(Intent.createChooser(send, "Exportar casos"))
    }

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()
}

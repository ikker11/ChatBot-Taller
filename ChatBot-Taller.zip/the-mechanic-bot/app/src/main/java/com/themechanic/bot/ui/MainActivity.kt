package com.themechanic.bot.ui

import android.Manifest
import android.app.Activity
import android.app.AlarmManager
import android.app.AlertDialog
import android.app.TimePickerDialog
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.PowerManager
import android.provider.Settings
import android.text.Editable
import android.text.InputType
import android.text.TextUtils
import android.text.TextWatcher
import android.view.Gravity
import android.view.View
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import com.themechanic.bot.R
import com.themechanic.bot.data.AppSettings
import com.themechanic.bot.data.Appointment
import com.themechanic.bot.data.Fmt
import com.themechanic.bot.data.Repo
import com.themechanic.bot.engine.CaseStatus
import com.themechanic.bot.engine.Profile
import com.themechanic.bot.notify.Reminders
import com.themechanic.bot.service.WhatsAppListener
import java.time.LocalDate
import java.time.LocalTime
import java.time.YearMonth
import java.time.ZoneId
import java.time.format.TextStyle
import java.util.Locale

class MainActivity : Activity() {

    companion object {
        const val EXTRA_TAB = "tab"
        const val VERSION = "1.1"
    }

    private lateinit var content: FrameLayout
    private lateinit var tabBar: LinearLayout
    private var tab = 0
    private var filter = 0
    private var year = LocalDate.now().year
    private var selectedDate: LocalDate = LocalDate.now()
    private val es = Locale("es", "ES")
    private val refresher = Runnable { if (tab != 2) render() }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Repo.init(this)
        iosWindow()
        tab = intent.getIntExtra(EXTRA_TAB, 0)

        val root = vbox().apply { setBackgroundColor(C.BG) }
        content = FrameLayout(this)
        root.addView(content, lp(-1, 0, 1f))

        val bar = vbox().apply { setBackgroundColor(Color.parseColor("#F9F9F9")) }
        bar.addView(View(this).apply { setBackgroundColor(C.SEPARATOR) }, lp(-1, hairline()))
        tabBar = hbox().apply { setPadding(0, dp(6), 0, dp(6)) }
        bar.addView(tabBar)
        root.addView(bar)
        setContentView(root)
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        tab = intent.getIntExtra(EXTRA_TAB, tab)
        render()
    }

    override fun onResume() {
        super.onResume()
        Repo.addListener(refresher)
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
        }
        render()
    }

    override fun onPause() {
        Repo.removeListener(refresher)
        super.onPause()
    }

    private fun render() {
        renderTabBar()
        content.removeAllViews()
        content.addView(
            when (tab) {
                0 -> casesView()
                1 -> calendarView()
                else -> settingsView()
            },
        )
    }

    private fun renderTabBar() {
        tabBar.removeAllViews()
        listOf(
            Triple("Casos", R.drawable.ic_inbox, 0),
            Triple("Calendario", R.drawable.ic_calendar, 1),
            Triple("Ajustes", R.drawable.ic_settings, 2),
        ).forEach { (label, res, i) ->
            val color = if (i == tab) C.TINT else C.GRAY
            val item = vbox().apply {
                gravity = Gravity.CENTER_HORIZONTAL
                addView(icon(res, color, 26), LinearLayout.LayoutParams(dp(26), dp(26)).apply { gravity = Gravity.CENTER_HORIZONTAL })
                addView(tv(label, 11f, color, if (i == tab) 1 else 0).apply { gravity = Gravity.CENTER }, lp(-2, -2).apply { gravity = Gravity.CENTER_HORIZONTAL })
                setOnClickListener { if (tab != i) { tab = i; render() } }
            }
            tabBar.addView(item, lp(0, -2, 1f))
        }
    }

    private fun page(inner: LinearLayout): ScrollView = ScrollView(this).apply {
        isFillViewport = true
        isVerticalScrollBarEnabled = false
        setBackgroundColor(C.BG)
        addView(inner)
    }

    private fun pageBox(): LinearLayout = vbox().apply {
        setPadding(dp(16), dp(12), dp(16), dp(28))
    }

    /** Cabecera con título grande y, a la derecha, el estado del bot. */
    private fun header(box: LinearLayout, title: String, right: View? = null) {
        val top = hbox()
        top.addView(ImageView(this).apply { setImageResource(R.drawable.logo_negro) }, lp(dp(22), dp(22)).apply { rightMargin = dp(6) })
        top.addView(tv("The Mechanic Automoción", 13f, C.SECONDARY, 1), lp(0, -2, 1f))
        top.addView(botStatusChip())
        box.addView(top)
        val t = hbox()
        t.addView(largeTitle(title), lp(0, -2, 1f))
        right?.let { t.addView(it) }
        box.addSpaced(t, 6)
    }

    private fun botStatusChip(): View {
        val listening = WhatsAppListener.isEnabled(this)
        val (text, color) = when {
            !AppSettings.botEnabled -> "Bot apagado" to C.GRAY
            !listening -> "Sin permiso" to C.RED
            else -> "Bot activo" to C.GREEN
        }
        return hbox().apply {
            background = rounded(alpha(color, 0.12f), dp(12).toFloat())
            setPadding(dp(8), dp(3), dp(10), dp(3))
            addView(View(context).apply { background = oval(color) }, lp(dp(7), dp(7)).apply { rightMargin = dp(5) })
            addView(tv(text, 12f, color, 1))
            setOnClickListener { tab = 2; render() }
        }
    }

    // =====================================================================
    // CASOS
    // =====================================================================

    private val filters = listOf("Activos", "Contactar", "Con cita", "Cerrados")

    private fun matchesFilter(p: Profile): Boolean = when (filter) {
        0 -> p.status != CaseStatus.CLOSED
        1 -> p.status == CaseStatus.NEEDS_CONTACT || p.status == CaseStatus.URGENT
        2 -> p.status == CaseStatus.SCHEDULED
        else -> p.status == CaseStatus.CLOSED
    }

    private fun casesView(): View {
        val box = pageBox()
        header(box, "Casos")

        if (!WhatsAppListener.isEnabled(this)) {
            val g = group()
            g.addRow(row("Activa el acceso a notificaciones", subtitle = "Necesario para que el bot lea y responda WhatsApp",
                iconRes = R.drawable.ic_bell, iconBg = C.RED, chevron = true) { openListenerSettings() })
            box.addSpaced(g, 14)
        }

        val showTests = Repo.prefs().getBoolean("mostrarPruebas", true)
        val all = Repo.profilesSorted().filter { showTests || !it.isTest }

        // Resumen tipo widgets
        val today = LocalDate.now()
        val stats = hbox()
        val urgent = all.count { it.status == CaseStatus.URGENT || it.status == CaseStatus.NEEDS_CONTACT }
        val pending = all.count { it.status == CaseStatus.PENDING || it.status == CaseStatus.IN_PROGRESS }
        val todayAppts = Repo.appointmentsOn(today).size
        stats.addView(statCard("$pending", "Pendientes", C.TINT) { filter = 0; render() }, lp(0, -2, 1f).apply { rightMargin = dp(8) })
        stats.addView(statCard("$urgent", "Por contactar", if (urgent > 0) C.ORANGE else C.GRAY) { filter = 1; render() }, lp(0, -2, 1f).apply { rightMargin = dp(8) })
        stats.addView(statCard("$todayAppts", "Citas hoy", C.GREEN) { tab = 1; selectedDate = today; year = today.year; render() }, lp(0, -2, 1f))
        box.addSpaced(stats, 14)

        box.addSpaced(segmented(filters, filter) { filter = it; render() }, 16)

        val list = all.filter { matchesFilter(it) }
        if (list.isEmpty()) {
            val empty = vbox().apply { gravity = Gravity.CENTER_HORIZONTAL; setPadding(dp(24), dp(56), dp(24), dp(40)) }
            empty.addView(icon(R.drawable.ic_inbox, C.TERTIARY, 56), LinearLayout.LayoutParams(dp(56), dp(56)).apply { gravity = Gravity.CENTER_HORIZONTAL })
            empty.addSpaced(tv("No hay casos", 20f, C.LABEL, 1).apply { gravity = Gravity.CENTER }, 12)
            empty.addSpaced(tv(if (filter == 0) "Cuando un cliente escriba por WhatsApp aparecerá aquí su perfil." else "No hay casos en esta categoría.", 15f, C.SECONDARY).apply { gravity = Gravity.CENTER }, 6)
            box.addView(empty)
            return page(box)
        }

        // Agrupados por día, del primero al último
        list.groupBy { Repo.dateOf(it.createdAt) }.toSortedMap().forEach { (date, items) ->
            box.addView(sectionHeader(dayLabel(date)).apply { setPadding(dp(16), dp(22), dp(16), dp(7)) })
            val g = group()
            items.forEach { p -> g.addRow(caseRow(p, all.indexOf(p) + 1), 72) }
            box.addView(g)
        }
        box.addView(sectionFooter("Ordenados por orden de llegada, del primero al último."))
        return page(box)
    }

    private fun statCard(number: String, label: String, color: Int, onClick: () -> Unit): View = vbox().apply {
        background = pressable(C.CARD, C.PRESSED, dp(12).toFloat())
        setPadding(dp(14), dp(12), dp(12), dp(12))
        addView(tv(number, 26f, color, 2))
        addView(tv(label, 13f, C.SECONDARY, 1).apply { maxLines = 1; ellipsize = TextUtils.TruncateAt.END })
        setOnClickListener { onClick() }
    }

    private fun dayLabel(d: LocalDate): String {
        val today = LocalDate.now()
        return when (d) {
            today -> "Hoy · " + Fmt.longDate(d).substringAfter(" ").substringBefore(" de 20")
            today.minusDays(1) -> "Ayer · " + Fmt.longDate(d).substringAfter(" ").substringBefore(" de 20")
            else -> Fmt.longDate(d)
        }
    }

    private fun caseRow(p: Profile, number: Int): View {
        val name = p.name.ifBlank { p.waName.ifBlank { "Cliente sin nombre" } }
        val color = C.status(p.status)
        val r = hbox().apply {
            setPadding(dp(16), dp(12), dp(12), dp(12))
            background = pressable(Color.TRANSPARENT, C.PRESSED, 0f)
            setOnClickListener { openProfile(p.id) }
        }
        r.addView(avatar(name, color, 44), LinearLayout.LayoutParams(dp(44), dp(44)).apply { rightMargin = dp(12) })
        val mid = vbox()
        val l1 = hbox()
        l1.addView(tv(name, 16f, C.LABEL, 1).apply { maxLines = 1; ellipsize = TextUtils.TruncateAt.END }, lp(0, -2, 1f))
        l1.addView(tv("#$number · ${Fmt.time(p.createdAt)}", 13f, C.SECONDARY))
        mid.addView(l1)
        val vehicle = p.vehicleLine()
        if (vehicle.isNotBlank()) mid.addView(tv(vehicle, 14f, C.SECONDARY).apply { maxLines = 1; ellipsize = TextUtils.TruncateAt.END })
        val l3 = hbox().apply { setPadding(0, dp(4), 0, 0) }
        l3.addView(badge(C.shortStatus(p.status), color))
        if (p.isTest) l3.addView(badge("Prueba", C.INDIGO), lp(-2, -2).apply { leftMargin = dp(6) })
        val next = Repo.appointmentsFor(p.id).firstOrNull { it.at >= System.currentTimeMillis() - 3600_000 }
        val extra = when {
            next != null -> "📅 " + Fmt.short(next.at)
            p.services.isNotEmpty() -> p.services.joinToString(" · ") { it.substringAfterLast("› ") }
            else -> ""
        }
        if (extra.isNotBlank()) l3.addView(tv(extra, 13f, C.SECONDARY).apply { maxLines = 1; ellipsize = TextUtils.TruncateAt.END }, lp(0, -2, 1f).apply { leftMargin = dp(8) })
        mid.addView(l3)
        r.addView(mid, lp(0, -2, 1f))
        r.addView(icon(R.drawable.ic_chevron_right, C.TERTIARY, 20), lp(dp(20), dp(20)).apply { leftMargin = dp(6) })
        return r
    }

    private fun openProfile(id: String) {
        startActivity(Intent(this, ProfileActivity::class.java).putExtra(ProfileActivity.EXTRA_ID, id))
    }

    // =====================================================================
    // CALENDARIO
    // =====================================================================

    private fun calendarView(): View {
        val box = pageBox()
        val add = FrameLayout(this).apply {
            background = pressable(alpha(C.TINT, 0.12f), alpha(C.TINT, 0.22f), dp(18).toFloat())
            addView(icon(R.drawable.ic_add, C.TINT, 22), FrameLayout.LayoutParams(dp(22), dp(22), Gravity.CENTER))
            setOnClickListener { addAppointmentFlow(selectedDate) }
        }
        header(box, "Calendario", add.also { it.layoutParams = LinearLayout.LayoutParams(dp(36), dp(36)) })

        // Navegación de año
        val nav = hbox()
        nav.addView(textButton("‹ ${year - 1}") { year--; render() })
        nav.addView(tv("$year", 22f, C.LABEL, 2).apply { gravity = Gravity.CENTER }, lp(0, -2, 1f))
        nav.addView(textButton("${year + 1} ›") { year++; render() })
        box.addSpaced(nav, 6)

        // Agenda del día seleccionado
        val dayAppts = Repo.appointmentsOn(selectedDate)
        val todayTag = if (selectedDate == LocalDate.now()) " · Hoy" else ""
        box.addView(sectionHeader(Fmt.longDate(selectedDate) + todayTag))
        val agenda = group()
        if (dayAppts.isEmpty()) agenda.addRow(row("Sin citas este día", titleColor = C.SECONDARY))
        dayAppts.forEach { a -> agenda.addRow(appointmentRow(a), 76) }
        agenda.addRow(row("Añadir cita", iconRes = R.drawable.ic_add, iconBg = C.TINT, titleColor = C.TINT) { addAppointmentFlow(selectedDate) })
        box.addView(agenda)

        // Próximas
        val next = Repo.upcoming(5).filter { Repo.dateOf(it.at) != selectedDate }
        if (next.isNotEmpty()) {
            box.addView(sectionHeader("Próximas citas"))
            val g = group()
            next.forEach { a -> g.addRow(appointmentRow(a, showDate = true), 76) }
            box.addView(g)
        }

        // Año completo
        box.addView(sectionHeader("Año $year"))
        val apptDays = Repo.allAppointments().groupBy { Repo.dateOf(it.at) }
        val width = resources.configuration.screenWidthDp
        val cols = when { width >= 1000 -> 4; width >= 680 -> 3; else -> 2 }
        var row: LinearLayout? = null
        for (m in 1..12) {
            if ((m - 1) % cols == 0) {
                val r = hbox().apply { gravity = Gravity.TOP }
                row = r
                box.addSpaced(r, if (m == 1) 0 else 10)
            }
            row?.addView(monthView(YearMonth.of(year, m), apptDays), lp(0, -2, 1f).apply { leftMargin = dp(4); rightMargin = dp(4) })
        }
        val remaining = (cols - 12 % cols) % cols
        repeat(remaining) { row?.addView(View(this), lp(0, 1, 1f)) }
        box.addView(sectionFooter("Toca un día para ver su agenda. Los días en azul tienen citas; hoy aparece en rojo."))
        return page(box)
    }

    private fun appointmentRow(a: Appointment, showDate: Boolean = false): View {
        val p = Repo.profile(a.profileId)
        val r = hbox().apply {
            setPadding(dp(16), dp(10), dp(12), dp(10))
            background = pressable(Color.TRANSPARENT, C.PRESSED, 0f)
            setOnClickListener { if (p != null) openProfile(p.id) else appointmentOptions(a) }
        }
        val time = vbox().apply { gravity = Gravity.CENTER_HORIZONTAL }
        time.addView(tv(Fmt.time(a.at), 16f, C.TINT, 1))
        if (showDate) time.addView(tv(Fmt.short(a.at).substringBefore(" "), 12f, C.SECONDARY))
        r.addView(time, lp(dp(60), -2))
        r.addView(View(this).apply { background = rounded(C.TINT, dp(2).toFloat()) }, lp(dp(3), dp(36)).apply { rightMargin = dp(12) })
        val mid = vbox()
        mid.addView(tv(p?.name?.ifBlank { p.waName } ?: a.title, 16f, C.LABEL, 1).apply { maxLines = 1; ellipsize = TextUtils.TruncateAt.END })
        val sub = p?.let { listOf(it.vehicleLine(), it.services.joinToString(", ") { s -> s.substringAfterLast("› ") }).filter { s -> s.isNotBlank() }.joinToString(" · ") } ?: "Cita sin caso"
        mid.addView(tv(sub, 13f, C.SECONDARY).apply { maxLines = 1; ellipsize = TextUtils.TruncateAt.END })
        r.addView(mid, lp(0, -2, 1f))
        r.addView(icon(R.drawable.ic_chevron_right, C.TERTIARY, 20), lp(dp(20), dp(20)))
        return r
    }

    private fun monthView(ym: YearMonth, apptDays: Map<LocalDate, List<Appointment>>): View {
        val today = LocalDate.now()
        val c = vbox().apply {
            background = rounded(C.CARD, dp(12).toFloat())
            setPadding(dp(8), dp(10), dp(8), dp(10))
        }
        val name = ym.month.getDisplayName(TextStyle.FULL_STANDALONE, es).replaceFirstChar { it.titlecase(es) }
        val isCurrent = ym == YearMonth.from(today)
        c.addView(tv(name, 15f, if (isCurrent) C.RED else C.LABEL, 2).apply { setPadding(dp(4), 0, 0, dp(4)) })
        val head = hbox()
        listOf("L", "M", "X", "J", "V", "S", "D").forEach {
            head.addView(tv(it, 10f, C.SECONDARY, 1).apply { gravity = Gravity.CENTER }, lp(0, -2, 1f))
        }
        c.addView(head)
        val offset = ym.atDay(1).dayOfWeek.value - 1
        val days = ym.lengthOfMonth()
        var day = 1 - offset
        while (day <= days) {
            val week = hbox()
            for (i in 0 until 7) {
                val cell = TextView(this).apply {
                    gravity = Gravity.CENTER
                    textSize = 12f
                    typeface = Fonts.regular
                    setPadding(0, dp(5), 0, dp(5))
                }
                if (day in 1..days) {
                    val date = ym.atDay(day)
                    val has = (apptDays[date]?.size ?: 0) > 0
                    cell.text = "$day"
                    cell.setTextColor(if (i >= 5) C.SECONDARY else C.LABEL)
                    when {
                        date == selectedDate -> {
                            cell.background = oval(if (date == today) C.RED else C.LABEL)
                            cell.setTextColor(Color.WHITE); cell.typeface = Fonts.medium
                        }
                        date == today -> { cell.setTextColor(C.RED); cell.typeface = Fonts.bold }
                        has -> { cell.background = oval(alpha(C.TINT, 0.16f)); cell.setTextColor(C.TINT); cell.typeface = Fonts.bold }
                    }
                    cell.setOnClickListener { selectedDate = date; render() }
                }
                week.addView(cell, lp(0, dp(28), 1f).apply { setMargins(dp(1), dp(1), dp(1), dp(1)) })
                day++
            }
            c.addView(week)
        }
        return c
    }

    private fun appointmentOptions(a: Appointment) {
        AlertDialog.Builder(this)
            .setTitle(a.title)
            .setMessage(Fmt.longDateTime(a.at) + if (a.notes.isNotBlank()) "\n\n${a.notes}" else "")
            .setPositiveButton("Cerrar", null)
            .setNegativeButton("Eliminar cita") { _, _ -> Repo.deleteAppointment(a.id); render() }
            .show()
    }

    /** Elegir a qué caso pertenece la cita (o una cita libre) y la hora. */
    private fun addAppointmentFlow(date: LocalDate) {
        val candidates = Repo.profilesSorted().filter { it.status != CaseStatus.CLOSED }
        val labels = candidates.map { p -> "${p.name.ifBlank { p.waName }} · ${p.vehicleLine()}" } + "✏️ Otra cita (sin caso)"
        AlertDialog.Builder(this)
            .setTitle("Cita para el ${Fmt.longDate(date)}")
            .setItems(labels.toTypedArray()) { _, i ->
                if (i < candidates.size) {
                    val p = candidates[i]
                    pickTime(date) { at -> ProfileActivity.afterAppointment(this, p, Repo.addAppointment(p.id, p.name, at)) { render() } }
                } else {
                    val input = EditText(this).apply { hint = "Ej.: Revisión coche de Antonio"; setPadding(dp(20), dp(16), dp(20), dp(16)) }
                    AlertDialog.Builder(this)
                        .setTitle("Descripción de la cita")
                        .setView(input)
                        .setPositiveButton("Siguiente") { _, _ ->
                            val title = input.text.toString().ifBlank { "Cita" }
                            pickTime(date) { at -> Repo.addAppointment(null, title, at); render(); toast("Cita guardada") }
                        }
                        .setNegativeButton("Cancelar", null)
                        .show()
                }
            }
            .setNegativeButton("Cancelar", null)
            .show()
    }

    private fun pickTime(date: LocalDate, onPicked: (Long) -> Unit) {
        TimePickerDialog(this, { _, h, m ->
            onPicked(date.atTime(LocalTime.of(h, m)).atZone(ZoneId.systemDefault()).toInstant().toEpochMilli())
        }, 9, 0, true).show()
    }

    // =====================================================================
    // AJUSTES
    // =====================================================================

    private fun settingsView(): View {
        val box = pageBox()
        header(box, "Ajustes")

        // Tarjeta del taller
        val card = group()
        val cardRow = hbox().apply { setPadding(dp(16), dp(14), dp(16), dp(14)) }
        cardRow.addView(FrameLayout(this).apply {
            background = oval(Color.WHITE)
            elevation = dp(2).toFloat()
            addView(ImageView(context).apply { setImageResource(R.drawable.logo_negro) }, FrameLayout.LayoutParams(dp(46), dp(46), Gravity.CENTER))
        }, lp(dp(62), dp(62)).apply { rightMargin = dp(14) })
        val cardText = vbox()
        cardText.addView(tv(AppSettings.tallerName, 20f, C.LABEL, 1))
        cardText.addView(tv("ChatBot-Taller · versión $VERSION", 14f, C.SECONDARY))
        cardRow.addView(cardText, lp(0, -2, 1f))
        card.addRow(cardRow)
        box.addSpaced(card, 14)

        // Bot
        val listening = WhatsAppListener.isEnabled(this)
        val pm = getSystemService(PowerManager::class.java)
        val batteryOk = pm.isIgnoringBatteryOptimizations(packageName)
        box.addView(sectionHeader("Asistente de WhatsApp"))
        val bot = group()
        bot.addRow(switchRow("Responder automáticamente", AppSettings.botEnabled, R.drawable.ic_chat, C.GREEN) { on ->
            AppSettings.botEnabled = on; render()
        }, 60)
        bot.addRow(row("Acceso a notificaciones", if (listening) "Activado" else "Desactivado", iconRes = R.drawable.ic_bell, iconBg = C.RED,
            valueColor = if (listening) C.SECONDARY else C.RED, chevron = true) { openListenerSettings() }, 60)
        bot.addRow(row("Batería", if (batteryOk) "Sin restricciones" else "Restringida", iconRes = R.drawable.ic_battery, iconBg = C.GREEN,
            valueColor = if (batteryOk) C.SECONDARY else C.ORANGE, chevron = true) { askBattery() }, 60)
        if (Build.VERSION.SDK_INT >= 31 && !getSystemService(AlarmManager::class.java).canScheduleExactAlarms()) {
            bot.addRow(row("Alarmas exactas", "Desactivadas", iconRes = R.drawable.ic_clock, iconBg = C.ORANGE, valueColor = C.ORANGE, chevron = true) {
                runCatching { startActivity(Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM, Uri.parse("package:$packageName"))) }
            }, 60)
        }
        bot.addRow(switchRow("También WhatsApp normal", AppSettings.watchPersonal, R.drawable.ic_chat, C.TEAL, "Además de WhatsApp Business") { on ->
            AppSettings.watchPersonal = on
        }, 60)
        box.addView(bot)
        box.addView(sectionFooter("El bot funciona mientras este dispositivo esté encendido y con conexión. WhatsApp Business debe estar instalado aquí."))

        // Taller
        box.addView(sectionHeader("Datos del taller"))
        val taller = group()
        taller.addRow(fieldRow("Nombre", AppSettings.tallerName, "The Mechanic Automoción") { AppSettings.tallerName = it })
        taller.addRow(fieldRow("Teléfono", AppSettings.tallerPhone, "600 000 000", InputType.TYPE_CLASS_PHONE) { AppSettings.tallerPhone = it })
        taller.addRow(fieldRow("Horario", AppSettings.hours, "L-V 8:30–14:00 y 16:00–19:00") { AppSettings.hours = it })
        taller.addRow(fieldRow("Dirección", AppSettings.address, "Calle, número, ciudad") { AppSettings.address = it })
        box.addView(taller)
        box.addView(sectionFooter("El bot usa el horario y la dirección cuando un cliente pregunta, y el teléfono para urgencias."))

        // Recordatorios
        box.addView(sectionHeader("Recordatorios de citas"))
        val rem = group()
        rem.addRow(row("Primer aviso", AppSettings.reminderLabel(AppSettings.reminder1), iconRes = R.drawable.ic_bell, iconBg = C.ORANGE, chevron = true) {
            chooseReminder("Primer aviso", AppSettings.reminder1) { AppSettings.reminder1 = it }
        }, 60)
        rem.addRow(row("Segundo aviso", AppSettings.reminderLabel(AppSettings.reminder2), iconRes = R.drawable.ic_bell, iconBg = C.ORANGE, chevron = true) {
            chooseReminder("Segundo aviso", AppSettings.reminder2) { AppSettings.reminder2 = it }
        }, 60)
        box.addView(rem)

        // Herramientas
        box.addView(sectionHeader("Herramientas"))
        val tools = group()
        tools.addRow(row("Probar el bot", subtitle = "Simula una conversación de cliente", iconRes = R.drawable.ic_chat, iconBg = C.INDIGO, chevron = true) {
            startActivity(Intent(this, SimulatorActivity::class.java))
        }, 60)
        tools.addRow(row("Exportar casos", subtitle = "Archivo CSV para Excel o correo", iconRes = R.drawable.ic_share, iconBg = C.TINT, chevron = true) { exportCsv() }, 60)
        tools.addRow(switchRow("Mostrar casos de prueba", Repo.prefs().getBoolean("mostrarPruebas", true), R.drawable.ic_eye, C.GRAY) { on ->
            Repo.prefs().edit().putBoolean("mostrarPruebas", on).apply()
        }, 60)
        box.addView(tools)

        box.addSpaced(group().apply {
            addRow(row("Borrar casos de prueba", titleColor = C.RED) {
                AlertDialog.Builder(this@MainActivity).setMessage("¿Borrar todos los casos creados con el simulador?")
                    .setPositiveButton("Borrar") { _, _ -> Repo.clearTests(); toast("Casos de prueba borrados") }
                    .setNegativeButton("Cancelar", null).show()
            })
        }, 28)

        box.addView(sectionFooter("Todos los datos se guardan solo en este dispositivo. La app no usa internet ni servicios externos."))
        return page(box)
    }

    /** Fila editable estilo iOS: etiqueta a la izquierda, texto a la derecha. Se guarda al escribir. */
    private fun fieldRow(label: String, value: String, hintText: String, type: Int = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_CAP_SENTENCES, onSave: (String) -> Unit): View {
        val r = hbox().apply { setPadding(dp(16), dp(4), dp(16), dp(4)); minimumHeight = dp(48) }
        r.addView(tv(label, 16f, C.LABEL), lp(dp(96), -2))
        val e = EditText(this).apply {
            setText(value)
            hint = hintText
            inputType = type
            textSize = 16f
            typeface = Fonts.regular
            setTextColor(C.SECONDARY)
            setHintTextColor(C.TERTIARY)
            background = null
            gravity = Gravity.END or Gravity.CENTER_VERTICAL
            setSingleLine(true)
            addTextChangedListener(object : TextWatcher {
                override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
                override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
                override fun afterTextChanged(s: Editable?) { onSave(s?.toString()?.trim().orEmpty()) }
            })
        }
        r.addView(e, lp(0, -2, 1f))
        return r
    }

    private fun chooseReminder(title: String, current: Int, onChange: (Int) -> Unit) {
        val choices = AppSettings.REMINDER_CHOICES
        AlertDialog.Builder(this)
            .setTitle(title)
            .setSingleChoiceItems(choices.map { AppSettings.reminderLabel(it) }.toTypedArray(), choices.indexOf(current).coerceAtLeast(0)) { d, i ->
                onChange(choices[i])
                Reminders.rescheduleAll(this)
                d.dismiss()
                render()
            }
            .setNegativeButton("Cancelar", null)
            .show()
    }

    private fun openListenerSettings() {
        runCatching { startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS)) }
            .onFailure { toast("Abre Ajustes > Notificaciones > Acceso a notificaciones") }
    }

    private fun askBattery() {
        runCatching {
            startActivity(Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:$packageName")))
        }.onFailure {
            runCatching { startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS)) }
        }
    }

    private fun exportCsv() {
        val send = Intent(Intent.ACTION_SEND).apply {
            type = "text/plain"
            putExtra(Intent.EXTRA_SUBJECT, "Casos ${AppSettings.tallerName}")
            putExtra(Intent.EXTRA_TEXT, Repo.exportCsv())
        }
        startActivity(Intent.createChooser(send, "Exportar casos"))
    }

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()
}

package com.themechanic.bot.engine

import java.time.Instant
import java.time.LocalDate
import java.time.ZoneId
import java.time.format.DateTimeFormatter

/**
 * Cerebro del chatbot: recibe un mensaje de un cliente y devuelve la respuesta.
 * No depende de Android, así se puede probar en cualquier ordenador.
 */
class BotEngine(
    private val store: CaseStore,
    private val info: () -> TallerInfo = { TallerInfo() },
    private val clock: () -> Long = { System.currentTimeMillis() },
    private val zone: ZoneId = ZoneId.systemDefault(),
    private val settings: () -> BotSettings = { BotSettings() },
) {
    companion object {
        /** Tras despedirse, durante este tiempo el bot no abre un caso nuevo. */
        const val DONE_QUIET_MS = 12L * 60 * 60 * 1000
        /** Tras pasar a un trabajador, el bot se calla en ese chat durante este tiempo. */
        const val HUMAN_QUIET_MS = 24L * 60 * 60 * 1000
        /** Al 3er intento sin entender al cliente, pasa el caso a un trabajador. */
        const val MAX_FAILURES = 3
        const val MAX_KB_ANSWERS = 8
        private const val MAX_TRANSCRIPT = 300

        val MAIN = listOf("ITV", "MANTENIMIENTO", "AVERÍA", "GRÚA")
        val ITV = listOf("REVISIÓN PRE-ITV", "ITV DESFAVORABLE", "TRAMITAR EL TALLER LA ITV")
        val MAINT = listOf("MANTENIMIENTO BÁSICO", "MANTENIMIENTO PREVENTIVO")
        val BASIC = listOf(
            "Filtro de aire", "Filtro de habitáculo", "Filtro gasolina/diésel",
            "Cambio de aceite + filtro de aceite", "Cambio de discos", "Cambio de pastillas", "Líquido de frenos",
        )
        val PREV = listOf(
            "Distribución", "Correa de accesorios", "Embrague", "Líquido de caja de cambios",
            "Recarga aire acondicionado", "Neumáticos",
        )

        private val MAIN_KW = listOf(
            listOf("itv", "inspeccion"),
            listOf("mantenimiento", "revision general"),
            listOf("averia", "fallo", "problema", "ruido", "roto", "rota"),
            listOf("grua", "remolque", "auxilio", "asistencia", "tirado", "tirada"),
        )
        private val ITV_KW = listOf(
            listOf("pre itv", "preitv", "revision"),
            listOf("desfavorable", "suspendida", "suspendido", "negativa", "no la pase", "no paso", "no pase", "no la ha pasado"),
            listOf("tramitar", "tramitad", "pasar la itv", "pasadme", "llevar"),
        )
        private val MAINT_KW = listOf(listOf("basico"), listOf("preventivo"))
        private val BASIC_KW = listOf(
            listOf("filtro de aire", "filtro del aire"),
            listOf("habitaculo", "antipolen", "polen"),
            listOf("filtro de gasolina", "filtro de diesel", "filtro de gasoil", "filtro de combustible", "gasolina", "diesel", "gasoil", "combustible"),
            listOf("aceite"),
            listOf("discos", "disco"),
            listOf("pastillas", "pastilla"),
            listOf("liquido de frenos", "liquido de freno"),
        )
        private val PREV_KW = listOf(
            listOf("distribucion"),
            listOf("correa de accesorios", "accesorios", "correa auxiliar"),
            listOf("embrague"),
            listOf("caja de cambios", "liquido de caja", "aceite de caja"),
            listOf("aire acondicionado", "climatizador", "clima", "recarga"),
            listOf("neumaticos", "neumatico", "ruedas", "rueda", "gomas"),
        )

        private val KEYCAP = listOf("0️⃣", "1️⃣", "2️⃣", "3️⃣", "4️⃣", "5️⃣", "6️⃣", "7️⃣", "8️⃣", "9️⃣")
        fun emoji(code: String): String = code.split('.').joinToString(".") { part -> part.map { KEYCAP[it - '0'] }.joinToString("") }
    }

    private class Ctx(val conv: Conversation, val msg: Incoming, val now: Long) {
        var event: CaseEvent? = null
    }

    private val eventRank = mapOf(
        CaseEvent.UPDATED to 0, CaseEvent.CREATED to 1, CaseEvent.COMPLETED to 2,
        CaseEvent.NEEDS_CONTACT to 3, CaseEvent.URGENT to 4,
    )

    private fun setEvent(ctx: Ctx, e: CaseEvent) {
        val cur = ctx.event
        if (cur == null || eventRank.getValue(e) > eventRank.getValue(cur)) ctx.event = e
    }

    // =====================================================================
    // Entrada principal
    // =====================================================================

    /** Procesa un mensaje del cliente. Devuelve el texto a responder, o null para no responder. */
    fun handle(conv: Conversation, msg: Incoming): String? {
        val ctx = Ctx(conv, msg, clock())
        log(conv, "Cliente", msg.text, ctx.now)
        val reply = route(ctx)
        if (reply != null) log(conv, "Bot", reply, ctx.now)
        profile(conv)?.let { p ->
            p.updatedAt = ctx.now
            store.onProfileChanged(p, ctx.event ?: CaseEvent.UPDATED)
        }
        return reply
    }

    /** Reactiva el bot en un chat: el próximo mensaje del cliente se atiende según el modo de reanudación. */
    fun reset(conv: Conversation) {
        if (conv.step == Step.HUMAN) {
            conv.stepSince = Long.MIN_VALUE / 2 // la pausa se da por terminada
        } else {
            conv.step = Step.DONE
            conv.doneAt = 0L
        }
        conv.failures = 0
    }

    /** Pausa el bot en un chat (cuando contesta un trabajador). */
    fun pause(conv: Conversation, now: Long = clock()) {
        if (conv.step != Step.HUMAN) {
            conv.pausedStep = conv.step
            conv.step = Step.HUMAN
        }
        conv.stepSince = now
        conv.failures = 0
    }

    /** ¿Sigue en pausa este chat? */
    fun isPaused(conv: Conversation, now: Long = clock()): Boolean =
        conv.step == Step.HUMAN && pauseRemaining(conv, now) > 0

    /** Milisegundos de pausa que quedan (Long.MAX_VALUE = indefinida). */
    fun pauseRemaining(conv: Conversation, now: Long = clock()): Long {
        val p = settings().pauseMs
        if (p == Long.MAX_VALUE) return if (conv.stepSince > Long.MIN_VALUE / 4) Long.MAX_VALUE else 0
        return (conv.stepSince + p - now).coerceAtLeast(0)
    }

    private fun route(ctx: Ctx): String? {
        val c = ctx.conv
        val m = ctx.msg
        val text = m.text.trim()

        when (c.step) {
            Step.NEW -> return start(ctx)
            Step.DONE -> {
                if (ctx.now - c.doneAt < DONE_QUIET_MS) {
                    if (!c.doneNoticeSent) {
                        c.doneNoticeSent = true
                        return "Hola de nuevo 👋 Ya tenemos registrada tu solicitud y un trabajador se pondrá en contacto contigo lo antes posible. ¡Gracias por tu paciencia! 🔧"
                    }
                    return null
                }
                return restart(ctx)
            }
            Step.HUMAN -> {
                if (pauseRemaining(c, ctx.now) > 0) return null
                return resume(ctx)
            }
            else -> Unit
        }

        val freeTextSteps = setOf(Step.ASK_FAULT_DESC, Step.ASK_TOW_DESC, Step.ASK_ITV_PHOTO, Step.ASK_TIRE_SIZE, Step.ASK_TIRE_PHOTO)
        if (c.step !in freeTextSteps && m.kind == MsgKind.TEXT && SmallTalk.isIdentityQuestion(text)) {
            return SmallTalk.identity(info().name) + "\n\n" + prompt(ctx)
        }
        if (c.step !in freeTextSteps && m.kind == MsgKind.TEXT && TextParsing.wantsHuman(text)) {
            return handoff(ctx, requested = true)
        }
        if (m.kind == MsgKind.AUDIO) {
            return fail(ctx, "🎤 Lo siento, no puedo escuchar audios. Por favor, *escríbelo* 🙏")
        }

        return when (c.step) {
            Step.ASK_NAME -> onName(ctx, text)
            Step.ASK_MODEL -> onModel(ctx, text)
            Step.ASK_YEAR -> onYear(ctx, text)
            Step.ASK_PLATE -> onPlate(ctx, text)
            Step.ASK_PHONE -> onPhone(ctx, text)
            Step.MAIN_MENU -> onMainMenu(ctx, text)
            Step.ITV_MENU -> onItvMenu(ctx, text)
            Step.MAINT_MENU -> onMaintMenu(ctx, text)
            Step.BASIC_MENU -> onMulti(ctx, text, listOf(2, 1), BASIC, BASIC_KW, "Mantenimiento básico")
            Step.PREV_MENU -> onMulti(ctx, text, listOf(2, 2), PREV, PREV_KW, "Mantenimiento preventivo")
            Step.ASK_ITV_PHOTO -> onItvPhoto(ctx, text)
            Step.ASK_ITV_DATE -> onItvDate(ctx, text)
            Step.ASK_TIRE_SIZE -> onTireSize(ctx, text)
            Step.ASK_TIRE_PHOTO -> onTirePhoto(ctx, text)
            Step.ASK_FAULT_DESC -> onFault(ctx, text)
            Step.ASK_TOW_DESC -> onTow(ctx, text)
            Step.ASK_MORE -> onMore(ctx, text)
            Step.ASK_SAME_VEHICLE -> onSameVehicle(ctx, text)
            Step.NEW, Step.DONE, Step.HUMAN -> null
        }
    }

    // =====================================================================
    // Inicio y datos del cliente
    // =====================================================================

    private fun start(ctx: Ctx): String {
        val c = ctx.conv
        c.profileId = null
        c.name = ""; c.model = ""; c.year = ""; c.plate = ""; c.phone = ""; c.keepPhone = false
        c.kbAnswers = 0
        go(ctx, Step.ASK_NAME)
        val t = info()
        return "¡Hola! 👋 Bienvenido/a a *${t.name}* 🔧🚗\n" +
            "Soy el asistente virtual del taller. Para atenderte necesito unos datos:\n" +
            "• Tu nombre\n• Modelo del vehículo\n• Año de fabricación\n• Matrícula\n• Teléfono de contacto\n\n" +
            "Después te enseñaré un menú. ⚠️ Para elegir las opciones *responde con el número* (por ejemplo: 1).\n\n" +
            "Para empezar, ¿cómo te llamas?"
    }

    private fun restart(ctx: Ctx): String {
        val c = ctx.conv
        c.profileId = null
        c.kbAnswers = 0
        if (c.model.isNotBlank() && c.plate.isNotBlank() && c.name.isNotBlank()) {
            go(ctx, Step.ASK_SAME_VEHICLE)
            return "¡Hola de nuevo, ${c.name}! 👋 Gracias por volver a contactar con *${info().name}*.\n\n" + prompt(ctx)
        }
        return start(ctx)
    }

    /** Vuelve a atender tras una pausa, según el modo elegido en Ajustes. */
    private fun resume(ctx: Ctx): String {
        val c = ctx.conv
        val hasData = c.name.isNotBlank() && c.model.isNotBlank()
        return when (settings().resumeMode) {
            ResumeMode.RESTART -> restart(ctx)
            ResumeMode.MENU -> {
                if (!hasData) return start(ctx)
                c.kbAnswers = 0
                createProfile(ctx)
                go(ctx, Step.MAIN_MENU)
                "¡Hola de nuevo, ${c.name}! 👋 Gracias por escribir a *${info().name}*.\n\n" + prompt(ctx)
            }
            ResumeMode.CONTINUE -> {
                val s = c.pausedStep
                val resumable = s !in setOf(Step.NEW, Step.DONE, Step.HUMAN) &&
                    (c.profileId == null || profile(c) != null)
                if (!resumable) return restart(ctx)
                go(ctx, s)
                "¡Hola de nuevo! 👋 Seguimos donde lo dejamos:\n\n" + prompt(ctx)
            }
        }
    }

    private val NAME_PREFIX = Regex(
        "^(?:(?:hola|buenas|buenos dias|buenas tardes|buenas noches)[ ,!.]*)?(?:me llamo|mi nombre es|soy|nombre:?)\\s+",
        RegexOption.IGNORE_CASE,
    )

    private fun onName(ctx: Ctx, text: String): String {
        val c = ctx.conv
        val clean = text.replace(NAME_PREFIX, "").replace(Regex("[!.¡¿?,;:]+$"), "").trim()
        val words = clean.split(Regex("\\s+")).filter { it.isNotBlank() }
        val onlyGreeting = TextParsing.isGreeting(text) && words.size <= 3 && !NAME_PREFIX.containsMatchIn(text)
        if (onlyGreeting) {
            return "¡Hola! 😊 Para empezar, dime por favor *tu nombre*."
        }
        if (ctx.msg.kind != MsgKind.TEXT || clean.length < 2 || clean.length > 40 || words.size > 5 ||
            clean.any { it.isDigit() } || !TextParsing.hasLetters(clean)
        ) {
            return fail(ctx, "Escríbeme solo *tu nombre*, por favor (ej.: Laura García).")
        }
        c.name = words.joinToString(" ") { w -> w.lowercase().replaceFirstChar { it.titlecase() } }
        return nextData(ctx, "Encantados, ${c.name} 😊")
    }

    private fun onModel(ctx: Ctx, text: String): String {
        val c = ctx.conv
        if (ctx.msg.kind != MsgKind.TEXT || !TextParsing.hasLetters(text) || text.length < 2 || text.length > 80 ||
            (TextParsing.isGreeting(text) && text.split(" ").size <= 2)
        ) {
            return fail(ctx, "Indícame la *marca y modelo* del vehículo (ej.: Seat León).")
        }
        var rest = text
        // Si de paso nos dice el año o la matrícula, los aprovechamos
        Regex("(?<!\\d)(19[5-9]\\d|20\\d\\d)(?!\\d)").find(rest)?.let { m ->
            TextParsing.parseYear(m.value, LocalDate.now(zone).year)?.let { y -> c.year = y.toString(); rest = rest.replace(m.value, " ") }
        }
        Regex("(?<![0-9A-Za-z])(\\d{4})\\s*-?\\s*([A-Za-z]{3})(?![A-Za-z])").find(rest)?.let { m ->
            c.plate = "${m.groupValues[1]} ${m.groupValues[2].uppercase()}"; rest = rest.replace(m.value, " ")
        }
        rest = rest.replace(Regex("\\b(?:del|de|año|ano|matricula|matrícula)\\s*$", RegexOption.IGNORE_CASE), "")
            .replace(Regex("\\s+"), " ").trim().trim(',', '.', '-')
        if (!TextParsing.hasLetters(rest)) return fail(ctx, "Indícame la *marca y modelo* del vehículo (ej.: Seat León).")
        c.model = rest.replaceFirstChar { it.titlecase() }
        return nextData(ctx, "¡Perfecto! 🚗")
    }

    private fun onYear(ctx: Ctx, text: String): String {
        val y = TextParsing.parseYear(text, LocalDate.now(zone).year)
            ?: return fail(ctx, "Escribe el *año de fabricación* con 4 cifras (ej.: 2015).")
        ctx.conv.year = y.toString()
        return nextData(ctx, "Anotado 👍")
    }

    private fun onPlate(ctx: Ctx, text: String): String {
        val p = TextParsing.parsePlate(text)
            ?: return fail(ctx, "Escribe la *matrícula* del vehículo (ej.: 1234 ABC).")
        ctx.conv.plate = p
        return nextData(ctx, "Anotado 👍")
    }

    private fun onPhone(ctx: Ctx, text: String): String {
        val c = ctx.conv
        val sameAsWa = c.waPhone.isNotBlank() && (
            TextParsing.numberTokens(text) == listOf(listOf(1)) ||
                TextParsing.containsAny(text, listOf("este", "este mismo", "el mismo", "mismo", "este numero", "si"))
            )
        val phone = if (sameAsWa) c.waPhone else TextParsing.parsePhone(text)
        if (phone == null) {
            return fail(ctx, "Escribe un *teléfono* de contacto con todas sus cifras (ej.: 600 123 456).")
        }
        c.phone = phone
        return nextData(ctx, "")
    }

    /** Pregunta el siguiente dato que falte, o crea el perfil y muestra el menú. */
    private fun nextData(ctx: Ctx, ack: String): String {
        val c = ctx.conv
        val next = when {
            c.model.isBlank() -> Step.ASK_MODEL
            c.year.isBlank() -> Step.ASK_YEAR
            c.plate.isBlank() -> Step.ASK_PLATE
            c.phone.isBlank() -> Step.ASK_PHONE
            else -> null
        }
        if (next != null) {
            go(ctx, next)
            return listOf(ack, prompt(ctx)).filter { it.isNotBlank() }.joinToString(" ")
        }
        createProfile(ctx)
        go(ctx, Step.MAIN_MENU)
        return "✅ ¡Gracias, ${c.name}! Hemos registrado tus datos:\n" +
            "🚗 ${c.model} (${c.year})\n🔢 ${c.plate}\n📞 ${c.phone}\n\n" + prompt(ctx)
    }

    private fun onSameVehicle(ctx: Ctx, text: String): String {
        val c = ctx.conv
        return when (TextParsing.yesNo(text)) {
            1 -> {
                createProfile(ctx)
                go(ctx, Step.MAIN_MENU)
                "¡Perfecto! 🚗 ${c.model} (${c.plate}).\n\n" + prompt(ctx)
            }
            2 -> {
                c.model = ""; c.year = ""; c.plate = ""
                nextData(ctx, "De acuerdo 👍")
            }
            else -> fail(ctx, "Responde *1* si es el mismo vehículo o *2* si es otro.")
        }
    }

    // =====================================================================
    // Menús
    // =====================================================================

    private fun keywordChoice(text: String, kw: List<List<String>>): List<Int> =
        kw.mapIndexedNotNull { i, words -> if (TextParsing.containsAny(text, words)) i + 1 else null }

    private fun onMainMenu(ctx: Ctx, text: String): String {
        val tokens = TextParsing.numberTokens(text)
        if (tokens.isEmpty()) {
            val k = keywordChoice(text, MAIN_KW)
            if (k.size == 1) return mainOption(ctx, k[0])
            return fail(ctx)
        }
        val t = tokens[0]
        if (t == listOf(0)) return prompt(ctx)
        return when {
            t[0] !in 1..4 -> fail(ctx)
            t.size == 1 -> mainOption(ctx, t[0])
            t[0] == 1 -> { go(ctx, Step.ITV_MENU); onItvMenu(ctx, text) }
            t[0] == 2 -> { go(ctx, Step.MAINT_MENU); onMaintMenu(ctx, text) }
            else -> mainOption(ctx, t[0])
        }
    }

    private fun mainOption(ctx: Ctx, n: Int): String {
        addService(ctx, null)
        return when (n) {
            1 -> { go(ctx, Step.ITV_MENU); "Has elegido *ITV* 📋\n\n" + prompt(ctx) }
            2 -> { go(ctx, Step.MAINT_MENU); "Has elegido *MANTENIMIENTO* 🛠️\n\n" + prompt(ctx) }
            3 -> { addService(ctx, "Avería"); go(ctx, Step.ASK_FAULT_DESC); prompt(ctx) }
            4 -> { addService(ctx, "Grúa"); go(ctx, Step.ASK_TOW_DESC); prompt(ctx) }
            else -> fail(ctx)
        }
    }

    private fun onItvMenu(ctx: Ctx, text: String): String {
        val tokens = TextParsing.numberTokens(text)
        val choice = if (tokens.isNotEmpty()) TextParsing.relative(tokens[0], listOf(1))
        else keywordChoice(text, ITV_KW).singleOrNull()
        return when (choice) {
            0 -> { go(ctx, Step.MAIN_MENU); prompt(ctx) }
            1 -> {
                addService(ctx, "ITV › Revisión pre-ITV")
                "🙌 ¡Gracias por contactar con *${info().name}*! Hemos anotado tu solicitud de *revisión pre-ITV*.\n\n" + askMore(ctx)
            }
            2 -> {
                addService(ctx, "ITV › ITV desfavorable")
                go(ctx, Step.ASK_ITV_PHOTO); prompt(ctx)
            }
            3 -> {
                addService(ctx, "ITV › Tramitar el taller la ITV")
                go(ctx, Step.ASK_ITV_DATE); prompt(ctx)
            }
            else -> fail(ctx)
        }
    }

    private fun onMaintMenu(ctx: Ctx, text: String): String {
        val tokens = TextParsing.numberTokens(text)
        val choice = if (tokens.isNotEmpty()) TextParsing.relative(tokens[0].take(2), listOf(2))
        else keywordChoice(text, MAINT_KW).singleOrNull()
        val deeper = tokens.any { it.size >= 3 }
        return when (choice) {
            0 -> { go(ctx, Step.MAIN_MENU); prompt(ctx) }
            1 -> { go(ctx, Step.BASIC_MENU); if (deeper) onMulti(ctx, text, listOf(2, 1), BASIC, BASIC_KW, "Mantenimiento básico") else prompt(ctx) }
            2 -> { go(ctx, Step.PREV_MENU); if (deeper) onMulti(ctx, text, listOf(2, 2), PREV, PREV_KW, "Mantenimiento preventivo") else prompt(ctx) }
            else -> fail(ctx)
        }
    }

    /** Menú en el que se pueden elegir varias opciones a la vez. */
    private fun onMulti(ctx: Ctx, text: String, prefix: List<Int>, items: List<String>, kw: List<List<String>>, label: String): String {
        val tokens = TextParsing.numberTokens(text)
        val values: List<Int> = if (tokens.isNotEmpty()) tokens.mapNotNull { TextParsing.relative(it, prefix) } else keywordChoice(text, kw)
        if (values == listOf(0)) { go(ctx, Step.MAINT_MENU); return prompt(ctx) }
        val valid = values.filter { it in 1..items.size }.distinct().sorted()
        if (valid.isEmpty()) return fail(ctx, "Responde con los *números* de los servicios que necesites, separados por comas (ej.: 1, 4, 6).")
        val ignored = values.filter { it !in 1..items.size && it != 0 }
        valid.forEach { addService(ctx, "$label › ${items[it - 1]}") }
        val list = valid.joinToString("\n") { "• ${items[it - 1]}" }
        val extra = if (ignored.isNotEmpty()) "\n(He ignorado: ${ignored.joinToString(", ")}, no está en la lista.)" else ""
        val head = "✅ Anotado en tu solicitud:\n$list$extra"
        if (prefix == listOf(2, 2) && 6 in valid) {
            go(ctx, Step.ASK_TIRE_SIZE)
            return "$head\n\n" + prompt(ctx)
        }
        return "$head\n\n" + askMore(ctx)
    }

    // =====================================================================
    // Pasos con información libre
    // =====================================================================

    private fun onItvPhoto(ctx: Ctx, text: String): String {
        when (ctx.msg.kind) {
            MsgKind.PHOTO, MsgKind.OTHER_MEDIA -> note(ctx, "📷 Foto/documento del informe ITV recibido (ver en el chat de WhatsApp)")
            MsgKind.TEXT -> {
                if (text.length < 2) return fail(ctx, "Adjunta una *foto del informe* de la ITV o escribe brevemente los defectos.")
                note(ctx, "ITV desfavorable (según el cliente): $text")
            }
            else -> return fail(ctx, "Adjunta una *foto del informe* de la ITV o escribe brevemente los defectos.")
        }
        return "¡Recibido, gracias! 📝 Lo hemos anotado para que nuestro equipo revise por qué ha sido desfavorable.\n\n" + askMore(ctx)
    }

    private fun onItvDate(ctx: Ctx, text: String): String {
        val c = ctx.conv
        val parsed = TextParsing.parseDate(text, LocalDate.now(zone))
        val date = parsed ?: if (c.failures >= 1 && text.any { it.isDigit() }) "$text (sin verificar)" else null
        if (date == null) return fail(ctx, "Escribe la fecha en la que caduca tu ITV (ej.: 15/03/2027 o marzo 2027).")
        profile(c)?.itvExpiry = date
        note(ctx, "ITV en vigor caduca: $date")
        return "Perfecto, anotado 📅 Tu ITV caduca: *$date*. Te contactaremos para darte cita antes de esa fecha.\n\n" + askMore(ctx)
    }

    private fun onTireSize(ctx: Ctx, text: String): String {
        if (ctx.msg.kind == MsgKind.PHOTO) {
            note(ctx, "📷 Foto del neumático recibida (ver en el chat de WhatsApp)")
            return "📷 ¡Foto recibida, gracias! Si puedes, escríbenos también la *medida* y *cuántos* neumáticos quieres cambiar (o responde *0* para continuar)."
                .also { go(ctx, Step.ASK_TIRE_PHOTO) }
        }
        if (ctx.msg.kind != MsgKind.TEXT || text.isBlank()) return fail(ctx, "Escribe la *medida* del neumático (ej.: 205/55 R16).")
        val size = TextParsing.tireSize(text)
        note(ctx, "Neumáticos: " + (size?.let { "medida $it — " } ?: "") + "\"$text\"")
        go(ctx, Step.ASK_TIRE_PHOTO)
        return "Anotado 👍 " + prompt(ctx)
    }

    private fun onTirePhoto(ctx: Ctx, text: String): String {
        when {
            ctx.msg.kind == MsgKind.PHOTO -> note(ctx, "📷 Foto del neumático recibida (ver en el chat de WhatsApp)")
            TextParsing.numberTokens(text) == listOf(listOf(0)) || TextParsing.yesNo(text) == 2 -> note(ctx, "Neumáticos: el cliente no envía foto")
            ctx.msg.kind == MsgKind.TEXT && text.isNotBlank() -> note(ctx, "Neumáticos (info adicional): $text")
            else -> return fail(ctx, "Envía una *foto* del neumático o responde *0* para continuar.")
        }
        return "¡Gracias! 🛞 Lo hemos anotado todo.\n\n" + askMore(ctx)
    }

    private fun onFault(ctx: Ctx, text: String): String {
        if (ctx.msg.kind == MsgKind.PHOTO || ctx.msg.kind == MsgKind.OTHER_MEDIA) {
            note(ctx, "📷 Foto/vídeo de la avería recibido (ver en el chat de WhatsApp)")
            return "📷 ¡Recibido! Cuéntanos también *brevemente por escrito* qué le sucede al vehículo."
        }
        if (text.length < 3 || !TextParsing.hasLetters(text)) {
            return fail(ctx, "Cuéntanos con unas palabras qué le sucede al vehículo (ej.: hace ruido al frenar).")
        }
        note(ctx, "Avería (según el cliente): $text")
        val matches = Mechanics.matches(text)
        val safety = matches.filter { it.safety }
        if (safety.isNotEmpty()) note(ctx, "⚠️ Posible riesgo para la seguridad")
        val tips = (safety + matches.filter { !it.safety }.take(1)).take(3).joinToString("\n") { it.answer }
        val towHint = if (safety.isNotEmpty()) "\n🚨 Si necesitas *grúa*, responde 1 y después elige 4️⃣.\n" else ""
        return "Gracias, lo hemos anotado 📝 Nuestro equipo lo revisará.\n" +
            (if (tips.isNotBlank()) "\n$tips\n" else "") + towHint + "\n" + askMore(ctx)
    }

    private fun onTow(ctx: Ctx, text: String): String {
        val c = ctx.conv
        when (ctx.msg.kind) {
            MsgKind.LOCATION -> {
                note(ctx, "📍 Ubicación compartida (ver en el chat de WhatsApp)")
                return "📍 ¡Ubicación recibida! Cuéntanos también *brevemente* qué le ha sucedido al vehículo."
            }
            MsgKind.PHOTO, MsgKind.OTHER_MEDIA -> {
                note(ctx, "📷 Foto recibida (ver en el chat de WhatsApp)")
                return "📷 ¡Recibido! Cuéntanos también *brevemente* qué le ha sucedido al vehículo y dónde se encuentra."
            }
            else -> Unit
        }
        if (text.length < 3 || !TextParsing.hasLetters(text)) {
            return fail(ctx, "Cuéntanos brevemente qué le ha pasado al vehículo y dónde está.")
        }
        note(ctx, "🚨 Grúa (según el cliente): $text")
        profile(c)?.status = CaseStatus.URGENT
        setEvent(ctx, CaseEvent.URGENT)
        val phone = c.phone.ifBlank { "tu teléfono" }
        val tallerPhone = info().phone.takeIf { it.isNotBlank() }?.let { "\nSi es muy urgente, llámanos al *$it*." } ?: ""
        return "🚨 Hemos avisado al taller con *prioridad*. Un trabajador te llamará lo antes posible al $phone para organizar la grúa.$tallerPhone\n\n" +
            "Mientras tanto, por tu seguridad: si estás en la vía, enciende las luces de emergencia y la baliza V16, ponte el chaleco y espera en un lugar seguro, fuera de la calzada.\n\n" +
            farewell(ctx)
    }

    private fun onMore(ctx: Ctx, text: String): String {
        return when (TextParsing.yesNo(text)) {
            1 -> { go(ctx, Step.MAIN_MENU); "¡Claro! 😊\n\n" + prompt(ctx) }
            2 -> farewell(ctx)
            else -> fail(ctx)
        }
    }

    private fun askMore(ctx: Ctx): String {
        go(ctx, Step.ASK_MORE)
        return prompt(ctx)
    }

    private fun farewell(ctx: Ctx): String {
        val c = ctx.conv
        profile(c)?.let { p -> if (p.status != CaseStatus.URGENT) p.status = CaseStatus.PENDING }
        setEvent(ctx, CaseEvent.COMPLETED)
        go(ctx, Step.DONE)
        c.doneAt = ctx.now
        c.doneNoticeSent = false
        val n = c.name.takeIf { it.isNotBlank() }?.let { ", $it" } ?: ""
        return "¡Muchas gracias$n! 🙌 Hemos registrado tu solicitud y un miembro de nuestro equipo la revisará y se pondrá en contacto contigo para darte cita lo antes posible.\n\n" +
            "Gracias por confiar en *${info().name}* 🔧🚗 ¡Que tengas un buen día!"
    }

    // =====================================================================
    // Errores, dudas y paso a un trabajador
    // =====================================================================

    private fun fail(ctx: Ctx, hint: String? = null): String {
        val c = ctx.conv
        // ¿Es una duda que podemos responder? Respondemos y repetimos la pregunta.
        if (ctx.msg.kind == MsgKind.TEXT && c.kbAnswers < MAX_KB_ANSWERS) {
            val answer = knowledgeAnswer(ctx.msg.text)
            if (answer != null) {
                c.kbAnswers++
                return "$answer\n\n" + prompt(ctx)
            }
        }
        c.failures++
        if (c.failures >= MAX_FAILURES) return handoff(ctx, requested = false)
        val h = hint ?: "Responde solo con el *número* de la opción, por favor."
        return "No te he entendido bien 🙏 $h\n\n" + prompt(ctx)
    }

    private fun knowledgeAnswer(text: String): String? {
        val t = info()
        if (TextParsing.containsAny(text, listOf("horario", "a que hora", "abris", "abren", "cerrais", "cierran", "abierto"))) {
            return if (t.hours.isNotBlank()) "🕒 Nuestro horario: ${t.hours}" else "🕒 Un trabajador te confirmará el horario cuando revise tu solicitud."
        }
        if (TextParsing.containsAny(text, listOf("donde estais", "donde esta el taller", "direccion", "como llego", "ubicacion del taller"))) {
            return if (t.address.isNotBlank()) "📍 Estamos en: ${t.address}" else "📍 Un trabajador te indicará cómo llegar al taller."
        }
        SmallTalk.answer(text, t)?.let { return it }
        val m = Mechanics.matches(text)
        if (m.isEmpty()) return null
        if (!Mechanics.isQuestion(text) && m.none { it.safety }) return null
        return m.take(2).joinToString("\n") { it.answer }
    }

    private fun handoff(ctx: Ctx, requested: Boolean): String {
        val c = ctx.conv
        val p = profile(c) ?: createProfile(ctx)
        if (p.status != CaseStatus.URGENT) p.status = CaseStatus.NEEDS_CONTACT
        note(
            ctx,
            if (requested) "👤 El cliente pide hablar con una persona: \"${ctx.msg.text}\""
            else "❓ El bot no ha entendido al cliente (paso: ${stepLabel(c.step)}). Último mensaje: \"${ctx.msg.text}\"",
        )
        setEvent(ctx, CaseEvent.NEEDS_CONTACT)
        c.pausedStep = c.step
        go(ctx, Step.HUMAN)
        val tel = info().phone.takeIf { it.isNotBlank() }?.let { " Si es urgente, puedes llamarnos al *$it*." } ?: ""
        return if (requested) {
            "¡Por supuesto! 🙂 Hemos avisado al equipo y *un trabajador se pondrá en contacto contigo* en cuanto pueda.$tel\n\nGracias por contactar con *${info().name}*."
        } else {
            "Disculpa, parece que no consigo entenderte bien 🙏 No te preocupes: hemos anotado tu consulta y *un trabajador se pondrá en contacto contigo* en cuanto pueda.$tel\n\nGracias por tu paciencia."
        }
    }

    // =====================================================================
    // Textos de cada paso
    // =====================================================================

    private fun menu(prefix: String, items: List<String>): String =
        items.mapIndexed { i, s -> "${emoji(if (prefix.isEmpty()) "${i + 1}" else "$prefix.${i + 1}")} $s" }.joinToString("\n")

    private fun prompt(ctx: Ctx): String {
        val c = ctx.conv
        return when (c.step) {
            Step.ASK_NAME -> "¿Cómo te llamas?"
            Step.ASK_MODEL -> "¿Cuál es la *marca y modelo* de tu vehículo? (ej.: Seat León)"
            Step.ASK_YEAR -> "¿De qué *año de fabricación* es? (ej.: 2015)"
            Step.ASK_PLATE -> "¿Cuál es la *matrícula*? (ej.: 1234 ABC)"
            Step.ASK_PHONE ->
                if (c.waPhone.isNotBlank()) "Por último, ¿un *teléfono de contacto*? Si es este mismo número de WhatsApp, responde *1*."
                else "Por último, ¿un *teléfono de contacto*? (ej.: 600 123 456)"
            Step.MAIN_MENU -> "¿En qué podemos ayudarte? Responde con el *número*:\n" + menu("", MAIN)
            Step.ITV_MENU -> "Responde con el *número*:\n" + menu("1", ITV) + "\n\n0️⃣ Volver al menú principal"
            Step.MAINT_MENU -> "Responde con el *número*:\n" + menu("2", MAINT) + "\n\n0️⃣ Volver al menú principal"
            Step.BASIC_MENU -> "*Mantenimiento básico* 🛠️\nPuedes elegir *varios*: responde con todos los números que necesites, separados por comas (ej.: 1, 4, 6).\n\n" +
                menu("2.1", BASIC) + "\n\n0️⃣ Volver"
            Step.PREV_MENU -> "*Mantenimiento preventivo* 🔩\nPuedes elegir *varios*: responde con todos los números que necesites, separados por comas (ej.: 1, 3, 6).\n\n" +
                menu("2.2", PREV) + "\n\n0️⃣ Volver"
            Step.ASK_ITV_PHOTO -> "Para saber por qué ha sido desfavorable, por favor *adjunta una foto del informe de la ITV* 📄📷\n(Si no la tienes a mano, escribe brevemente los defectos que te indicaron.)"
            Step.ASK_ITV_DATE -> "¿En qué *fecha caduca* tu ITV en vigor? 📅 (ej.: 15/03/2027)\nLa encontrarás en la pegatina del parabrisas o en la tarjeta ITV."
            Step.ASK_TIRE_SIZE -> "Has elegido *neumáticos* 🛞 Indícanos la *medida* (viene en el lateral, ej.: 205/55 R16) y *cuántos* quieres cambiar."
            Step.ASK_TIRE_PHOTO -> "Si puedes, envíanos una *foto* del lateral del neumático 📷 donde se vea la medida. Si no, responde *0* para continuar."
            Step.ASK_FAULT_DESC -> "Has elegido *AVERÍA* 🔍 Cuéntanos *brevemente* qué le sucede al vehículo (ruidos, testigos encendidos, desde cuándo…)."
            Step.ASK_TOW_DESC -> "Has elegido *GRÚA* 🚨 Cuéntanos *brevemente* qué le ha sucedido al vehículo y *dónde se encuentra* (dirección o ubicación)."
            Step.ASK_MORE -> "¿Necesitas algo más?\n1️⃣ Sí, otro servicio\n2️⃣ No, eso es todo"
            Step.ASK_SAME_VEHICLE -> "¿Es para el mismo vehículo (*${c.model}*, ${c.plate})?\n1️⃣ Sí\n2️⃣ No, es otro vehículo"
            Step.NEW, Step.DONE, Step.HUMAN -> ""
        }
    }

    fun stepLabel(s: Step): String = when (s) {
        Step.ASK_NAME -> "nombre"
        Step.ASK_MODEL -> "modelo"
        Step.ASK_YEAR -> "año"
        Step.ASK_PLATE -> "matrícula"
        Step.ASK_PHONE -> "teléfono"
        Step.MAIN_MENU -> "menú principal"
        Step.ITV_MENU -> "menú ITV"
        Step.MAINT_MENU -> "menú mantenimiento"
        Step.BASIC_MENU -> "mantenimiento básico"
        Step.PREV_MENU -> "mantenimiento preventivo"
        Step.ASK_ITV_PHOTO -> "foto informe ITV"
        Step.ASK_ITV_DATE -> "fecha caducidad ITV"
        Step.ASK_TIRE_SIZE -> "medida neumáticos"
        Step.ASK_TIRE_PHOTO -> "foto neumáticos"
        Step.ASK_FAULT_DESC -> "descripción avería"
        Step.ASK_TOW_DESC -> "descripción grúa"
        Step.ASK_MORE -> "¿algo más?"
        Step.ASK_SAME_VEHICLE -> "¿mismo vehículo?"
        Step.NEW -> "inicio"
        Step.DONE -> "terminado"
        Step.HUMAN -> "con trabajador"
    }

    // =====================================================================
    // Ayudantes
    // =====================================================================

    private fun go(ctx: Ctx, s: Step) {
        ctx.conv.step = s
        ctx.conv.stepSince = ctx.now
        ctx.conv.failures = 0
    }

    private fun profile(c: Conversation): Profile? = c.profileId?.let { store.getProfile(it) }

    private fun createProfile(ctx: Ctx): Profile {
        val c = ctx.conv
        val p = store.newProfile(c.chatKey, ctx.now)
        p.name = c.name; p.waName = c.waName; p.model = c.model; p.year = c.year; p.plate = c.plate; p.phone = c.phone
        if (p.phone.isBlank() && c.waPhone.isNotBlank()) p.phone = c.waPhone
        p.status = CaseStatus.IN_PROGRESS
        p.transcript.addAll(c.preTranscript)
        c.preTranscript.clear()
        c.profileId = p.id
        setEvent(ctx, CaseEvent.CREATED)
        return p
    }

    /** Añade un servicio al perfil (null = solo asegura que hay perfil). */
    private fun addService(ctx: Ctx, service: String?) {
        val p = profile(ctx.conv) ?: return
        if (service != null && service !in p.services) p.services.add(service)
    }

    private fun note(ctx: Ctx, text: String) {
        val p = profile(ctx.conv) ?: createProfile(ctx)
        p.notes.add("${time(ctx.now)} · $text")
    }

    private val timeFmt = DateTimeFormatter.ofPattern("dd/MM HH:mm")
    private fun time(ms: Long) = Instant.ofEpochMilli(ms).atZone(zone).format(timeFmt)

    private fun log(c: Conversation, who: String, text: String, now: Long) {
        val line = "${time(now)} · $who: $text"
        val target = profile(c)?.transcript ?: c.preTranscript
        target.add(line)
        while (target.size > MAX_TRANSCRIPT) target.removeAt(0)
    }
}

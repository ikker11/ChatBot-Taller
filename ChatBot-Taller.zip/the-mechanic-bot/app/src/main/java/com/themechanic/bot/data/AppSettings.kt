package com.themechanic.bot.data

import com.themechanic.bot.engine.BotSettings
import com.themechanic.bot.engine.ResumeMode
import java.time.Instant
import java.time.ZoneId
import java.time.format.DateTimeFormatter
import java.util.Locale

/** Ajustes de la app (se guardan en el dispositivo). */
object AppSettings {
    private val p get() = Repo.prefs()

    var botEnabled: Boolean
        get() = p.getBoolean("bot", true)
        set(v) { p.edit().putBoolean("bot", v).apply() }

    /** Responder también en WhatsApp normal (además de WhatsApp Business). */
    var watchPersonal: Boolean
        get() = p.getBoolean("personal", false)
        set(v) { p.edit().putBoolean("personal", v).apply() }

    var tallerName: String
        get() = p.getString("nombre", null)?.takeIf { it.isNotBlank() } ?: "The Mechanic Automoción"
        set(v) { p.edit().putString("nombre", v).apply() }

    var tallerPhone: String
        get() = p.getString("telefono", "") ?: ""
        set(v) { p.edit().putString("telefono", v).apply() }

    var hours: String
        get() = p.getString("horario", "") ?: ""
        set(v) { p.edit().putString("horario", v).apply() }

    var address: String
        get() = p.getString("direccion", "") ?: ""
        set(v) { p.edit().putString("direccion", v).apply() }

    /** Minutos de antelación de los dos recordatorios (0 = desactivado). */
    var reminder1: Int
        get() = p.getInt("rem1", 24 * 60)
        set(v) { p.edit().putInt("rem1", v).apply() }

    var reminder2: Int
        get() = p.getInt("rem2", 60)
        set(v) { p.edit().putInt("rem2", v).apply() }

    fun reminderOffsets(): List<Int> = listOf(reminder1, reminder2)

    // ---------- Pausa cuando contesta un trabajador ----------

    /** Minutos que el bot se calla en un chat tras contestar un trabajador (-1 = hasta reactivarlo). */
    var pauseMinutes: Int
        get() = p.getInt("pausa", 24 * 60)
        set(v) { p.edit().putInt("pausa", v).apply() }

    var resumeMode: ResumeMode
        get() = ResumeMode.of(p.getString("reanudar", null))
        set(v) { p.edit().putString("reanudar", v.name).apply() }

    fun pauseMs(): Long = if (pauseMinutes < 0) Long.MAX_VALUE else pauseMinutes * 60_000L

    fun botSettings() = BotSettings(pauseMs = pauseMs(), resumeMode = resumeMode)

    val PAUSE_CHOICES = listOf(30, 60, 120, 240, 480, 720, 24 * 60, 48 * 60, -1)
    fun pauseLabel(min: Int): String = when {
        min < 0 -> "Hasta que lo reactive"
        min < 60 -> "$min minutos"
        min == 60 -> "1 hora"
        else -> "${min / 60} horas"
    }

    // ---------- Contactos que el bot no contesta ----------

    var excluded: List<String>
        get() = (p.getString("excluidos", "") ?: "").split("\n").map { it.trim() }.filter { it.isNotEmpty() }
        set(v) { p.edit().putString("excluidos", v.map { it.trim() }.filter { it.isNotEmpty() }.distinct().joinToString("\n")).apply() }

    private fun norm(s: String) = java.text.Normalizer.normalize(s.lowercase().trim().removePrefix("~").trim(), java.text.Normalizer.Form.NFD)
        .replace(Regex("\\p{Mn}+"), "").replace(Regex("\\s+"), " ")

    /** ¿Está este chat en la lista de contactos excluidos? Compara por nombre o por número. */
    fun isExcluded(name: String, phone: String): Boolean {
        val n = norm(name)
        val nameDigits = name.filter { it.isDigit() }
        val phoneDigits = phone.filter { it.isDigit() }
        return excluded.any { e ->
            val digits = e.filter { it.isDigit() }
            val isNumber = digits.length >= 6 && e.none { it.isLetter() }
            if (isNumber) {
                val tail = digits.takeLast(9)
                (phoneDigits.isNotEmpty() && phoneDigits.endsWith(tail)) || (nameDigits.length >= 6 && nameDigits.endsWith(tail))
            } else {
                norm(e) == n
            }
        }
    }

    fun watchedPackages(): Set<String> =
        if (watchPersonal) setOf("com.whatsapp.w4b", "com.whatsapp") else setOf("com.whatsapp.w4b")

    val REMINDER_CHOICES = listOf(0, 15, 30, 60, 120, 240, 24 * 60, 2 * 24 * 60)
    fun reminderLabel(min: Int): String = when {
        min == 0 -> "Sin aviso"
        min < 60 -> "$min minutos antes"
        min == 60 -> "1 hora antes"
        min < 24 * 60 -> "${min / 60} horas antes"
        min == 24 * 60 -> "1 día antes"
        else -> "${min / (24 * 60)} días antes"
    }
}

/** Formatos de fecha en español. */
object Fmt {
    private val es = Locale("es", "ES")
    private val dt = DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm", es)
    private val sh = DateTimeFormatter.ofPattern("dd/MM HH:mm", es)
    private val tm = DateTimeFormatter.ofPattern("HH:mm", es)
    private val longDate = DateTimeFormatter.ofPattern("EEEE d 'de' MMMM 'de' yyyy", es)

    private fun z(ms: Long) = Instant.ofEpochMilli(ms).atZone(ZoneId.systemDefault())
    fun dateTime(ms: Long): String = z(ms).format(dt)
    fun short(ms: Long): String = z(ms).format(sh)
    fun time(ms: Long): String = z(ms).format(tm)
    fun longDate(d: java.time.LocalDate): String = d.format(longDate).replaceFirstChar { it.titlecase(es) }
    fun longDateTime(ms: Long): String = longDate(z(ms).toLocalDate()) + " a las " + time(ms)
}

package com.themechanic.bot.data

import java.time.Instant
import java.time.ZoneId
import java.time.format.DateTimeFormatter
import java.util.Locale

/** Ajustes de la app (se guardan en el dispositivo). */
object AppSettings {
    private val p get() = Repo.prefs()

    var botEnabled: Boolean
        get() = p.getBoolean("bot", true)
        set(v) { p.edit().putBoolean("bot", v).apply() }

    /** Responder también en WhatsApp normal (además de WhatsApp Business). */
    var watchPersonal: Boolean
        get() = p.getBoolean("personal", false)
        set(v) { p.edit().putBoolean("personal", v).apply() }

    var tallerName: String
        get() = p.getString("nombre", null)?.takeIf { it.isNotBlank() } ?: "The Mechanic Automoción"
        set(v) { p.edit().putString("nombre", v).apply() }

    var tallerPhone: String
        get() = p.getString("telefono", "") ?: ""
        set(v) { p.edit().putString("telefono", v).apply() }

    var hours: String
        get() = p.getString("horario", "") ?: ""
        set(v) { p.edit().putString("horario", v).apply() }

    var address: String
        get() = p.getString("direccion", "") ?: ""
        set(v) { p.edit().putString("direccion", v).apply() }

    /** Minutos de antelación de los dos recordatorios (0 = desactivado). */
    var reminder1: Int
        get() = p.getInt("rem1", 24 * 60)
        set(v) { p.edit().putInt("rem1", v).apply() }

    var reminder2: Int
        get() = p.getInt("rem2", 60)
        set(v) { p.edit().putInt("rem2", v).apply() }

    fun reminderOffsets(): List<Int> = listOf(reminder1, reminder2)

    fun watchedPackages(): Set<String> =
        if (watchPersonal) setOf("com.whatsapp.w4b", "com.whatsapp") else setOf("com.whatsapp.w4b")

    val REMINDER_CHOICES = listOf(0, 15, 30, 60, 120, 240, 24 * 60, 2 * 24 * 60)
    fun reminderLabel(min: Int): String = when {
        min == 0 -> "Sin aviso"
        min < 60 -> "$min minutos antes"
        min == 60 -> "1 hora antes"
        min < 24 * 60 -> "${min / 60} horas antes"
        min == 24 * 60 -> "1 día antes"
        else -> "${min / (24 * 60)} días antes"
    }
}

/** Formatos de fecha en español. */
object Fmt {
    private val es = Locale("es", "ES")
    private val dt = DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm", es)
    private val sh = DateTimeFormatter.ofPattern("dd/MM HH:mm", es)
    private val tm = DateTimeFormatter.ofPattern("HH:mm", es)
    private val longDate = DateTimeFormatter.ofPattern("EEEE d 'de' MMMM 'de' yyyy", es)

    private fun z(ms: Long) = Instant.ofEpochMilli(ms).atZone(ZoneId.systemDefault())
    fun dateTime(ms: Long): String = z(ms).format(dt)
    fun short(ms: Long): String = z(ms).format(sh)
    fun time(ms: Long): String = z(ms).format(tm)
    fun longDate(d: java.time.LocalDate): String = d.format(longDate).replaceFirstChar { it.titlecase(es) }
    fun longDateTime(ms: Long): String = longDate(z(ms).toLocalDate()) + " a las " + time(ms)
}

package com.themechanic.bot.engine

/** Estado de un caso (perfil de cliente) tal como lo ve el trabajador. */
enum class CaseStatus(val label: String) {
    IN_PROGRESS("En curso (cliente respondiendo)"),
    PENDING("Pendiente de revisar"),
    URGENT("URGENTE – Grúa"),
    NEEDS_CONTACT("Contactar con el cliente"),
    SCHEDULED("Cita asignada"),
    CANCELLED("Cita anulada por el cliente"),
    CLOSED("Cerrado");

    companion object {
        fun of(name: String?): CaseStatus = values().firstOrNull { it.name == name } ?: PENDING
    }
}

/** Perfil/caso de un cliente. Se crea cuando el cliente da sus datos. */
class Profile(
    val id: String,
    val chatKey: String,
    val createdAt: Long,
) {
    var name: String = ""
    var waName: String = ""
    var model: String = ""
    var year: String = ""
    var plate: String = ""
    var phone: String = ""
    var itvExpiry: String = ""
    var status: CaseStatus = CaseStatus.IN_PROGRESS
    var updatedAt: Long = createdAt
    var isTest: Boolean = false
    val services: MutableList<String> = mutableListOf()
    val notes: MutableList<String> = mutableListOf()
    val transcript: MutableList<String> = mutableListOf()

    fun vehicleLine(): String = listOf(model, year.takeIf { it.isNotBlank() }?.let { "($it)" } ?: "", plate)
        .filter { it.isNotBlank() }.joinToString(" ")
}

/** Paso en el que está la conversación con un cliente. */
enum class Step {
    NEW, ASK_NAME, ASK_MODEL, ASK_YEAR, ASK_PLATE, ASK_PHONE,
    MAIN_MENU, ITV_MENU, MAINT_MENU, BASIC_MENU, PREV_MENU,
    ASK_ITV_PHOTO, ASK_ITV_DATE, ASK_TIRE_SIZE, ASK_TIRE_PHOTO,
    ASK_FAULT_DESC, ASK_TOW_DESC, ASK_MORE, ASK_SAME_VEHICLE,
    DONE, HUMAN;

    companion object {
        fun of(name: String?): Step = values().firstOrNull { it.name == name } ?: NEW
    }
}

/** Estado de la conversación con un chat de WhatsApp. */
class Conversation(val chatKey: String) {
    var step: Step = Step.NEW
    var stepSince: Long = 0L
    var failures: Int = 0
    var kbAnswers: Int = 0
    var profileId: String? = null
    var waName: String = ""
    /** Teléfono deducido del propio WhatsApp (si Android lo da). */
    var waPhone: String = ""
    var name: String = ""
    var model: String = ""
    var year: String = ""
    var plate: String = ""
    var phone: String = ""
    var keepPhone: Boolean = false
    var doneAt: Long = 0L
    var doneNoticeSent: Boolean = false
    var lastProcessedTs: Long = 0L
    /** Paso en el que estaba cuando se pausó el bot (para "seguir donde lo dejó"). */
    var pausedStep: Step = Step.NEW
    /** Último mensaje del cliente (la memoria del bot dura 6 meses desde aquí). */
    var lastActivity: Long = 0L
    val preTranscript: MutableList<String> = mutableListOf()
    /** Últimas respuestas enviadas por el bot (para no confundirlas con mensajes de un humano). */
    val recentBotReplies: MutableList<String> = mutableListOf()
}

enum class MsgKind { TEXT, PHOTO, AUDIO, LOCATION, OTHER_MEDIA }

data class Incoming(val text: String, val kind: MsgKind = MessageClassifier.classify(text))

/** Datos del taller que aparecen en los mensajes. Editables desde Ajustes. */
data class TallerInfo(
    val name: String = "The Mechanic Automoción",
    val phone: String = "",
    val hours: String = "",
    val address: String = "",
)

enum class CaseEvent { CREATED, UPDATED, COMPLETED, NEEDS_CONTACT, RESCHEDULE, URGENT, CANCELLED }

/** Referencia a una cita del calendario (para que el motor pueda anularla). */
data class ApptRef(val id: String, val at: Long, val profileId: String?)

/** Qué hace el bot cuando termina la pausa (tras contestar un trabajador). */
enum class ResumeMode(val label: String, val description: String) {
    RESTART("Empezar de nuevo", "Saluda otra vez y pregunta si es para el mismo vehículo"),
    MENU("Mostrar el menú", "Saluda y enseña directamente el menú de servicios"),
    CONTINUE("Seguir donde se quedó", "Repite la última pregunta que tenía pendiente");

    companion object {
        fun of(name: String?): ResumeMode = values().firstOrNull { it.name == name } ?: RESTART
    }
}

/** Ajustes del comportamiento del bot. */
data class BotSettings(
    /** Tiempo que el bot se calla en un chat tras contestar un trabajador (Long.MAX_VALUE = hasta reactivarlo). */
    val pauseMs: Long = 24L * 60 * 60 * 1000,
    val resumeMode: ResumeMode = ResumeMode.RESTART,
)

/** Donde el motor guarda los perfiles (Android lo implementa con archivos; los tests en memoria). */
interface CaseStore {
    fun newProfile(chatKey: String, now: Long): Profile
    fun getProfile(id: String): Profile?
    fun onProfileChanged(profile: Profile, event: CaseEvent)

    /** Último perfil de este chat desde la fecha indicada (memoria del bot). */
    fun latestProfileFor(chatKey: String, since: Long): Profile? = null

    /** Citas futuras de este chat. */
    fun upcomingAppointments(chatKey: String, now: Long): List<ApptRef> = emptyList()

    /** Borra una cita del calendario (la ha anulado el cliente). */
    fun cancelAppointment(id: String) {}
}

object MessageClassifier {
    fun classify(raw: String): MsgKind {
        val t = raw.trim()
        val low = t.lowercase()
        return when {
            t.startsWith("📷") || low == "foto" || low == "photo" || low == "imagen" -> MsgKind.PHOTO
            t.startsWith("🎤") || t.startsWith("🎵") || low.startsWith("mensaje de voz") ||
                low.startsWith("nota de voz") || low == "audio" -> MsgKind.AUDIO
            t.startsWith("📍") || low.startsWith("ubicación") || low.startsWith("ubicacion") -> MsgKind.LOCATION
            t.startsWith("📄") || t.startsWith("🎥") || t.startsWith("📹") || t.startsWith("🎬") ||
                low == "sticker" || low == "gif" || low.startsWith("📇") -> MsgKind.OTHER_MEDIA
            else -> MsgKind.TEXT
        }
    }
}

package com.themechanic.bot.notify

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import com.themechanic.bot.R
import com.themechanic.bot.data.Appointment
import com.themechanic.bot.data.AppSettings
import com.themechanic.bot.data.Fmt
import com.themechanic.bot.engine.CaseEvent
import com.themechanic.bot.engine.Profile
import com.themechanic.bot.ui.MainActivity
import com.themechanic.bot.ui.ProfileActivity

/** Avisos al trabajador: casos nuevos, urgencias y recordatorios de citas. */
object Notifier {
    const val CH_CASES = "casos"
    const val CH_URGENT = "urgentes"
    const val CH_REMINDERS = "recordatorios"

    fun createChannels(ctx: Context) {
        val nm = ctx.getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel(CH_CASES, "Casos nuevos", NotificationManager.IMPORTANCE_DEFAULT).apply {
            description = "Cuando un cliente termina de dar sus datos o necesita que le contactéis"
        })
        nm.createNotificationChannel(NotificationChannel(CH_URGENT, "Urgencias (grúa)", NotificationManager.IMPORTANCE_HIGH).apply {
            description = "Clientes que piden grúa"
        })
        nm.createNotificationChannel(NotificationChannel(CH_REMINDERS, "Recordatorios de citas", NotificationManager.IMPORTANCE_HIGH).apply {
            description = "Avisos antes de cada cita del calendario"
        })
    }

    private fun openProfile(ctx: Context, profileId: String?, req: Int): PendingIntent {
        val intent = if (profileId != null) {
            Intent(ctx, ProfileActivity::class.java).putExtra(ProfileActivity.EXTRA_ID, profileId)
        } else {
            Intent(ctx, MainActivity::class.java).putExtra(MainActivity.EXTRA_TAB, 1)
        }
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
        return PendingIntent.getActivity(ctx, req, intent, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
    }

    fun caseEvent(ctx: Context, p: Profile, event: CaseEvent) {
        val (channel, title) = when (event) {
            CaseEvent.URGENT -> CH_URGENT to "🚨 GRÚA: ${p.name.ifBlank { p.waName }}"
            CaseEvent.NEEDS_CONTACT -> CH_CASES to "👤 Contactar: ${p.name.ifBlank { p.waName }}"
            else -> CH_CASES to "🔧 Nuevo caso: ${p.name.ifBlank { p.waName }}"
        }
        val test = if (p.isTest) " (PRUEBA)" else ""
        val body = listOf(p.vehicleLine(), p.services.joinToString(", ")).filter { it.isNotBlank() }.joinToString("\n")
        val n = Notification.Builder(ctx, channel)
            .setSmallIcon(R.drawable.ic_wrench)
            .setContentTitle(title + test)
            .setContentText(body.ifBlank { "Toca para ver el caso" })
            .setStyle(Notification.BigTextStyle().bigText(body.ifBlank { "Toca para ver el caso" }))
            .setContentIntent(openProfile(ctx, p.id, p.id.hashCode()))
            .setAutoCancel(true)
            .setCategory(Notification.CATEGORY_MESSAGE)
            .build()
        ctx.getSystemService(NotificationManager::class.java).notify(p.id.hashCode(), n)
    }

    fun reminder(ctx: Context, a: Appointment, p: Profile?, minutesBefore: Int) {
        val who = p?.let { listOf(it.name, it.vehicleLine()).filter { s -> s.isNotBlank() }.joinToString(" · ") } ?: a.title
        val services = p?.services?.joinToString(", ").orEmpty()
        val n = Notification.Builder(ctx, CH_REMINDERS)
            .setSmallIcon(R.drawable.ic_wrench)
            .setContentTitle("📅 Cita ${AppSettings.reminderLabel(minutesBefore).replace(" antes", "")}: ${Fmt.time(a.at)}")
            .setContentText(who)
            .setStyle(Notification.BigTextStyle().bigText("${Fmt.longDateTime(a.at)}\n$who" + if (services.isNotBlank()) "\n$services" else ""))
            .setContentIntent(openProfile(ctx, a.profileId, a.id.hashCode()))
            .setAutoCancel(true)
            .setCategory(Notification.CATEGORY_REMINDER)
            .build()
        ctx.getSystemService(NotificationManager::class.java).notify((a.id + minutesBefore).hashCode(), n)
    }
}

package com.themechanic.bot

import android.app.Application
import com.themechanic.bot.data.Repo
import com.themechanic.bot.notify.Notifier

class App : Application() {
    override fun onCreate() {
        super.onCreate()
        Repo.init(this)
        Notifier.createChannels(this)
    }
}

package com.themechanic.bot.engine

import java.text.Normalizer
import java.time.LocalDate
import java.time.YearMonth

/** Utilidades para entender lo que escribe el cliente. */
object TextParsing {

    private val NUMBER_WORDS = mapOf(
        "cero" to "0", "uno" to "1", "dos" to "2", "tres" to "3", "cuatro" to "4",
        "cinco" to "5", "seis" to "6", "siete" to "7", "ocho" to "8", "nueve" to "9",
        "primero" to "1", "primera" to "1", "segundo" to "2", "segunda" to "2",
        "tercero" to "3", "tercera" to "3",
    )

    /** Minúsculas, sin tildes y sin emojis "keycap" (1️⃣ → 1). */
    fun normalize(raw: String): String {
        var s = raw.replace("️", "").replace("⃣", "").replace("🔟", "10")
        s = Normalizer.normalize(s.lowercase(), Normalizer.Form.NFD).replace(Regex("\\p{Mn}+"), "")
        return s.trim()
    }

    /** Convierte palabras numéricas a cifras: "uno punto dos" → "1.2". */
    fun numberize(raw: String): String {
        var s = normalize(raw)
        s = Regex("[a-z]+").replace(s) { m -> NUMBER_WORDS[m.value] ?: m.value }
        repeat(3) { s = Regex("(\\d)\\s*punto\\s*(\\d)").replace(s, "$1.$2") }
        // Une "1 . 2" → "1.2" (repetido para cadenas tipo 2 . 1 . 3)
        repeat(3) { s = Regex("(\\d)\\s*\\.\\s*(\\d)").replace(s, "$1.$2") }
        return s
    }

    /** Códigos numéricos encontrados en el texto, p. ej. "1, 2.1.4 y tres" → [[1],[2,1,4],[3]]. */
    fun numberTokens(raw: String): List<List<Int>> {
        val s = numberize(raw)
        return Regex("\\d+(?:\\.\\d+)*").findAll(s)
            .map { m -> m.value.split('.').mapNotNull { it.toIntOrNull() } }
            .filter { it.isNotEmpty() }
            .toList()
    }

    /**
     * Interpreta un código respecto a un menú con prefijo (ej. prefijo [2,1]).
     * Acepta "4", "1.4" o "2.1.4" → 4. Devuelve null si no encaja.
     */
    fun relative(token: List<Int>, prefix: List<Int>): Int? {
        if (token.size == 1) return token[0]
        val head = token.dropLast(1)
        if (head.size > prefix.size) return null
        return if (prefix.takeLast(head.size) == head) token.last() else null
    }

    fun words(raw: String): Set<String> =
        normalize(raw).split(Regex("[^a-z0-9]+")).filter { it.isNotBlank() }.toSet()

    fun containsAny(raw: String, phrases: Collection<String>): Boolean {
        val n = " " + normalize(raw).replace(Regex("[^a-z0-9/]+"), " ") + " "
        return phrases.any { p -> n.contains(" " + normalize(p) + " ") }
    }

    fun hasLetters(raw: String) = raw.any { it.isLetter() }

    // ---------- Datos del vehículo ----------

    fun parseYear(raw: String, currentYear: Int): Int? {
        val s = normalize(raw)
        Regex("(?<!\\d)(19[5-9]\\d|20\\d\\d)(?!\\d)").find(s)?.let { m ->
            val y = m.value.toInt()
            return if (y in 1950..currentYear + 1) y else null
        }
        val two = Regex("^(?:del?\\s+|año\\s+|ano\\s+)?'?(\\d{2})$").find(s)?.groupValues?.get(1)?.toInt()
            ?: return null
        val cy = currentYear % 100
        return if (two <= cy + 1) 2000 + two else 1900 + two
    }

    fun parsePlate(raw: String): String? {
        val s = normalize(raw).uppercase().replace(Regex("^(?:MATRICULA|ES|LA)\\s*:?\\s*"), "")
        val c = s.replace(Regex("[^A-Z0-9]"), "")
        Regex("(\\d{4})([A-Z]{3})").find(c)?.let { m ->
            return "${m.groupValues[1]} ${m.groupValues[2]}"
        }
        Regex("^([A-Z]{1,2})(\\d{4})([A-Z]{0,2})$").find(c)?.let { m ->
            return listOf(m.groupValues[1], m.groupValues[2], m.groupValues[3]).filter { it.isNotEmpty() }.joinToString("-")
        }
        // Otras matrículas (extranjeras, especiales): entre 4 y 10 caracteres con letras y números
        if (c.length in 4..10 && c.any { it.isDigit() } && c.any { it.isLetter() } && !s.contains(Regex("\\s{2,}"))) {
            val tokens = s.trim().split(Regex("\\s+"))
            if (tokens.size <= 3) return c
        }
        return null
    }

    fun parsePhone(raw: String): String? {
        val digits = raw.filter { it.isDigit() }
        if (digits.length < 9 || digits.length > 15) return null
        if (raw.count { it.isLetter() } > 12) return null
        return if (digits.length == 9) digits.chunked(3).joinToString(" ") else "+$digits"
    }

    private val MONTHS = mapOf(
        "enero" to 1, "febrero" to 2, "marzo" to 3, "abril" to 4, "mayo" to 5, "junio" to 6,
        "julio" to 7, "agosto" to 8, "septiembre" to 9, "setiembre" to 9, "octubre" to 10,
        "noviembre" to 11, "diciembre" to 12,
    )

    /** Fecha de caducidad de la ITV. Acepta 15/03/2027, 15-3-27, "15 de marzo de 2027", "marzo 2027", "03/2027". */
    fun parseDate(raw: String, today: LocalDate): String? {
        val s = normalize(raw)
        fun fixYear(y: Int) = if (y < 100) 2000 + y else y
        fun ok(y: Int) = y in today.year - 2..today.year + 6

        Regex("(\\d{1,2})\\s*[/\\-.]\\s*(\\d{1,2})\\s*[/\\-.]\\s*(\\d{2,4})").find(s)?.let { m ->
            val d = m.groupValues[1].toInt(); val mo = m.groupValues[2].toInt(); val y = fixYear(m.groupValues[3].toInt())
            return runCatching { LocalDate.of(y, mo, d) }.getOrNull()?.takeIf { ok(y) }?.let { fmt(it) }
        }
        Regex("(?:(\\d{1,2})\\s*(?:de\\s+)?)?([a-z]+)\\s*(?:de\\s+|del\\s+)?(\\d{2,4})").findAll(s).forEach { m ->
            val mo = MONTHS[m.groupValues[2]] ?: return@forEach
            val y = fixYear(m.groupValues[3].toInt())
            if (!ok(y)) return@forEach
            val dStr = m.groupValues[1]
            return if (dStr.isNotEmpty()) {
                runCatching { LocalDate.of(y, mo, dStr.toInt()) }.getOrNull()?.let { fmt(it) }
            } else {
                "${MONTHS.entries.first { it.value == mo }.key} de $y"
            }
        }
        Regex("(?<![\\d/])(\\d{1,2})\\s*[/\\-]\\s*(\\d{4}|\\d{2})(?![\\d/])").find(s)?.let { m ->
            val mo = m.groupValues[1].toInt(); val y = fixYear(m.groupValues[2].toInt())
            if (mo in 1..12 && ok(y)) {
                val ym = YearMonth.of(y, mo)
                return "${MONTHS.entries.first { it.value == ym.monthValue }.key} de ${ym.year}"
            }
        }
        return null
    }

    private fun fmt(d: LocalDate) = "%02d/%02d/%04d".format(d.dayOfMonth, d.monthValue, d.year)

    fun tireSize(raw: String): String? =
        Regex("(\\d{3})\\s*/\\s*(\\d{2})\\s*(?:z?r)?\\s*(\\d{2})", RegexOption.IGNORE_CASE).find(raw)
            ?.let { "${it.groupValues[1]}/${it.groupValues[2]} R${it.groupValues[3]}" }

    // ---------- Intenciones ----------

    private val HUMAN_PHRASES = listOf(
        "hablar con", "habla con", "pasame con", "ponme con", "persona", "humano", "trabajador",
        "operador", "encargado", "agente", "que me llamen", "llamadme", "llamame", "me podeis llamar",
        "me puedes llamar", "me podrian llamar",
    )

    fun wantsHuman(raw: String): Boolean = containsAny(raw, HUMAN_PHRASES)

    private val YES = listOf("si", "sip", "vale", "claro", "ok", "okey", "de acuerdo", "por supuesto", "afirmativo", "mismo")
    private val NO = listOf("no", "nada", "nada mas", "eso es todo", "ya esta", "es todo", "ninguno", "ninguna", "otro", "otra", "diferente", "distinto")

    /** 1 = sí, 2 = no, null = no se sabe. Admite número o palabra. */
    fun yesNo(raw: String): Int? {
        val nums = numberTokens(raw).filter { it.size == 1 }.map { it[0] }
        if (nums.size == 1 && nums[0] in 1..2) return nums[0]
        val no = containsAny(raw, NO)
        val yes = containsAny(raw, YES)
        return when {
            no && !yes -> 2
            yes && !no -> 1
            else -> null
        }
    }

    fun isGreeting(raw: String): Boolean = containsAny(raw, listOf("hola", "buenas", "buenos dias", "buenas tardes", "buenas noches", "hey", "saludos"))
}

package com.themechanic.bot.data

import android.content.Context
import android.content.SharedPreferences
import android.os.Handler
import android.os.Looper
import com.themechanic.bot.engine.BotEngine
import com.themechanic.bot.engine.CaseEvent
import com.themechanic.bot.engine.CaseStatus
import com.themechanic.bot.engine.CaseStore
import com.themechanic.bot.engine.Conversation
import com.themechanic.bot.engine.Profile
import com.themechanic.bot.engine.Step
import com.themechanic.bot.engine.TallerInfo
import com.themechanic.bot.notify.Notifier
import com.themechanic.bot.notify.Reminders
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.time.Instant
import java.time.LocalDate
import java.time.ZoneId
import java.util.concurrent.CopyOnWriteArrayList
import kotlin.random.Random

/** Cita del calendario (puede estar ligada a un perfil o ser libre). */
class Appointment(val id: String, var profileId: String?, var title: String, var at: Long, var notes: String = "")

/**
 * Todos los datos de la app, guardados en un archivo JSON dentro del dispositivo.
 * Nada sale del dispositivo.
 */
object Repo : CaseStore {
    val lock = Any()
    const val SIM_KEY = "__simulador__"

    private var appCtx: Context? = null
    private val profiles = LinkedHashMap<String, Profile>()
    private val convs = HashMap<String, Conversation>()
    private val appts = LinkedHashMap<String, Appointment>()
    private val listeners = CopyOnWriteArrayList<Runnable>()
    private val main = Handler(Looper.getMainLooper())
    @Volatile private var loaded = false

    val engine: BotEngine by lazy { BotEngine(this, { tallerInfo() }) }

    fun init(context: Context) {
        synchronized(lock) {
            if (loaded) return
            appCtx = context.applicationContext
            load()
            loaded = true
        }
    }

    val ctx: Context get() = appCtx ?: error("Repo no inicializado")

    fun prefs(): SharedPreferences = ctx.getSharedPreferences("ajustes", Context.MODE_PRIVATE)

    fun tallerInfo() = TallerInfo(
        name = AppSettings.tallerName,
        phone = AppSettings.tallerPhone,
        hours = AppSettings.hours,
        address = AppSettings.address,
    )

    // ------------------------------------------------------------------
    // Escuchas para refrescar la pantalla
    // ------------------------------------------------------------------
    fun addListener(r: Runnable) { listeners.add(r) }
    fun removeListener(r: Runnable) { listeners.remove(r) }
    fun notifyListeners() { main.post { listeners.forEach { it.run() } } }

    /** Cambia datos de forma segura, guarda y refresca la pantalla. */
    fun <T> mutate(block: () -> T): T {
        val r = synchronized(lock) { block().also { save() } }
        notifyListeners()
        return r
    }

    // ------------------------------------------------------------------
    // CaseStore (lo usa el motor del bot)
    // ------------------------------------------------------------------
    override fun newProfile(chatKey: String, now: Long): Profile {
        val id = "c${now}_${Random.nextInt(1000, 9999)}"
        val p = Profile(id, chatKey, now)
        p.isTest = chatKey == SIM_KEY
        profiles[id] = p
        return p
    }

    override fun getProfile(id: String): Profile? = profiles[id]

    override fun onProfileChanged(profile: Profile, event: CaseEvent) {
        save()
        notifyListeners()
        if (event == CaseEvent.COMPLETED || event == CaseEvent.NEEDS_CONTACT || event == CaseEvent.URGENT) {
            runCatching { Notifier.caseEvent(ctx, profile, event) }
        }
    }

    // ------------------------------------------------------------------
    // Consultas para la interfaz
    // ------------------------------------------------------------------
    fun conversationFor(chatKey: String): Conversation = synchronized(lock) { convs.getOrPut(chatKey) { Conversation(chatKey) } }

    fun profilesSorted(): List<Profile> = synchronized(lock) { profiles.values.sortedBy { it.createdAt } }

    fun profile(id: String?): Profile? = synchronized(lock) { id?.let { profiles[it] } }

    fun appointment(id: String?): Appointment? = synchronized(lock) { id?.let { appts[it] } }

    fun allAppointments(): List<Appointment> = synchronized(lock) { appts.values.sortedBy { it.at } }

    fun appointmentsFor(profileId: String): List<Appointment> = allAppointments().filter { it.profileId == profileId }

    fun appointmentsOn(date: LocalDate): List<Appointment> = allAppointments().filter { dateOf(it.at) == date }

    fun upcoming(limit: Int): List<Appointment> {
        val now = System.currentTimeMillis()
        return allAppointments().filter { it.at >= now - 60 * 60 * 1000 }.take(limit)
    }

    fun dateOf(ms: Long): LocalDate = Instant.ofEpochMilli(ms).atZone(ZoneId.systemDefault()).toLocalDate()

    fun isBotPaused(p: Profile): Boolean = synchronized(lock) {
        val c = convs[p.chatKey] ?: return@synchronized false
        c.step == Step.HUMAN && System.currentTimeMillis() - c.stepSince < BotEngine.HUMAN_QUIET_MS && c.profileId == p.id
    }

    // ------------------------------------------------------------------
    // Acciones desde la interfaz
    // ------------------------------------------------------------------
    fun addAppointment(profileId: String?, title: String, at: Long): Appointment {
        val a = mutate {
            val appt = Appointment("a${System.currentTimeMillis()}_${Random.nextInt(1000, 9999)}", profileId, title, at)
            appts[appt.id] = appt
            profileId?.let { profiles[it] }?.let { p ->
                p.status = CaseStatus.SCHEDULED
                p.notes.add("${stamp()} · 📅 Cita asignada: ${Fmt.dateTime(at)}")
                p.updatedAt = System.currentTimeMillis()
            }
            appt
        }
        Reminders.schedule(ctx, a)
        return a
    }

    fun deleteAppointment(id: String) {
        val a = synchronized(lock) { appts[id] } ?: return
        Reminders.cancel(ctx, a)
        mutate {
            appts.remove(id)
            a.profileId?.let { profiles[it] }?.let { p ->
                p.notes.add("${stamp()} · Cita del ${Fmt.dateTime(a.at)} eliminada")
                if (p.status == CaseStatus.SCHEDULED && appts.values.none { it.profileId == p.id }) p.status = CaseStatus.PENDING
            }
        }
    }

    fun setStatus(id: String, s: CaseStatus) = mutate { profiles[id]?.let { it.status = s; it.updatedAt = System.currentTimeMillis() } }

    fun addNote(id: String, text: String) = mutate { profiles[id]?.notes?.add("${stamp()} · ✍️ $text") }

    fun deleteProfile(id: String) {
        appointmentsFor(id).forEach { deleteAppointment(it.id) }
        mutate {
            val p = profiles.remove(id)
            if (p != null) convs[p.chatKey]?.let { c -> if (c.profileId == id) c.profileId = null }
        }
    }

    /** El trabajador atiende este chat: el bot se calla 24 h en él. */
    fun pauseBot(p: Profile, reason: String) = mutate {
        val c = convs.getOrPut(p.chatKey) { Conversation(p.chatKey) }
        c.step = Step.HUMAN
        c.stepSince = System.currentTimeMillis()
        c.profileId = p.id
        p.notes.add("${stamp()} · ⏸️ Bot en pausa en este chat ($reason)")
    }

    /** El bot vuelve a atender: el próximo mensaje del cliente empieza una conversación nueva. */
    fun resumeBot(p: Profile) = mutate {
        convs[p.chatKey]?.let { engine.reset(it) }
        p.notes.add("${stamp()} · ▶️ Bot reactivado en este chat")
    }

    fun resetSimulator() = mutate { convs.remove(SIM_KEY) }

    fun clearTests() {
        profilesSorted().filter { it.isTest }.forEach { deleteProfile(it.id) }
        resetSimulator()
    }

    fun stamp(): String = Fmt.short(System.currentTimeMillis())

    // ------------------------------------------------------------------
    // Guardado en archivo JSON
    // ------------------------------------------------------------------
    private fun file() = File(ctx.filesDir, "datos.json")

    fun save() {
        synchronized(lock) {
            val root = JSONObject()
            root.put("version", 1)
            root.put("profiles", JSONArray().apply { profiles.values.forEach { put(profileJson(it)) } })
            root.put("conversations", JSONArray().apply { convs.values.forEach { put(convJson(it)) } })
            root.put("appointments", JSONArray().apply { appts.values.forEach { put(apptJson(it)) } })
            val tmp = File(ctx.filesDir, "datos.json.tmp")
            tmp.writeText(root.toString())
            if (!tmp.renameTo(file())) {
                file().writeText(root.toString())
                tmp.delete()
            }
        }
    }

    private fun load() {
        val f = file()
        if (!f.exists()) return
        val root = runCatching { JSONObject(f.readText()) }.getOrNull() ?: return
        root.optJSONArray("profiles")?.let { arr -> for (i in 0 until arr.length()) profileFrom(arr.getJSONObject(i)).let { profiles[it.id] = it } }
        root.optJSONArray("conversations")?.let { arr -> for (i in 0 until arr.length()) convFrom(arr.getJSONObject(i)).let { convs[it.chatKey] = it } }
        root.optJSONArray("appointments")?.let { arr -> for (i in 0 until arr.length()) apptFrom(arr.getJSONObject(i)).let { appts[it.id] = it } }
    }

    private fun strings(list: List<String>) = JSONArray().apply { list.forEach { put(it) } }
    private fun JSONObject.strList(key: String): List<String> {
        val a = optJSONArray(key) ?: return emptyList()
        return (0 until a.length()).map { a.optString(it) }
    }

    private fun profileJson(p: Profile) = JSONObject().apply {
        put("id", p.id); put("chatKey", p.chatKey); put("createdAt", p.createdAt)
        put("name", p.name); put("waName", p.waName); put("model", p.model); put("year", p.year)
        put("plate", p.plate); put("phone", p.phone); put("itvExpiry", p.itvExpiry)
        put("status", p.status.name); put("updatedAt", p.updatedAt); put("isTest", p.isTest)
        put("services", strings(p.services)); put("notes", strings(p.notes)); put("transcript", strings(p.transcript))
    }

    private fun profileFrom(o: JSONObject) = Profile(o.getString("id"), o.optString("chatKey"), o.optLong("createdAt")).apply {
        name = o.optString("name"); waName = o.optString("waName"); model = o.optString("model"); year = o.optString("year")
        plate = o.optString("plate"); phone = o.optString("phone"); itvExpiry = o.optString("itvExpiry")
        status = CaseStatus.of(o.optString("status")); updatedAt = o.optLong("updatedAt", createdAt); isTest = o.optBoolean("isTest")
        services.addAll(o.strList("services")); notes.addAll(o.strList("notes")); transcript.addAll(o.strList("transcript"))
    }

    private fun convJson(c: Conversation) = JSONObject().apply {
        put("chatKey", c.chatKey); put("step", c.step.name); put("stepSince", c.stepSince); put("failures", c.failures)
        put("kbAnswers", c.kbAnswers); put("profileId", c.profileId ?: ""); put("waName", c.waName); put("waPhone", c.waPhone)
        put("name", c.name); put("model", c.model); put("year", c.year); put("plate", c.plate); put("phone", c.phone)
        put("keepPhone", c.keepPhone); put("doneAt", c.doneAt); put("doneNoticeSent", c.doneNoticeSent)
        put("lastProcessedTs", c.lastProcessedTs); put("preTranscript", strings(c.preTranscript))
        put("recentBotReplies", strings(c.recentBotReplies))
    }

    private fun convFrom(o: JSONObject) = Conversation(o.getString("chatKey")).apply {
        step = Step.of(o.optString("step")); stepSince = o.optLong("stepSince"); failures = o.optInt("failures")
        kbAnswers = o.optInt("kbAnswers"); profileId = o.optString("profileId").ifBlank { null }
        waName = o.optString("waName"); waPhone = o.optString("waPhone")
        name = o.optString("name"); model = o.optString("model"); year = o.optString("year"); plate = o.optString("plate"); phone = o.optString("phone")
        keepPhone = o.optBoolean("keepPhone"); doneAt = o.optLong("doneAt"); doneNoticeSent = o.optBoolean("doneNoticeSent")
        lastProcessedTs = o.optLong("lastProcessedTs")
        preTranscript.addAll(o.strList("preTranscript")); recentBotReplies.addAll(o.strList("recentBotReplies"))
    }

    private fun apptJson(a: Appointment) = JSONObject().apply {
        put("id", a.id); put("profileId", a.profileId ?: ""); put("title", a.title); put("at", a.at); put("notes", a.notes)
    }

    private fun apptFrom(o: JSONObject) = Appointment(
        o.getString("id"), o.optString("profileId").ifBlank { null }, o.optString("title"), o.optLong("at"), o.optString("notes"),
    )

    /** Exporta todos los casos como texto CSV (para compartir o guardar). */
    fun exportCsv(): String {
        fun q(s: String) = "\"" + s.replace("\"", "\"\"") + "\""
        val sb = StringBuilder("recibido;nombre;telefono;vehiculo;año;matricula;estado;servicios;notas;citas\n")
        profilesSorted().filter { !it.isTest }.forEach { p ->
            val citas = appointmentsFor(p.id).joinToString(" | ") { Fmt.dateTime(it.at) }
            sb.append(listOf(Fmt.dateTime(p.createdAt), p.name, p.phone, p.model, p.year, p.plate, p.status.label,
                p.services.joinToString(" | "), p.notes.joinToString(" | "), citas).joinToString(";") { q(it) }).append('\n')
        }
        return sb.toString()
    }
}

package com.themechanic.bot.service

import android.app.Notification
import android.app.RemoteInput
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import android.util.Log
import androidx.core.app.NotificationCompat
import com.themechanic.bot.data.AppSettings
import com.themechanic.bot.data.Repo
import com.themechanic.bot.engine.Incoming
import java.util.concurrent.Executors

/**
 * Lee las notificaciones de WhatsApp Business y contesta con el botón "Responder".
 * Funciona mientras el dispositivo esté encendido y con conexión.
 */
class WhatsAppListener : NotificationListenerService() {

    companion object {
        private const val TAG = "TheMechanicBot"
        /** Al instalar o reiniciar, no contestamos mensajes más antiguos que esto. */
        private const val MAX_AGE_MS = 10 * 60 * 1000L
        private const val REPLY_DELAY_MS = 2000L

        @Volatile var connected = false

        fun isEnabled(ctx: Context): Boolean {
            val flat = Settings.Secure.getString(ctx.contentResolver, "enabled_notification_listeners") ?: return false
            val me = ComponentName(ctx, WhatsAppListener::class.java)
            return flat.split(":").any { ComponentName.unflattenFromString(it) == me }
        }
    }

    private val worker = Executors.newSingleThreadExecutor()
    private val main = Handler(Looper.getMainLooper())

    private class Msg(val text: String, val ts: Long, val fromMe: Boolean)

    override fun onListenerConnected() {
        Repo.init(applicationContext)
        connected = true
        Repo.notifyListeners()
    }

    override fun onListenerDisconnected() {
        connected = false
        Repo.notifyListeners()
        requestRebind(ComponentName(this, WhatsAppListener::class.java))
    }

    override fun onNotificationPosted(sbn: StatusBarNotification) {
        try {
            Repo.init(applicationContext)
            if (!AppSettings.botEnabled) return
            if (sbn.packageName !in AppSettings.watchedPackages()) return
            val n = sbn.notification ?: return
            if (n.flags and Notification.FLAG_GROUP_SUMMARY != 0) return
            val action = findReplyAction(n) ?: return
            worker.execute { runCatching { process(sbn, n, action) }.onFailure { Log.e(TAG, "Error procesando", it) } }
        } catch (e: Exception) {
            Log.e(TAG, "Error", e)
        }
    }

    private fun findReplyAction(n: Notification): Notification.Action? {
        val candidates = (n.actions?.toList() ?: emptyList()) + Notification.WearableExtender(n).actions
        val withInput = candidates.filter { a -> a.remoteInputs?.any { it.allowFreeFormInput } == true }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
            withInput.firstOrNull { it.semanticAction == Notification.Action.SEMANTIC_ACTION_REPLY }?.let { return it }
        }
        return withInput.firstOrNull()
    }

    private fun process(sbn: StatusBarNotification, n: Notification, action: Notification.Action) {
        val extras = n.extras
        val style = NotificationCompat.MessagingStyle.extractMessagingStyleFromNotification(n)
        val shortcut = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) n.shortcutId else null

        // Ignorar grupos
        val isGroup = style?.isGroupConversation == true ||
            extras.getBoolean(Notification.EXTRA_IS_GROUP_CONVERSATION, false) ||
            shortcut?.endsWith("@g.us") == true ||
            sbn.tag?.endsWith("@g.us") == true
        if (isGroup) return

        val title = extras.getCharSequence(Notification.EXTRA_TITLE)?.toString().orEmpty()
        val chatKey = sbn.packageName + "|" + (shortcut ?: sbn.tag?.takeIf { it.contains("@") } ?: title)
        if (title.isBlank() && shortcut == null) return

        val myName = style?.user?.name?.toString()
        val messages: List<Msg> = style?.messages?.mapNotNull { m ->
            val text = m.text?.toString() ?: return@mapNotNull null
            val sender = m.person?.name?.toString()
            Msg(text, m.timestamp, m.person == null || (myName != null && sender == myName))
        } ?: listOfNotNull(
            extras.getCharSequence(Notification.EXTRA_TEXT)?.toString()?.let { Msg(it, sbn.postTime, false) },
        )
        if (messages.isEmpty()) return

        val now = System.currentTimeMillis()
        var reply: String? = null

        // Contactos que el bot no debe contestar
        if (AppSettings.isExcluded(title, phoneFromJid(shortcut ?: sbn.tag) ?: "")) return

        synchronized(Repo.lock) {
            val conv = Repo.conversationFor(chatKey)
            if (conv.waName.isBlank()) conv.waName = title
            phoneFromJid(shortcut ?: sbn.tag)?.let { conv.waPhone = it }

            val fresh = messages.filter { it.ts > conv.lastProcessedTs && (conv.lastProcessedTs > 0 || now - it.ts < MAX_AGE_MS) }
                .sortedBy { it.ts }
            if (fresh.isEmpty()) return
            conv.lastProcessedTs = maxOf(conv.lastProcessedTs, fresh.maxOf { it.ts })

            for (m in fresh) {
                if (m.fromMe) {
                    // ¿Lo escribió el bot o una persona del taller?
                    val mine = conv.recentBotReplies.any { same(it, m.text) }
                    if (!mine) {
                        // Ha contestado una persona del taller: el bot se calla el tiempo elegido en Ajustes
                        Repo.engine.pause(conv, now)
                        Repo.profile(conv.profileId)?.notes?.add("${Repo.stamp()} · ⏸️ Un trabajador ha respondido a mano; bot en pausa (${AppSettings.pauseLabel(AppSettings.pauseMinutes).lowercase()})")
                    }
                    continue
                }
                val r = Repo.engine.handle(conv, Incoming(m.text))
                if (r != null) reply = r
            }
            reply?.let { r ->
                conv.recentBotReplies.add(r)
                while (conv.recentBotReplies.size > 10) conv.recentBotReplies.removeAt(0)
            }
            Repo.save()
        }
        Repo.notifyListeners()

        val text = reply ?: return
        main.postDelayed({ send(action, text) }, REPLY_DELAY_MS)
    }

    private fun send(action: Notification.Action, text: String) {
        try {
            val inputs = action.remoteInputs ?: return
            val intent = Intent().addFlags(Intent.FLAG_RECEIVER_FOREGROUND)
            val results = Bundle()
            inputs.forEach { ri -> if (ri.allowFreeFormInput) results.putCharSequence(ri.resultKey, text) }
            RemoteInput.addResultsToIntent(inputs, intent, results)
            action.actionIntent.send(this, 0, intent)
        } catch (e: Exception) {
            Log.e(TAG, "No se pudo responder", e)
        }
    }

    private fun same(a: String, b: String): Boolean {
        fun n(s: String) = s.filter { it.isLetterOrDigit() }.lowercase()
        val x = n(a); val y = n(b)
        return x == y || (x.length > 20 && y.length > 20 && (x.startsWith(y.take(40)) || y.startsWith(x.take(40))))
    }

    private fun phoneFromJid(jid: String?): String? {
        val m = Regex("^(\\d{6,15})@s\\.whatsapp\\.net$").find(jid ?: return null) ?: return null
        return "+" + m.groupValues[1]
    }

    override fun onDestroy() {
        worker.shutdown()
        super.onDestroy()
    }
}

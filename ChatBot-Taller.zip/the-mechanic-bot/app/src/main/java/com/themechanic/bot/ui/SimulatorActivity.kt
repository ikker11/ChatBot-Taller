package com.themechanic.bot.ui

import android.app.Activity
import android.graphics.Color
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.view.inputmethod.EditorInfo
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.HorizontalScrollView
import android.widget.LinearLayout
import android.widget.ScrollView
import com.themechanic.bot.R
import com.themechanic.bot.data.Repo
import com.themechanic.bot.engine.Incoming

/** Chat de prueba con aspecto de Mensajes de iOS. */
class SimulatorActivity : Activity() {

    private lateinit var messages: LinearLayout
    private lateinit var scroll: ScrollView
    private lateinit var input: EditText

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Repo.init(this)
        iosWindow(Color.WHITE)

        val root = vbox().apply { setBackgroundColor(Color.WHITE) }
        root.addView(navBar("Probar el bot", "Ajustes", { finish() }, "Reiniciar") { restart() }.apply { setBackgroundColor(Color.WHITE) })
        root.addView(View(this).apply { setBackgroundColor(C.SEPARATOR) }, lp(-1, hairline()))

        messages = vbox().apply { setPadding(dp(12), dp(10), dp(12), dp(16)) }
        scroll = ScrollView(this).apply { isVerticalScrollBarEnabled = false; addView(messages) }
        root.addView(scroll, lp(-1, 0, 1f))

        // Atajos para simular fotos, audios y ubicación
        val quick = hbox().apply { setPadding(dp(12), dp(6), dp(12), dp(6)) }
        listOf("📷 Foto" to "📷 Foto", "📍 Ubicación" to "📍 Ubicación", "🎤 Audio" to "🎤 Mensaje de voz (0:07)").forEach { (label, msg) ->
            quick.addView(tv(label, 14f, C.TINT, 1).apply {
                background = pressable(alpha(C.TINT, 0.10f), alpha(C.TINT, 0.2f), dp(16).toFloat())
                setPadding(dp(12), dp(6), dp(12), dp(6))
                setOnClickListener { send(msg) }
            }, lp(-2, -2).apply { rightMargin = dp(8) })
        }
        root.addView(HorizontalScrollView(this).apply { isHorizontalScrollBarEnabled = false; addView(quick) })

        // Barra de escritura
        val bar = hbox().apply { setPadding(dp(10), dp(6), dp(10), dp(10)); setBackgroundColor(Color.parseColor("#F9F9F9")) }
        input = EditText(this).apply {
            hint = "Mensaje"
            textSize = 16f
            typeface = Fonts.regular
            setTextColor(C.LABEL)
            setHintTextColor(C.SECONDARY)
            background = rounded(Color.WHITE, dp(19).toFloat(), hairline() * 2, C.TERTIARY)
            setPadding(dp(14), dp(8), dp(14), dp(8))
            imeOptions = EditorInfo.IME_ACTION_SEND
            setSingleLine(false)
            maxLines = 4
            setOnEditorActionListener { _, id, _ -> if (id == EditorInfo.IME_ACTION_SEND) { sendInput(); true } else false }
        }
        bar.addView(input, lp(0, -2, 1f))
        val sendBtn = FrameLayout(this).apply {
            background = oval(C.TINT)
            addView(icon(R.drawable.ic_arrow_up, Color.WHITE, 20), FrameLayout.LayoutParams(dp(20), dp(20), Gravity.CENTER))
            setOnClickListener { sendInput() }
        }
        bar.addView(sendBtn, lp(dp(36), dp(36)).apply { leftMargin = dp(8) })
        root.addView(bar)

        setContentView(root)
        system("Escribe como si fueras un cliente. Los casos que se creen aquí se marcan como PRUEBA.")
        system("Escribe \"Hola\" para empezar.")
    }

    private fun sendInput() {
        val t = input.text.toString().trim()
        if (t.isEmpty()) return
        input.setText("")
        send(t)
    }

    private fun send(text: String) {
        bubble(text, fromBot = false)
        val reply = synchronized(Repo.lock) {
            val conv = Repo.conversationFor(Repo.SIM_KEY)
            conv.waName = "Cliente de prueba"
            Repo.engine.handle(conv, Incoming(text)).also { Repo.save() }
        }
        Repo.notifyListeners()
        if (reply != null) scroll.postDelayed({ bubble(reply, fromBot = true) }, 450)
        else system("El bot no responde: la conversación ha terminado o la atiende un trabajador. Pulsa Reiniciar.")
    }

    private fun restart() {
        Repo.resetSimulator()
        messages.removeAllViews()
        system("Conversación reiniciada. Escribe \"Hola\".")
    }

    private fun system(text: String) {
        messages.addView(tv(text, 12f, C.SECONDARY).apply { gravity = Gravity.CENTER; setPadding(dp(24), dp(8), dp(24), dp(4)) },
            lp(-1, -2))
    }

    private fun bubble(text: String, fromBot: Boolean) {
        val b = tv(whatsappFormat(text), 16f, if (fromBot) C.LABEL else Color.WHITE).apply {
            background = rounded(if (fromBot) C.FILL else C.TINT, dp(18).toFloat())
            setPadding(dp(13), dp(8), dp(13), dp(9))
        }
        messages.addView(b, lp(-2, -2).apply {
            topMargin = dp(6)
            gravity = if (fromBot) Gravity.START else Gravity.END
            if (fromBot) rightMargin = dp(56) else leftMargin = dp(56)
        })
        scroll.post { scroll.fullScroll(ScrollView.FOCUS_DOWN) }
    }
}

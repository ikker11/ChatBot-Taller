package com.themechanic.bot.ui

import android.app.Activity
import android.graphics.Color
import android.os.Bundle
import android.view.Gravity
import android.view.MenuItem
import android.view.inputmethod.EditorInfo
import android.widget.EditText
import android.widget.HorizontalScrollView
import android.widget.LinearLayout
import android.widget.ScrollView
import com.themechanic.bot.data.Repo
import com.themechanic.bot.engine.Incoming

/** Chat de prueba: escribe como si fueras un cliente y mira qué responde el bot. */
class SimulatorActivity : Activity() {

    private lateinit var messages: LinearLayout
    private lateinit var scroll: ScrollView
    private lateinit var input: EditText

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Repo.init(this)
        title = "Probar el bot"
        actionBar?.setDisplayHomeAsUpEnabled(true)

        val root = vbox().apply { setBackgroundColor(Color.parseColor("#ECE5DD")) }
        root.addView(tv("Escribe como si fueras un cliente. Los casos que se creen aquí se marcan como PRUEBA.", 12f, C.MUTED).apply {
            setPadding(dp(14), dp(8), dp(14), dp(8)); setBackgroundColor(Color.WHITE)
        })

        messages = vbox(10)
        scroll = ScrollView(this).apply { addView(messages) }
        root.addView(scroll, lp(-1, 0, 1f))

        // Atajos para simular fotos, audios y ubicación
        val quick = hbox().apply { setPadding(dp(8), dp(4), dp(8), dp(4)) }
        listOf("📷 Foto" to "📷 Foto", "📍 Ubicación" to "📍 Ubicación", "🎤 Audio" to "🎤 Mensaje de voz (0:07)", "🔄 Reiniciar" to "").forEach { (label, msg) ->
            quick.addView(btn(label, 1) {
                if (msg.isEmpty()) restart() else send(msg)
            }, lp(-2, -2).apply { rightMargin = dp(6) })
        }
        root.addView(HorizontalScrollView(this).apply { addView(quick) })

        val bar = hbox().apply { setPadding(dp(8), dp(6), dp(8), dp(8)); setBackgroundColor(Color.WHITE) }
        input = EditText(this).apply {
            hint = "Escribe un mensaje"
            imeOptions = EditorInfo.IME_ACTION_SEND
            setSingleLine(false)
            maxLines = 4
            setOnEditorActionListener { _, id, _ -> if (id == EditorInfo.IME_ACTION_SEND) { sendInput(); true } else false }
        }
        bar.addView(input, lp(0, -2, 1f))
        bar.addView(btn("Enviar", 0) { sendInput() }, lp(-2, -2).apply { leftMargin = dp(6) })
        root.addView(bar)

        setContentView(root)
        bubble("👋 Escribe \"Hola\" para empezar la conversación de prueba.", fromBot = true)
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        if (item.itemId == android.R.id.home) { finish(); return true }
        return super.onOptionsItemSelected(item)
    }

    private fun sendInput() {
        val t = input.text.toString().trim()
        if (t.isEmpty()) return
        input.setText("")
        send(t)
    }

    private fun send(text: String) {
        bubble(text, fromBot = false)
        val reply = synchronized(Repo.lock) {
            val conv = Repo.conversationFor(Repo.SIM_KEY)
            conv.waName = "Cliente de prueba"
            Repo.engine.handle(conv, Incoming(text)).also { Repo.save() }
        }
        Repo.notifyListeners()
        if (reply != null) {
            scroll.postDelayed({ bubble(reply, fromBot = true) }, 400)
        } else {
            bubble("(el bot no responde: el caso está terminado o lo atiende un trabajador)", fromBot = true, system = true)
        }
    }

    private fun restart() {
        Repo.resetSimulator()
        messages.removeAllViews()
        bubble("🔄 Conversación reiniciada. Escribe \"Hola\".", fromBot = true, system = true)
    }

    private fun bubble(text: String, fromBot: Boolean, system: Boolean = false) {
        val b = tv(whatsappFormat(text), 15f, if (system) C.MUTED else C.INK).apply {
            background = rounded(if (fromBot) Color.WHITE else C.BUBBLE_ME, dp(12).toFloat())
            setPadding(dp(12), dp(8), dp(12), dp(8))
        }
        val params = lp(-2, -2).apply {
            topMargin = dp(6)
            gravity = if (fromBot) Gravity.START else Gravity.END
            if (fromBot) rightMargin = dp(48) else leftMargin = dp(48)
        }
        messages.addView(b, params)
        scroll.post { scroll.fullScroll(ScrollView.FOCUS_DOWN) }
    }
}

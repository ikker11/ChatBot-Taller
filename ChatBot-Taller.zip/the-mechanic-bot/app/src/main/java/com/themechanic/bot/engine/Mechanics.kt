package com.themechanic.bot.engine

/**
 * Conocimientos básicos de mecánica para responder dudas frecuentes y
 * detectar situaciones de riesgo. Respuestas prudentes y generales:
 * el diagnóstico real siempre lo hace el taller.
 */
object Mechanics {

    class Entry(val keywords: List<List<String>>, val answer: String, val safety: Boolean = false) {
        /** Coincide si alguna de las combinaciones de palabras aparece completa. */
        fun matches(text: String): Boolean = keywords.any { combo -> combo.all { TextParsing.containsAny(text, listOf(it)) || stemMatch(text, it) } }
        private fun stemMatch(text: String, k: String): Boolean =
            k.endsWith("*") && TextParsing.normalize(text).contains(TextParsing.normalize(k.dropLast(1)))
    }

    val ENTRIES: List<Entry> = listOf(
        Entry(
            listOf(listOf("no frena"), listOf("pedal", "blando"), listOf("freno", "fondo"), listOf("frenos", "fondo"), listOf("sin frenos"), listOf("fallan los frenos")),
            "⚠️ Si el coche no frena bien o el pedal está blando, *no circules con él*. Es mejor traerlo en grúa.",
            safety = true,
        ),
        Entry(
            listOf(listOf("humo"), listOf("fuego"), listOf("llamas"), listOf("quema*")),
            "⚠️ Si sale humo u olor a quemado, detén el vehículo en un lugar seguro, apaga el motor y no sigas circulando.",
            safety = true,
        ),
        Entry(
            listOf(listOf("olor", "gasolina"), listOf("huele", "gasolina"), listOf("olor", "combustible"), listOf("fuga", "gasolina"), listOf("pierde", "gasolina")),
            "⚠️ Si huele a combustible, no circules ni fumes cerca del vehículo.",
            safety = true,
        ),
        Entry(
            listOf(listOf("temperatura"), listOf("se calienta"), listOf("recalienta"), listOf("sobrecalienta"), listOf("anticongelante"), listOf("refrigerante")),
            "⚠️ Si la aguja de temperatura sube a la zona roja, para y apaga el motor. No abras el tapón del radiador en caliente.",
            safety = true,
        ),
        Entry(
            listOf(listOf("testigo", "aceite"), listOf("luz", "aceite"), listOf("presion", "aceite")),
            "⚠️ Si se enciende el testigo *rojo* de aceite, para el motor en cuanto sea seguro: circular así puede dañarlo gravemente.",
            safety = true,
        ),
        Entry(
            listOf(listOf("cada cuanto", "aceite"), listOf("cuando", "aceite"), listOf("cambio", "aceite", "km")),
            "Como referencia, el aceite se cambia cada 10.000–30.000 km o una vez al año, según el fabricante. Lo ideal es seguir el libro de mantenimiento.",
        ),
        Entry(
            listOf(listOf("chirria*"), listOf("pitan", "fren*"), listOf("ruido", "fren*"), listOf("chirrido"), listOf("rechina*")),
            "Un chirrido al frenar suele indicar pastillas desgastadas; conviene revisarlas pronto.",
        ),
        Entry(
            listOf(listOf("vibra*", "fren*"), listOf("tiembla", "fren*")),
            "Si el volante o el pedal vibran al frenar, puede que los discos estén deformados o gastados.",
        ),
        Entry(
            listOf(listOf("no arranca"), listOf("no enciende"), listOf("bateria"), listOf("hace clic"), listOf("hace click")),
            "Si no arranca y solo hace \"clic\" o las luces se ven débiles, suele ser la batería (duran unos 4–5 años). Si arranca con pinzas, revisaremos batería y alternador.",
        ),
        Entry(
            listOf(listOf("testigo", "motor"), listOf("luz", "motor"), listOf("check engine"), listOf("averia", "motor", "luz")),
            "El testigo amarillo de motor indica una avería registrada en la centralita. Si *parpadea*, no fuerces el motor. Lo comprobamos con la máquina de diagnosis.",
        ),
        Entry(
            listOf(listOf("embrague", "patina"), listOf("patina"), listOf("embrague", "duro"), listOf("embrague", "alto")),
            "Si el motor se revoluciona pero el coche no gana velocidad, o el pedal está muy alto, el embrague puede estar desgastado.",
        ),
        Entry(
            listOf(listOf("distribucion", "cuando"), listOf("distribucion", "cada")),
            "La distribución se cambia según el fabricante, normalmente entre 60.000 y 160.000 km o cada 5–10 años. Si se rompe puede averiar el motor, así que no conviene retrasarla.",
        ),
        Entry(
            listOf(listOf("aire", "no enfria"), listOf("aire acondicionado", "calor"), listOf("clima", "no enfria"), listOf("aire", "caliente")),
            "Si el aire acondicionado no enfría, puede faltar gas o haber una fuga. Lo comprobamos al hacer la recarga.",
        ),
        Entry(
            listOf(listOf("dibujo", "neumatic*"), listOf("milimetros", "rueda*"), listOf("cuando", "cambiar", "neumatic*"), listOf("ruedas", "gastadas")),
            "La profundidad mínima legal del dibujo es de 1,6 mm, aunque se recomienda cambiarlos antes (sobre 3 mm).",
        ),
        Entry(
            listOf(listOf("pinchazo"), listOf("pinchado"), listOf("pinchada"), listOf("reventon")),
            "Si tienes un pinchazo, no circules con la rueda deshinchada: puede dañar la llanta. Usa la rueda de repuesto o el kit antipinchazos.",
        ),
        Entry(
            listOf(listOf("itv", "documentos"), listOf("itv", "documentacion"), listOf("itv", "llevar"), listOf("itv", "papeles")),
            "Para la ITV hay que llevar la documentación del vehículo: permiso de circulación y tarjeta ITV (ficha técnica).",
        ),
        Entry(
            listOf(listOf("precio"), listOf("cuanto cuesta"), listOf("cuanto vale"), listOf("presupuesto"), listOf("cuanto sale")),
            "Los precios dependen de cada vehículo. Un trabajador revisará tu solicitud y te dará un presupuesto sin compromiso.",
        ),
    )

    fun matches(text: String): List<Entry> = ENTRIES.filter { it.matches(text) }

    fun safetyWarnings(text: String): List<String> = matches(text).filter { it.safety }.map { it.answer }

    fun isQuestion(text: String): Boolean =
        text.contains("?") || TextParsing.containsAny(text, listOf("que", "como", "cuando", "cuanto", "cada cuanto", "por que", "puedo", "es normal", "donde"))
}

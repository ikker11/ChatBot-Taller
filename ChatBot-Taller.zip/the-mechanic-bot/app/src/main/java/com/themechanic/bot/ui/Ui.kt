package com.themechanic.bot.ui

import android.content.Context
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.text.SpannableStringBuilder
import android.text.Spanned
import android.text.style.StyleSpan
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import com.themechanic.bot.engine.CaseStatus

/** Colores de la app: grafito + ámbar. */
object C {
    val BG = Color.parseColor("#F3F4F6")
    val CARD = Color.WHITE
    val INK = Color.parseColor("#111827")
    val MUTED = Color.parseColor("#6B7280")
    val LINE = Color.parseColor("#E5E7EB")
    val DARK = Color.parseColor("#1F2937")
    val ACCENT = Color.parseColor("#F59E0B")
    val ACCENT_SOFT = Color.parseColor("#FEF3C7")
    val RED = Color.parseColor("#DC2626")
    val GREEN = Color.parseColor("#16A34A")
    val BLUE = Color.parseColor("#2563EB")
    val PURPLE = Color.parseColor("#7C3AED")
    val BUBBLE_ME = Color.parseColor("#DCF8C6")

    fun status(s: CaseStatus): Int = when (s) {
        CaseStatus.IN_PROGRESS -> MUTED
        CaseStatus.PENDING -> BLUE
        CaseStatus.URGENT -> RED
        CaseStatus.NEEDS_CONTACT -> ACCENT
        CaseStatus.SCHEDULED -> GREEN
        CaseStatus.CLOSED -> Color.parseColor("#9CA3AF")
    }
}

fun Context.dp(v: Int): Int = (v * resources.displayMetrics.density + 0.5f).toInt()

fun rounded(color: Int, radiusPx: Float, strokePx: Int = 0, strokeColor: Int = 0): GradientDrawable =
    GradientDrawable().apply {
        setColor(color)
        cornerRadius = radiusPx
        if (strokePx > 0) setStroke(strokePx, strokeColor)
    }

fun Context.tv(text: CharSequence, size: Float = 15f, color: Int = C.INK, bold: Boolean = false): TextView =
    TextView(this).apply {
        this.text = text
        textSize = size
        setTextColor(color)
        if (bold) setTypeface(typeface, Typeface.BOLD)
        setLineSpacing(0f, 1.15f)
    }

fun Context.vbox(padDp: Int = 0): LinearLayout = LinearLayout(this).apply {
    orientation = LinearLayout.VERTICAL
    setPadding(dp(padDp), dp(padDp), dp(padDp), dp(padDp))
}

fun Context.hbox(): LinearLayout = LinearLayout(this).apply {
    orientation = LinearLayout.HORIZONTAL
    gravity = Gravity.CENTER_VERTICAL
}

fun Context.card(): LinearLayout = vbox(14).apply {
    background = rounded(C.CARD, dp(14).toFloat())
    elevation = dp(1).toFloat()
}

fun Context.btn(text: String, style: Int = 0, onClick: () -> Unit): Button = Button(this).apply {
    this.text = text
    isAllCaps = false
    textSize = 14f
    stateListAnimator = null
    val (bg, fg) = when (style) {
        0 -> C.DARK to Color.WHITE          // principal
        1 -> C.ACCENT_SOFT to C.INK         // secundario
        2 -> Color.parseColor("#FEE2E2") to C.RED // peligro
        else -> C.ACCENT to C.INK           // destacado
    }
    background = rounded(bg, dp(10).toFloat())
    setTextColor(fg)
    setPadding(dp(14), dp(8), dp(14), dp(8))
    minHeight = dp(44)
    setOnClickListener { onClick() }
}

fun Context.pill(text: String, color: Int): TextView = tv(text, 12f, Color.WHITE, bold = true).apply {
    background = rounded(color, dp(20).toFloat())
    setPadding(dp(10), dp(3), dp(10), dp(3))
}

fun lp(w: Int = ViewGroup.LayoutParams.MATCH_PARENT, h: Int = ViewGroup.LayoutParams.WRAP_CONTENT, weight: Float = 0f) =
    LinearLayout.LayoutParams(w, h, weight)

fun Context.space(hDp: Int): View = View(this).apply { layoutParams = LinearLayout.LayoutParams(1, dp(hDp)) }

fun LinearLayout.addSpaced(v: View, topDp: Int = 10, params: LinearLayout.LayoutParams = lp()) {
    params.topMargin = context.dp(topDp)
    addView(v, params)
}

/** Convierte el formato de WhatsApp (*negrita*) en negrita real. */
fun whatsappFormat(s: String): CharSequence {
    val out = SpannableStringBuilder()
    var i = 0
    val re = Regex("\\*([^*\\n]+)\\*")
    re.findAll(s).forEach { m ->
        out.append(s.substring(i, m.range.first))
        val start = out.length
        out.append(m.groupValues[1])
        out.setSpan(StyleSpan(Typeface.BOLD), start, out.length, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
        i = m.range.last + 1
    }
    out.append(s.substring(i))
    return out
}

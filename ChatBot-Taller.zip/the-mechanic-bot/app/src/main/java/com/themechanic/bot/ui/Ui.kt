package com.themechanic.bot.ui

import android.app.Activity
import android.content.Context
import android.content.res.ColorStateList
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.StateListDrawable
import android.text.SpannableStringBuilder
import android.text.Spanned
import android.text.TextUtils
import android.text.style.StyleSpan
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.Switch
import android.widget.TextView
import com.themechanic.bot.R
import com.themechanic.bot.engine.CaseStatus

/** Paleta inspirada en iOS. */
object C {
    val BG = Color.parseColor("#F2F2F7")
    val CARD = Color.WHITE
    val LABEL = Color.parseColor("#1C1C1E")
    val SECONDARY = Color.parseColor("#8E8E93")
    val TERTIARY = Color.parseColor("#C7C7CC")
    val SEPARATOR = Color.parseColor("#E5E5EA")
    val PRESSED = Color.parseColor("#E5E5EA")
    val FILL = Color.parseColor("#E9E9EB")
    val SEGMENT_BG = Color.parseColor("#E3E3E8")
    val TINT = Color.parseColor("#007AFF")
    val GREEN = Color.parseColor("#34C759")
    val RED = Color.parseColor("#FF3B30")
    val ORANGE = Color.parseColor("#FF9500")
    val INDIGO = Color.parseColor("#5856D6")
    val TEAL = Color.parseColor("#30B0C7")
    val GRAY = Color.parseColor("#8E8E93")

    // Compatibilidad con nombres anteriores
    val INK = LABEL
    val MUTED = SECONDARY

    fun status(s: CaseStatus): Int = when (s) {
        CaseStatus.IN_PROGRESS -> GRAY
        CaseStatus.PENDING -> TINT
        CaseStatus.URGENT -> RED
        CaseStatus.NEEDS_CONTACT -> ORANGE
        CaseStatus.SCHEDULED -> GREEN
        CaseStatus.CLOSED -> Color.parseColor("#AEAEB2")
    }

    fun shortStatus(s: CaseStatus): String = when (s) {
        CaseStatus.IN_PROGRESS -> "En curso"
        CaseStatus.PENDING -> "Pendiente"
        CaseStatus.URGENT -> "Grúa urgente"
        CaseStatus.NEEDS_CONTACT -> "Contactar"
        CaseStatus.SCHEDULED -> "Con cita"
        CaseStatus.CLOSED -> "Cerrado"
    }
}

object Fonts {
    val regular: Typeface = Typeface.create("sans-serif", Typeface.NORMAL)
    val medium: Typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
    val bold: Typeface = Typeface.create("sans-serif", Typeface.BOLD)
}

fun alpha(color: Int, a: Float): Int = Color.argb((a * 255).toInt(), Color.red(color), Color.green(color), Color.blue(color))

fun Context.dp(v: Int): Int = (v * resources.displayMetrics.density + 0.5f).toInt()

fun rounded(color: Int, radiusPx: Float, strokePx: Int = 0, strokeColor: Int = 0): GradientDrawable =
    GradientDrawable().apply {
        setColor(color)
        cornerRadius = radiusPx
        if (strokePx > 0) setStroke(strokePx, strokeColor)
    }

fun oval(color: Int): GradientDrawable = GradientDrawable().apply {
    shape = GradientDrawable.OVAL
    setColor(color)
}

/** Fondo que se oscurece al pulsar, como las celdas de iOS. */
fun pressable(normal: Int, pressed: Int, radiusPx: Float): StateListDrawable = StateListDrawable().apply {
    addState(intArrayOf(android.R.attr.state_pressed), rounded(pressed, radiusPx))
    addState(intArrayOf(), rounded(normal, radiusPx))
}

/** Ventana estilo iOS: barra de estado clara con iconos oscuros. */
fun Activity.iosWindow(statusColor: Int = C.BG) {
    window.statusBarColor = statusColor
    window.navigationBarColor = Color.WHITE
    window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR or View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR
}

fun Context.tv(text: CharSequence, size: Float = 16f, color: Int = C.LABEL, weight: Int = 0): TextView =
    TextView(this).apply {
        this.text = text
        textSize = size
        setTextColor(color)
        typeface = when (weight) { 1 -> Fonts.medium; 2 -> Fonts.bold; else -> Fonts.regular }
        setLineSpacing(0f, 1.12f)
    }

/** Compatibilidad: tv(..., bold = true). */
fun Context.tv(text: CharSequence, size: Float, color: Int, bold: Boolean): TextView = tv(text, size, color, if (bold) 1 else 0)

fun Context.vbox(padDp: Int = 0): LinearLayout = LinearLayout(this).apply {
    orientation = LinearLayout.VERTICAL
    setPadding(dp(padDp), dp(padDp), dp(padDp), dp(padDp))
}

fun Context.hbox(): LinearLayout = LinearLayout(this).apply {
    orientation = LinearLayout.HORIZONTAL
    gravity = Gravity.CENTER_VERTICAL
}

fun lp(w: Int = ViewGroup.LayoutParams.MATCH_PARENT, h: Int = ViewGroup.LayoutParams.WRAP_CONTENT, weight: Float = 0f) =
    LinearLayout.LayoutParams(w, h, weight)

fun Context.space(hDp: Int): View = View(this).apply { layoutParams = LinearLayout.LayoutParams(1, dp(hDp)) }

fun LinearLayout.addSpaced(v: View, topDp: Int = 10, params: LinearLayout.LayoutParams = lp()) {
    params.topMargin = context.dp(topDp)
    addView(v, params)
}

fun Context.hairline(): Int = (resources.displayMetrics.density * 0.6f).toInt().coerceAtLeast(1)

fun Context.icon(res: Int, color: Int, sizeDp: Int = 22): ImageView = ImageView(this).apply {
    setImageResource(res)
    setColorFilter(color)
    layoutParams = LinearLayout.LayoutParams(dp(sizeDp), dp(sizeDp))
}

// ---------------------------------------------------------------------
// Componentes estilo iOS
// ---------------------------------------------------------------------

fun Context.largeTitle(text: String): TextView = tv(text, 32f, C.LABEL, 2).apply {
    letterSpacing = -0.01f
}

fun Context.sectionHeader(text: String): TextView = tv(text.uppercase(), 13f, C.SECONDARY).apply {
    letterSpacing = 0.03f
    setPadding(dp(16), dp(24), dp(16), dp(7))
}

fun Context.sectionFooter(text: String): TextView = tv(text, 13f, C.SECONDARY).apply {
    setPadding(dp(16), dp(7), dp(16), 0)
}

/** Tarjeta blanca redondeada que agrupa filas (lista "inset grouped"). */
fun Context.group(): LinearLayout = vbox().apply {
    background = rounded(C.CARD, dp(12).toFloat())
    clipToOutline = true
}

/** Añade una fila a un grupo, con separador fino entre filas. */
fun LinearLayout.addRow(v: View, insetDp: Int = 16) {
    if (childCount > 0) {
        val sep = View(context).apply { setBackgroundColor(C.SEPARATOR) }
        addView(sep, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, context.hairline()).apply { leftMargin = context.dp(insetDp) })
    }
    addView(v, lp())
}

/** Icono blanco sobre cuadrado de color, como en Ajustes de iOS. */
fun Context.iconTile(res: Int, bg: Int, sizeDp: Int = 30): View = FrameLayout(this).apply {
    background = rounded(bg, dp(7).toFloat())
    val ic = ImageView(context).apply { setImageResource(res); setColorFilter(Color.WHITE) }
    addView(ic, FrameLayout.LayoutParams(dp(18), dp(18), Gravity.CENTER))
    layoutParams = LinearLayout.LayoutParams(dp(sizeDp), dp(sizeDp)).apply { rightMargin = dp(14) }
}

/** Fila estándar: [icono] Título / subtítulo ........ valor  › */
fun Context.row(
    title: CharSequence,
    value: CharSequence? = null,
    subtitle: CharSequence? = null,
    iconRes: Int? = null,
    iconBg: Int = C.TINT,
    titleColor: Int = C.LABEL,
    valueColor: Int = C.SECONDARY,
    chevron: Boolean = false,
    onClick: (() -> Unit)? = null,
): LinearLayout = hbox().apply {
    minimumHeight = dp(46)
    setPadding(dp(16), dp(11), dp(14), dp(11))
    if (iconRes != null) addView(iconTile(iconRes, iconBg))
    val texts = vbox()
    texts.addView(tv(title, 16f, titleColor))
    if (!subtitle.isNullOrEmpty()) texts.addView(tv(subtitle, 13f, C.SECONDARY).apply { setPadding(0, dp(2), 0, 0) })
    addView(texts, lp(0, -2, 1f))
    if (!value.isNullOrEmpty()) {
        addView(tv(value, 16f, valueColor).apply {
            gravity = Gravity.END
            maxLines = 2
            ellipsize = TextUtils.TruncateAt.END
        }, lp(-2, -2).apply { leftMargin = dp(12) })
    }
    if (chevron) addView(icon(R.drawable.ic_chevron_right, C.TERTIARY, 20), lp(dp(20), dp(20)).apply { leftMargin = dp(6) })
    if (onClick != null) {
        background = pressable(Color.TRANSPARENT, C.PRESSED, 0f)
        setOnClickListener { onClick() }
    }
}

/** Fila con interruptor. */
fun Context.switchRow(title: String, checked: Boolean, iconRes: Int? = null, iconBg: Int = C.GREEN, subtitle: String? = null, onChange: (Boolean) -> Unit): LinearLayout =
    row(title, subtitle = subtitle, iconRes = iconRes, iconBg = iconBg).apply {
        val sw = Switch(context).apply {
            isChecked = checked
            val states = arrayOf(intArrayOf(android.R.attr.state_checked), intArrayOf())
            trackTintList = ColorStateList(states, intArrayOf(C.GREEN, Color.parseColor("#D1D1D6")))
            thumbTintList = ColorStateList(states, intArrayOf(Color.WHITE, Color.WHITE))
            setOnCheckedChangeListener { _, on -> onChange(on) }
        }
        addView(sw, lp(-2, -2))
    }

/** Etiqueta de estado tipo cápsula. */
fun Context.badge(text: String, color: Int): TextView = tv(text, 12f, color, 1).apply {
    background = rounded(alpha(color, 0.14f), dp(10).toFloat())
    setPadding(dp(8), dp(2), dp(8), dp(3))
}

/** Compatibilidad con el nombre anterior. */
fun Context.pill(text: String, color: Int): TextView = badge(text, color)

/** Botón relleno grande. */
fun Context.filledButton(text: String, color: Int = C.TINT, onClick: () -> Unit): TextView = tv(text, 17f, Color.WHITE, 1).apply {
    gravity = Gravity.CENTER
    background = pressable(color, alpha(color, 0.75f), dp(13).toFloat())
    minHeight = dp(50)
    setPadding(dp(16), dp(12), dp(16), dp(12))
    setOnClickListener { onClick() }
}

/** Botón con fondo suave del color. */
fun Context.tintedButton(text: String, color: Int = C.TINT, onClick: () -> Unit): TextView = tv(text, 16f, color, 1).apply {
    gravity = Gravity.CENTER
    background = pressable(alpha(color, 0.12f), alpha(color, 0.22f), dp(12).toFloat())
    minHeight = dp(44)
    setPadding(dp(14), dp(10), dp(14), dp(10))
    setOnClickListener { onClick() }
}

/** Compatibilidad: btn(texto, estilo) { }. */
fun Context.btn(text: String, style: Int = 0, onClick: () -> Unit): TextView = when (style) {
    0 -> filledButton(text, C.TINT, onClick)
    2 -> tintedButton(text, C.RED, onClick)
    else -> tintedButton(text, C.TINT, onClick)
}

/** Texto pulsable de color (como los botones de la barra de navegación de iOS). */
fun Context.textButton(text: String, color: Int = C.TINT, size: Float = 17f, onClick: () -> Unit): TextView = tv(text, size, color).apply {
    setPadding(dp(8), dp(8), dp(8), dp(8))
    background = pressable(Color.TRANSPARENT, alpha(color, 0.10f), dp(8).toFloat())
    setOnClickListener { onClick() }
}

/** Control segmentado de iOS. */
fun Context.segmented(options: List<String>, selected: Int, onSelect: (Int) -> Unit): LinearLayout = hbox().apply {
    background = rounded(C.SEGMENT_BG, dp(9).toFloat())
    setPadding(dp(2), dp(2), dp(2), dp(2))
    options.forEachIndexed { i, label ->
        val seg = tv(label, 13f, C.LABEL, if (i == selected) 1 else 0).apply {
            gravity = Gravity.CENTER
            maxLines = 1
            ellipsize = TextUtils.TruncateAt.END
            setPadding(dp(6), dp(7), dp(6), dp(7))
            if (i == selected) {
                background = rounded(Color.WHITE, dp(7).toFloat())
                elevation = dp(1).toFloat()
            }
            setOnClickListener { onSelect(i) }
        }
        addView(seg, lp(0, -2, 1f))
    }
}

/** Barra de navegación: ‹ Atrás     Título     Acción */
fun Context.navBar(title: String, backLabel: String?, onBack: (() -> Unit)?, actionLabel: String? = null, onAction: (() -> Unit)? = null): View =
    FrameLayout(this).apply {
        setBackgroundColor(C.BG)
        minimumHeight = dp(52)
        if (backLabel != null && onBack != null) {
            val back = hbox().apply {
                setPadding(dp(6), dp(8), dp(12), dp(8))
                addView(icon(R.drawable.ic_chevron_left, C.TINT, 28))
                addView(tv(backLabel, 17f, C.TINT))
                background = pressable(Color.TRANSPARENT, alpha(C.TINT, 0.08f), dp(8).toFloat())
                setOnClickListener { onBack() }
            }
            addView(back, FrameLayout.LayoutParams(-2, -2, Gravity.START or Gravity.CENTER_VERTICAL))
        }
        addView(tv(title, 17f, C.LABEL, 1).apply { maxLines = 1; ellipsize = TextUtils.TruncateAt.END },
            FrameLayout.LayoutParams(-2, -2, Gravity.CENTER))
        if (actionLabel != null && onAction != null) {
            addView(textButton(actionLabel) { onAction() }, FrameLayout.LayoutParams(-2, -2, Gravity.END or Gravity.CENTER_VERTICAL).apply { rightMargin = dp(8) })
        }
    }

/** Círculo con iniciales, como en Contactos. */
fun Context.avatar(name: String, color: Int, sizeDp: Int): TextView {
    val initials = name.split(Regex("\\s+")).filter { it.isNotBlank() }.take(2).joinToString("") { it.first().uppercase() }.ifBlank { "?" }
    return tv(initials, sizeDp * 0.36f, Color.WHITE, 1).apply {
        gravity = Gravity.CENTER
        background = GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, intArrayOf(alpha(color, 0.75f), color)).apply { shape = GradientDrawable.OVAL }
        layoutParams = LinearLayout.LayoutParams(dp(sizeDp), dp(sizeDp))
    }
}

/** Convierte el formato de WhatsApp (*negrita*) en negrita real. */
fun whatsappFormat(s: String): CharSequence {
    val out = SpannableStringBuilder()
    var i = 0
    Regex("\\*([^*\\n]+)\\*").findAll(s).forEach { m ->
        out.append(s.substring(i, m.range.first))
        val start = out.length
        out.append(m.groupValues[1])
        out.setSpan(StyleSpan(Typeface.BOLD), start, out.length, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
        i = m.range.last + 1
    }
    out.append(s.substring(i))
    return out
}

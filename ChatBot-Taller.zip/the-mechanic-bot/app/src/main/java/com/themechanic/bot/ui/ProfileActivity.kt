package com.themechanic.bot.ui

import android.app.Activity
import android.app.AlertDialog
import android.app.DatePickerDialog
import android.app.TimePickerDialog
import android.content.ActivityNotFoundException
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Toast
import com.themechanic.bot.R
import com.themechanic.bot.data.AppSettings
import com.themechanic.bot.data.Appointment
import com.themechanic.bot.data.Fmt
import com.themechanic.bot.data.Repo
import com.themechanic.bot.engine.CaseStatus
import com.themechanic.bot.engine.Profile
import java.net.URLEncoder
import java.time.LocalDate
import java.time.LocalTime
import java.time.ZoneId

/** Ficha de un cliente, al estilo de Contactos de iOS. */
class ProfileActivity : Activity() {

    companion object {
        const val EXTRA_ID = "id"

        fun openWhatsApp(ctx: Context, phone: String, text: String) {
            var digits = phone.filter { it.isDigit() }
            if (digits.length == 9) digits = "34$digits"
            val uri = Uri.parse("https://wa.me/$digits?text=" + URLEncoder.encode(text, "UTF-8"))
            val intent = Intent(Intent.ACTION_VIEW, uri)
            try {
                ctx.startActivity(Intent(intent).setPackage("com.whatsapp.w4b"))
            } catch (e: ActivityNotFoundException) {
                try { ctx.startActivity(intent) } catch (e2: ActivityNotFoundException) {
                    Toast.makeText(ctx, "No se encontró WhatsApp", Toast.LENGTH_SHORT).show()
                }
            }
        }

        fun confirmationText(p: Profile, at: Long): String =
            "Hola ${p.name} 👋 Te confirmamos tu cita en *${AppSettings.tallerName}* el ${Fmt.longDateTime(at).replaceFirstChar { it.lowercase() }}" +
                (if (p.model.isNotBlank()) " para tu ${p.model}${if (p.plate.isNotBlank()) " (${p.plate})" else ""}" else "") +
                ". ¡Te esperamos! 🔧"

        /** Tras guardar una cita: ofrece enviar la confirmación al cliente por WhatsApp. */
        fun afterAppointment(act: Activity, p: Profile, a: Appointment, onDone: () -> Unit) {
            onDone()
            if (p.phone.isBlank()) {
                Toast.makeText(act, "Cita guardada", Toast.LENGTH_SHORT).show(); return
            }
            AlertDialog.Builder(act)
                .setTitle("Cita guardada")
                .setMessage("${Fmt.longDateTime(a.at)}\n\n¿Enviar la confirmación a ${p.name.ifBlank { "el cliente" }} por WhatsApp?\n\nSe abrirá WhatsApp con el mensaje preparado y el bot se pausará en ese chat.")
                .setPositiveButton("Enviar") { _, _ ->
                    Repo.pauseBot(p, "confirmación de cita enviada")
                    openWhatsApp(act, p.phone, confirmationText(p, a.at))
                }
                .setNegativeButton("Ahora no", null)
                .show()
        }
    }

    private var id: String? = null
    private var showChat = false
    private val refresher = Runnable { render() }
    private var scrollY = 0
    private var scroll: ScrollView? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Repo.init(this)
        iosWindow()
        id = intent.getStringExtra(EXTRA_ID)
    }

    override fun onResume() {
        super.onResume()
        Repo.addListener(refresher)
        render()
    }

    override fun onPause() {
        Repo.removeListener(refresher)
        super.onPause()
    }

    private fun render() {
        val p = Repo.profile(id)
        if (p == null) { finish(); return }
        scrollY = scroll?.scrollY ?: 0
        val name = p.name.ifBlank { p.waName.ifBlank { "Cliente" } }
        val color = C.status(p.status)

        val root = vbox().apply { setBackgroundColor(C.BG) }
        root.addView(navBar("", "Casos", { finish() }, "Estado") { changeStatus(p) })

        val box = vbox().apply { setPadding(dp(16), dp(4), dp(16), dp(32)) }

        // Cabecera tipo Contactos
        val head = vbox().apply { gravity = Gravity.CENTER_HORIZONTAL }
        head.addView(avatar(name, color, 92), LinearLayout.LayoutParams(dp(92), dp(92)).apply { gravity = Gravity.CENTER_HORIZONTAL })
        head.addSpaced(tv(name, 26f, C.LABEL, 2).apply { gravity = Gravity.CENTER }, 10, lp(-2, -2).apply { gravity = Gravity.CENTER_HORIZONTAL })
        if (p.vehicleLine().isNotBlank()) head.addSpaced(tv(p.vehicleLine(), 16f, C.SECONDARY).apply { gravity = Gravity.CENTER }, 2, lp(-2, -2).apply { gravity = Gravity.CENTER_HORIZONTAL })
        val badges = hbox().apply { gravity = Gravity.CENTER }
        badges.addView(badge(p.status.label, color).apply { setOnClickListener { changeStatus(p) } })
        if (p.isTest) badges.addView(badge("Prueba", C.INDIGO), lp(-2, -2).apply { leftMargin = dp(6) })
        head.addSpaced(badges, 8, lp(-2, -2).apply { gravity = Gravity.CENTER_HORIZONTAL })
        head.addSpaced(tv("Recibido el ${Fmt.dateTime(p.createdAt)}", 13f, C.SECONDARY).apply { gravity = Gravity.CENTER }, 6, lp(-2, -2).apply { gravity = Gravity.CENTER_HORIZONTAL })
        box.addSpaced(head, 4)

        // Acciones rápidas
        val hasPhone = p.phone.isNotBlank()
        val actions = hbox()
        actions.addView(actionTile("Llamar", R.drawable.ic_phone, hasPhone) {
            runCatching { startActivity(Intent(Intent.ACTION_DIAL, Uri.parse("tel:${p.phone.filter { it.isDigit() || it == '+' }}"))) }
        }, lp(0, -2, 1f).apply { rightMargin = dp(8) })
        actions.addView(actionTile("WhatsApp", R.drawable.ic_chat, hasPhone) {
            Repo.pauseBot(p, "el trabajador abre el chat")
            openWhatsApp(this, p.phone, "Hola ${p.name} 👋, te escribimos de ${AppSettings.tallerName}. ")
        }, lp(0, -2, 1f).apply { rightMargin = dp(8) })
        actions.addView(actionTile("Cita", R.drawable.ic_calendar, true) { assignAppointment(p) }, lp(0, -2, 1f).apply { rightMargin = dp(8) })
        actions.addView(actionTile("Nota", R.drawable.ic_edit, true) { addNote(p) }, lp(0, -2, 1f))
        box.addSpaced(actions, 18)

        // Vehículo y contacto
        box.addView(sectionHeader("Vehículo"))
        val veh = group()
        veh.addRow(row("Marca y modelo", p.model.ifBlank { "—" }))
        veh.addRow(row("Año", p.year.ifBlank { "—" }))
        veh.addRow(row("Matrícula", p.plate.ifBlank { "—" }))
        if (p.itvExpiry.isNotBlank()) veh.addRow(row("ITV caduca", p.itvExpiry, valueColor = C.ORANGE))
        box.addView(veh)

        box.addView(sectionHeader("Contacto"))
        val contact = group()
        contact.addRow(row("Teléfono", p.phone.ifBlank { "—" }, valueColor = if (hasPhone) C.TINT else C.SECONDARY,
            onClick = if (hasPhone) ({ runCatching { startActivity(Intent(Intent.ACTION_DIAL, Uri.parse("tel:${p.phone.filter { it.isDigit() || it == '+' }}"))) } }) else null))
        if (p.waName.isNotBlank()) contact.addRow(row("Nombre en WhatsApp", p.waName))
        box.addView(contact)

        // Servicios
        box.addView(sectionHeader("Servicios solicitados"))
        val serv = group()
        if (p.services.isEmpty()) serv.addRow(row("Aún no ha elegido ningún servicio", titleColor = C.SECONDARY))
        p.services.forEach { s ->
            val parts = s.split(" › ")
            serv.addRow(row(parts.last(), subtitle = if (parts.size > 1) parts.dropLast(1).joinToString(" › ") else null, iconRes = R.drawable.ic_wrench, iconBg = serviceColor(s)), 60)
        }
        box.addView(serv)

        // Citas
        box.addView(sectionHeader("Citas en el taller"))
        val ap = group()
        Repo.appointmentsFor(p.id).forEach { a ->
            val past = a.at < System.currentTimeMillis()
            ap.addRow(row(Fmt.longDate(Repo.dateOf(a.at)), Fmt.time(a.at), iconRes = R.drawable.ic_calendar, iconBg = if (past) C.GRAY else C.GREEN,
                valueColor = if (past) C.SECONDARY else C.GREEN, chevron = true) { appointmentOptions(p, a) }, 60)
        }
        ap.addRow(row("Asignar fecha y hora", iconRes = R.drawable.ic_add, iconBg = C.TINT, titleColor = C.TINT) { assignAppointment(p) }, 60)
        box.addView(ap)

        // Notas
        box.addView(sectionHeader("Información y notas"))
        val notes = group()
        if (p.notes.isEmpty()) notes.addRow(row("Sin notas", titleColor = C.SECONDARY))
        p.notes.forEach { n ->
            val stamp = n.substringBefore(" · ", "")
            val text = if (stamp.isNotEmpty()) n.substringAfter(" · ") else n
            notes.addRow(row(text, subtitle = stamp.ifEmpty { null }))
        }
        notes.addRow(row("Añadir nota", iconRes = R.drawable.ic_edit, iconBg = C.ORANGE, titleColor = C.TINT) { addNote(p) }, 60)
        box.addView(notes)

        // Gestión
        val paused = Repo.isBotPaused(p)
        box.addView(sectionHeader("Gestión"))
        val mg = group()
        mg.addRow(row("Estado", p.status.label, valueColor = color, chevron = true) { changeStatus(p) })
        mg.addRow(row("Bot en este chat", if (paused) "En pausa" else "Activo", subtitle = if (paused) Repo.pauseLabel(p).replaceFirstChar { it.uppercase() } else null,
            valueColor = if (paused) C.ORANGE else C.GREEN, chevron = true) {
            if (paused) Repo.resumeBot(p) else Repo.pauseBot(p, "pausa manual")
        })
        if (p.waName.isNotBlank()) {
            val excluded = AppSettings.isExcluded(p.waName, "")
            mg.addRow(row(if (excluded) "Volver a contestar a este contacto" else "No contestar nunca a este contacto", titleColor = if (excluded) C.TINT else C.RED) {
                AppSettings.excluded = if (excluded) AppSettings.excluded.filterNot { it.equals(p.waName, ignoreCase = true) } else AppSettings.excluded + p.waName
                render()
            })
        }
        if (p.status != CaseStatus.CLOSED) mg.addRow(row("Marcar como cerrado", titleColor = C.TINT) { Repo.setStatus(p.id, CaseStatus.CLOSED) })
        box.addView(mg)
        box.addView(sectionFooter(if (paused) "El bot no responderá a este cliente mientras lo atiendes tú. Puedes cambiar el tiempo en Ajustes." else "Si atiendes tú al cliente, pausa el bot para que no interfiera (${AppSettings.pauseLabel(AppSettings.pauseMinutes).lowercase()})."))

        // Conversación
        box.addView(sectionHeader("Conversación con el bot"))
        val chat = group()
        chat.addRow(row(if (showChat) "Ocultar conversación" else "Ver conversación", "${p.transcript.size} mensajes",
            iconRes = R.drawable.ic_chat, iconBg = C.GREEN, chevron = !showChat) { showChat = !showChat; render() }, 60)
        if (showChat) {
            val bubbles = vbox().apply { setPadding(dp(12), dp(8), dp(12), dp(12)) }
            p.transcript.forEach { line -> bubbles.addView(transcriptBubble(line)) }
            chat.addRow(bubbles, 0)
        }
        box.addView(chat)

        box.addSpaced(group().apply {
            addRow(row("Eliminar caso", titleColor = C.RED) {
                AlertDialog.Builder(this@ProfileActivity).setMessage("¿Eliminar este caso y sus citas? No se puede deshacer.")
                    .setPositiveButton("Eliminar") { _, _ -> Repo.deleteProfile(p.id); finish() }
                    .setNegativeButton("Cancelar", null).show()
            })
        }, 28)

        val sv = ScrollView(this).apply { setBackgroundColor(C.BG); isVerticalScrollBarEnabled = false; addView(box) }
        root.addView(sv, lp(-1, 0, 1f))
        scroll = sv
        setContentView(root)
        val y = scrollY
        sv.post { sv.scrollTo(0, y) }
    }

    private fun serviceColor(s: String): Int = when {
        s.startsWith("ITV") -> C.TINT
        s.startsWith("Mantenimiento básico") -> C.TEAL
        s.startsWith("Mantenimiento preventivo") -> C.INDIGO
        s.startsWith("Avería") -> C.ORANGE
        s.startsWith("Grúa") -> C.RED
        else -> C.GRAY
    }

    private fun actionTile(label: String, res: Int, enabled: Boolean, onClick: () -> Unit): View = vbox().apply {
        gravity = Gravity.CENTER_HORIZONTAL
        setPadding(0, dp(10), 0, dp(9))
        background = pressable(C.CARD, C.PRESSED, dp(12).toFloat())
        val c = if (enabled) C.TINT else C.TERTIARY
        addView(icon(res, c, 22), LinearLayout.LayoutParams(dp(22), dp(22)).apply { gravity = Gravity.CENTER_HORIZONTAL })
        addView(tv(label, 12f, c, 1).apply { gravity = Gravity.CENTER; setPadding(0, dp(4), 0, 0) }, lp(-2, -2).apply { gravity = Gravity.CENTER_HORIZONTAL })
        if (enabled) setOnClickListener { onClick() }
    }

    private fun transcriptBubble(line: String): View {
        // Formato: "dd/MM HH:mm · Quién: texto"
        val stamp = line.substringBefore(" · ", "")
        val rest = line.substringAfter(" · ")
        val fromBot = rest.startsWith("Bot:")
        val text = rest.substringAfter(": ", rest)
        val wrap = vbox().apply { gravity = if (fromBot) Gravity.START else Gravity.END }
        val bubble = tv(whatsappFormat(text), 15f, if (fromBot) C.LABEL else Color.WHITE).apply {
            background = rounded(if (fromBot) C.FILL else C.TINT, dp(17).toFloat())
            setPadding(dp(12), dp(8), dp(12), dp(8))
        }
        wrap.addView(bubble, lp(-2, -2).apply {
            gravity = if (fromBot) Gravity.START else Gravity.END
            if (fromBot) rightMargin = dp(40) else leftMargin = dp(40)
        })
        wrap.addView(tv((if (fromBot) "Bot · " else "Cliente · ") + stamp, 11f, C.SECONDARY).apply { setPadding(dp(6), dp(2), dp(6), 0) },
            lp(-2, -2).apply { gravity = if (fromBot) Gravity.START else Gravity.END })
        return wrap.apply { setPadding(0, dp(4), 0, dp(4)) }
    }

    private fun changeStatus(p: Profile) {
        val all = CaseStatus.values()
        AlertDialog.Builder(this)
            .setTitle("Estado del caso")
            .setSingleChoiceItems(all.map { it.label }.toTypedArray(), all.indexOf(p.status)) { d, i ->
                Repo.setStatus(p.id, all[i]); d.dismiss()
            }
            .setNegativeButton("Cancelar", null)
            .show()
    }

    private fun addNote(p: Profile) {
        val input = EditText(this).apply { hint = "Escribe la nota"; minLines = 2; setPadding(dp(20), dp(16), dp(20), dp(16)) }
        AlertDialog.Builder(this)
            .setTitle("Añadir nota")
            .setView(input)
            .setPositiveButton("Guardar") { _, _ -> input.text.toString().trim().takeIf { it.isNotEmpty() }?.let { Repo.addNote(p.id, it) } }
            .setNegativeButton("Cancelar", null)
            .show()
    }

    private fun assignAppointment(p: Profile) {
        val t = LocalDate.now()
        DatePickerDialog(this, { _, y, m, d ->
            TimePickerDialog(this, { _, h, min ->
                val at = LocalDate.of(y, m + 1, d).atTime(LocalTime.of(h, min)).atZone(ZoneId.systemDefault()).toInstant().toEpochMilli()
                val clash = Repo.allAppointments().filter { kotlin.math.abs(it.at - at) < 30 * 60_000L }
                val save = { afterAppointment(this, p, Repo.addAppointment(p.id, p.name, at)) { render() } }
                if (clash.isNotEmpty()) {
                    AlertDialog.Builder(this)
                        .setMessage("Ya hay ${clash.size} cita(s) a menos de 30 minutos de esa hora. ¿Guardar igualmente?")
                        .setPositiveButton("Guardar") { _, _ -> save() }
                        .setNegativeButton("Cancelar", null).show()
                } else save()
            }, 9, 0, true).show()
        }, t.year, t.monthValue - 1, t.dayOfMonth).show()
    }

    private fun appointmentOptions(p: Profile, a: Appointment) {
        AlertDialog.Builder(this)
            .setTitle(Fmt.longDateTime(a.at))
            .setItems(arrayOf("Enviar confirmación por WhatsApp", "Eliminar cita")) { _, i ->
                if (i == 0) {
                    if (p.phone.isBlank()) { Toast.makeText(this, "Este cliente no tiene teléfono", Toast.LENGTH_SHORT).show(); return@setItems }
                    Repo.pauseBot(p, "confirmación de cita enviada")
                    openWhatsApp(this, p.phone, confirmationText(p, a.at))
                } else {
                    Repo.deleteAppointment(a.id)
                }
            }
            .setNegativeButton("Cerrar", null)
            .show()
    }
}

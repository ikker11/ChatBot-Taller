package com.themechanic.bot.ui

import android.app.Activity
import android.app.AlertDialog
import android.app.DatePickerDialog
import android.app.TimePickerDialog
import android.content.ActivityNotFoundException
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.view.MenuItem
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Toast
import com.themechanic.bot.data.AppSettings
import com.themechanic.bot.data.Appointment
import com.themechanic.bot.data.Fmt
import com.themechanic.bot.data.Repo
import com.themechanic.bot.engine.CaseStatus
import com.themechanic.bot.engine.Profile
import java.net.URLEncoder
import java.time.LocalDate
import java.time.LocalTime
import java.time.ZoneId

/** Ficha de un cliente: datos, servicios, notas, citas y conversación. */
class ProfileActivity : Activity() {

    companion object {
        const val EXTRA_ID = "id"

        fun openWhatsApp(ctx: Context, phone: String, text: String) {
            var digits = phone.filter { it.isDigit() }
            if (digits.length == 9) digits = "34$digits"
            val uri = Uri.parse("https://wa.me/$digits?text=" + URLEncoder.encode(text, "UTF-8"))
            val intent = Intent(Intent.ACTION_VIEW, uri)
            try {
                ctx.startActivity(Intent(intent).setPackage("com.whatsapp.w4b"))
            } catch (e: ActivityNotFoundException) {
                try { ctx.startActivity(intent) } catch (e2: ActivityNotFoundException) {
                    Toast.makeText(ctx, "No se encontró WhatsApp", Toast.LENGTH_SHORT).show()
                }
            }
        }

        fun confirmationText(p: Profile, at: Long): String =
            "Hola ${p.name} 👋 Te confirmamos tu cita en *${AppSettings.tallerName}* el ${Fmt.longDateTime(at).replaceFirstChar { it.lowercase() }}" +
                (if (p.model.isNotBlank()) " para tu ${p.model}${if (p.plate.isNotBlank()) " (${p.plate})" else ""}" else "") +
                ". ¡Te esperamos! 🔧"

        /** Tras guardar una cita: ofrece enviar la confirmación al cliente por WhatsApp. */
        fun afterAppointment(act: Activity, p: Profile, a: Appointment, onDone: () -> Unit) {
            onDone()
            if (p.phone.isBlank()) {
                Toast.makeText(act, "Cita guardada", Toast.LENGTH_SHORT).show(); return
            }
            AlertDialog.Builder(act)
                .setTitle("Cita guardada ✅")
                .setMessage("${Fmt.longDateTime(a.at)}\n\n¿Quieres enviar la confirmación a ${p.name.ifBlank { "el cliente" }} por WhatsApp?\n(Se abrirá WhatsApp con el mensaje preparado; el bot se pausará en ese chat para no interferir.)")
                .setPositiveButton("Enviar por WhatsApp") { _, _ ->
                    Repo.pauseBot(p, "confirmación de cita enviada")
                    openWhatsApp(act, p.phone, confirmationText(p, a.at))
                }
                .setNegativeButton("Ahora no", null)
                .show()
        }
    }

    private var id: String? = null
    private var showChat = false
    private val refresher = Runnable { render() }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Repo.init(this)
        id = intent.getStringExtra(EXTRA_ID)
        actionBar?.setDisplayHomeAsUpEnabled(true)
    }

    override fun onResume() {
        super.onResume()
        Repo.addListener(refresher)
        render()
    }

    override fun onPause() {
        Repo.removeListener(refresher)
        super.onPause()
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        if (item.itemId == android.R.id.home) { finish(); return true }
        return super.onOptionsItemSelected(item)
    }

    private fun render() {
        val p = Repo.profile(id)
        if (p == null) { finish(); return }
        title = p.name.ifBlank { p.waName.ifBlank { "Caso" } }

        val box = vbox(14).apply { setBackgroundColor(C.BG) }

        // Cabecera
        val head = card()
        val top = hbox()
        top.addView(tv(p.name.ifBlank { p.waName.ifBlank { "Cliente" } }, 20f, bold = true), lp(0, -2, 1f))
        if (p.isTest) top.addView(pill("PRUEBA", C.PURPLE), lp(-2, -2).apply { rightMargin = dp(6) })
        head.addView(top)
        head.addSpaced(pill(p.status.label, C.status(p.status)).apply { setOnClickListener { changeStatus(p) } }, 6, lp(-2, -2))
        head.addSpaced(tv("Recibido: ${Fmt.dateTime(p.createdAt)}", 13f, C.MUTED), 6)
        if (p.waName.isNotBlank() && p.waName != p.name) head.addView(tv("Nombre en WhatsApp: ${p.waName}", 13f, C.MUTED))
        box.addView(head)

        // Datos
        val data = card()
        data.addView(tv("Datos del vehículo y contacto", 16f, bold = true))
        row(data, "🚗 Vehículo", p.model)
        row(data, "📆 Año", p.year)
        row(data, "🔢 Matrícula", p.plate)
        row(data, "📞 Teléfono", p.phone)
        if (p.itvExpiry.isNotBlank()) row(data, "📋 ITV caduca", p.itvExpiry)
        if (p.phone.isNotBlank()) {
            val actions = hbox()
            actions.addView(btn("Llamar", 1) {
                runCatching { startActivity(Intent(Intent.ACTION_DIAL, Uri.parse("tel:${p.phone.filter { it.isDigit() || it == '+' }}"))) }
            }, lp(0, -2, 1f).apply { rightMargin = dp(6) })
            actions.addView(btn("WhatsApp", 1) {
                Repo.pauseBot(p, "el trabajador abre el chat")
                openWhatsApp(this, p.phone, "Hola ${p.name} 👋, te escribimos de ${AppSettings.tallerName}. ")
            }, lp(0, -2, 1f))
            data.addSpaced(actions, 10)
        }
        box.addSpaced(data, 12)

        // Servicios
        val serv = card()
        serv.addView(tv("Servicios solicitados", 16f, bold = true))
        if (p.services.isEmpty()) serv.addView(tv("Aún no ha elegido ningún servicio.", 14f, C.MUTED))
        p.services.forEach { serv.addSpaced(tv("• $it", 15f), 4) }
        box.addSpaced(serv, 12)

        // Notas
        val notes = card()
        notes.addView(tv("Información y notas", 16f, bold = true))
        if (p.notes.isEmpty()) notes.addView(tv("Sin notas.", 14f, C.MUTED))
        p.notes.forEach { notes.addSpaced(tv(it, 14f), 6) }
        notes.addSpaced(btn("✍️ Añadir nota", 1) { addNote(p) }, 10)
        box.addSpaced(notes, 12)

        // Citas
        val ap = card()
        ap.addView(tv("Citas en el taller", 16f, bold = true))
        val appts = Repo.appointmentsFor(p.id)
        if (appts.isEmpty()) ap.addView(tv("Sin cita asignada.", 14f, C.MUTED))
        appts.forEach { a ->
            val r = hbox().apply {
                background = rounded(C.ACCENT_SOFT, dp(10).toFloat())
                setPadding(dp(10), dp(8), dp(10), dp(8))
            }
            r.addView(tv("📅 ${Fmt.longDateTime(a.at)}", 14f, bold = true), lp(0, -2, 1f))
            r.setOnClickListener { appointmentOptions(p, a) }
            ap.addSpaced(r, 6)
        }
        ap.addSpaced(btn("📅 Asignar fecha y hora", 3) { assignAppointment(p) }, 10)
        box.addSpaced(ap, 12)

        // Estado y bot
        val st = card()
        st.addView(tv("Gestión del caso", 16f, bold = true))
        st.addSpaced(btn("Cambiar estado (${p.status.label})", 1) { changeStatus(p) }, 8)
        if (p.status != CaseStatus.CLOSED) st.addSpaced(btn("✔️ Marcar como cerrado", 1) { Repo.setStatus(p.id, CaseStatus.CLOSED) }, 8)
        val paused = Repo.isBotPaused(p)
        st.addSpaced(tv(if (paused) "⏸️ El bot está en pausa en este chat (lo atiende una persona)." else "🤖 El bot atiende este chat.", 13f, C.MUTED), 10)
        st.addSpaced(
            if (paused) btn("▶️ Reactivar el bot en este chat", 1) { Repo.resumeBot(p) }
            else btn("⏸️ Pausar el bot (lo atiendo yo)", 1) { Repo.pauseBot(p, "pausa manual") },
            6,
        )
        box.addSpaced(st, 12)

        // Conversación
        val chat = card()
        val chatHead = hbox()
        chatHead.addView(tv("Conversación con el bot (${p.transcript.size})", 16f, bold = true), lp(0, -2, 1f))
        chatHead.addView(btn(if (showChat) "Ocultar" else "Ver", 1) { showChat = !showChat; render() })
        chat.addView(chatHead)
        if (showChat) {
            p.transcript.forEach { line ->
                val fromBot = line.contains("· Bot:")
                chat.addSpaced(tv(whatsappFormat(line), 13f).apply {
                    background = rounded(if (fromBot) C.BG else C.BUBBLE_ME, dp(10).toFloat())
                    setPadding(dp(10), dp(6), dp(10), dp(6))
                }, 6)
            }
        }
        box.addSpaced(chat, 12)

        box.addSpaced(btn("🗑️ Eliminar caso", 2) {
            AlertDialog.Builder(this).setMessage("¿Eliminar este caso y sus citas? No se puede deshacer.")
                .setPositiveButton("Eliminar") { _, _ -> Repo.deleteProfile(p.id); finish() }
                .setNegativeButton("Cancelar", null).show()
        }, 16)

        val scroll = ScrollView(this).apply { setBackgroundColor(C.BG); addView(box) }
        setContentView(scroll)
    }

    private fun row(parent: LinearLayout, label: String, value: String) {
        val r = hbox()
        r.addView(tv(label, 14f, C.MUTED), lp(dp(130), -2))
        r.addView(tv(value.ifBlank { "—" }, 15f, bold = true), lp(0, -2, 1f))
        parent.addSpaced(r, 6)
    }

    private fun changeStatus(p: Profile) {
        val all = CaseStatus.values()
        AlertDialog.Builder(this)
            .setTitle("Estado del caso")
            .setSingleChoiceItems(all.map { it.label }.toTypedArray(), all.indexOf(p.status)) { d, i ->
                Repo.setStatus(p.id, all[i]); d.dismiss()
            }
            .setNegativeButton("Cancelar", null)
            .show()
    }

    private fun addNote(p: Profile) {
        val input = EditText(this).apply { hint = "Escribe la nota"; minLines = 2 }
        AlertDialog.Builder(this)
            .setTitle("Añadir nota")
            .setView(input)
            .setPositiveButton("Guardar") { _, _ -> input.text.toString().trim().takeIf { it.isNotEmpty() }?.let { Repo.addNote(p.id, it) } }
            .setNegativeButton("Cancelar", null)
            .show()
    }

    private fun assignAppointment(p: Profile) {
        val t = LocalDate.now()
        DatePickerDialog(this, { _, y, m, d ->
            TimePickerDialog(this, { _, h, min ->
                val at = LocalDate.of(y, m + 1, d).atTime(LocalTime.of(h, min)).atZone(ZoneId.systemDefault()).toInstant().toEpochMilli()
                val clash = Repo.allAppointments().filter { kotlin.math.abs(it.at - at) < 30 * 60_000L }
                val save = { afterAppointment(this, p, Repo.addAppointment(p.id, p.name, at)) { render() } }
                if (clash.isNotEmpty()) {
                    AlertDialog.Builder(this)
                        .setMessage("Ya hay ${clash.size} cita(s) a menos de 30 min de esa hora. ¿Guardar igualmente?")
                        .setPositiveButton("Guardar") { _, _ -> save() }
                        .setNegativeButton("Cancelar", null).show()
                } else save()
            }, 9, 0, true).show()
        }, t.year, t.monthValue - 1, t.dayOfMonth).show()
    }

    private fun appointmentOptions(p: Profile, a: Appointment) {
        AlertDialog.Builder(this)
            .setTitle("Cita")
            .setMessage(Fmt.longDateTime(a.at))
            .setPositiveButton("Enviar confirmación") { _, _ ->
                Repo.pauseBot(p, "confirmación de cita enviada")
                openWhatsApp(this, p.phone, confirmationText(p, a.at))
            }
            .setNeutralButton("Eliminar cita") { _, _ -> Repo.deleteAppointment(a.id) }
            .setNegativeButton("Cerrar", null)
            .show()
    }
}
